# RippleMind — AI-Driven Examination Timetable Simulation and Optimization

A full-stack web application for creating examination timetables, detecting scheduling conflicts, allocating rooms and invigilators, simulating changes before applying them, and handling emergency room outages.

## Quick Start

```bash
# 1. Install dependencies
bun install        # or: npm install

# 2. Set up the database
bun run db:push    # or: npx prisma db push

# 3. Start the dev server
bun run dev        # or: npm run dev

# 4. Open http://localhost:3000

# 5. Load demo data (in a new terminal, while server is running)
curl -X POST http://localhost:3000/api/ripplemind/seed
```

## Login Credentials

**Administrator** (full access to all 18 pages):
- Email: `admin@ripplemind.edu`
- Password: `admin123` (or any password ≥ 4 chars)

**Student** (view-only Student Portal):
- Switch to the "Student" tab
- Enter your name
- Select your student group from the dropdown

## Features

### Authentication & Roles
- Login page with Administrator and Student tabs
- Admin: full access to all 18 pages
- Student: simplified view with only their exam schedule
- Session persists via localStorage
- Logout button in both admin and student topbars

### Part 1 — Foundation
1. **Dashboard** — real-time metrics, CSS bar charts for conflicts/exam types, upcoming exams
2. **Exams Management** — CRUD with validation (duration 30–480 min, positive enrollment, unique codes)
3. **Student Groups** — CRUD with student counts
4. **Rooms Management** — CRUD with capacity, location, availability toggle
5. **Time Slots** — CRUD with date/time validation
6. **Invigilators** — CRUD with max workload and availability
7. **Generate Timetable** — solver mode selector (CP/Greedy), configurable objective weights
8. **Timetable Viewer** — table + calendar views, CSV export
9. **Conflict Reports** — 6 hard-constraint checks + 3 fairness checks with severity indicators
10. **Settings** — demo data loading, audit log, solver configuration

### Part 2 — Simulation
11. **What-if Simulation** — propose changes, test feasibility, 6 interactive CSS bar graphs comparing original vs proposed
12. **Ripple-effect Analysis** — CSS-based graph visualization of change impact
13. **Alternative Comparison** — multiple feasible solutions compared side-by-side
14. **AI Assistant** — GLM-4.6 chat + NL-to-proposal translation (feasibility always by solver, never LLM)
15. **Scenario History** — saved scenarios with restore/discard, audit trail
16. **Analytics** — room utilization, invigilator workload, student-group workload, seat utilization, quality score, CSV export

### Emergency Features
17. **Emergency Simulation** — simulate a room outage, automatically re-schedule affected exams
18. **Student Portal** — personalized timetable with room allotment, invigilators, recent changes, print support

### Constraint-Based Optimization
- **Greedy solver** (`src/lib/greedy-solver.ts`) — fast first-fit + local search, considers room capacity, conflicts, duration, stability
- **CP solver** (`src/lib/solver.ts`) — constraint programming with MRV, forward-checking, fairness constraints (available when more RAM)
- **OR-Tools integration** — set `ORTOOLS_AVAILABLE=true` when Google OR-Tools is installed in production
- **Fairness constraints** — max 2 exams/day per group, 1-hour minimum gap between exams

### Conflict Detection (9 rules)
- Room double-booking
- Student group overlap
- Room capacity violations
- Invigilator double-booking
- Unavailable resources (rooms, slots, invigilators)
- Incomplete assignments
- Excessive daily exam load per group (>2/day)
- Back-to-back exams (<30 min gap)
- Invigilator fatigue (3+ assignments/day)

### UI Features
- Bold orange/red/cream/white theme
- Responsive layout (mobile sidebar, stacking cards)
- Keyboard focus indicators
- Animated stat cards, shimmer loading states
- Print-optimized Student Portal
- Toast notifications

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 16, React 19, TypeScript 5, Tailwind CSS 4, shadcn/ui |
| Backend | Next.js API Routes (REST) |
| Database | Prisma ORM (SQLite dev / PostgreSQL prod) |
| Solver | Greedy first-fit + TypeScript CP solver (OR-Tools ready) |
| Charts | Pure CSS (no heavy libraries — runs in 4GB environments) |
| AI | z-ai-web-dev-sdk (GLM-4.6) |
| State | Zustand + TanStack Query |

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/ripplemind/dashboard` | Dashboard metrics |
| GET/POST | `/api/ripplemind/exams` | Exam CRUD |
| GET/POST | `/api/ripplemind/student-groups` | Student group CRUD |
| GET/POST | `/api/ripplemind/rooms` | Room CRUD |
| GET/POST | `/api/ripplemind/time-slots` | Time slot CRUD |
| GET/POST | `/api/ripplemind/invigilators` | Invigilator CRUD |
| GET | `/api/ripplemind/assignments` | Published timetable |
| GET | `/api/ripplemind/conflicts` | All conflicts |
| POST | `/api/ripplemind/schedule/generate` | Run solver |
| POST | `/api/ripplemind/schedule/apply` | Apply timetable (atomic) |
| GET/POST | `/api/ripplemind/scenarios` | What-if scenarios |
| POST | `/api/ripplemind/scenarios/[id]/apply` | Apply scenario |
| POST | `/api/ripplemind/scenarios/[id]/ripple` | Ripple graph data |
| POST | `/api/ripplemind/emergency/outage` | Emergency room outage |
| GET | `/api/ripplemind/student-portal?groupId=` | Student portal data |
| POST | `/api/ripplemind/ai/explain` | LLM explanation |
| POST | `/api/ripplemind/ai/translate` | NL-to-proposal |
| GET | `/api/ripplemind/analytics` | Analytics data |
| GET | `/api/ripplemind/audit` | Audit log |
| GET/POST | `/api/ripplemind/notifications` | Notifications |
| POST | `/api/ripplemind/seed` | Load demo data |
| POST | `/api/ripplemind/reset` | Clear all data |

## Environment Variables

```env
DATABASE_URL=file:./db/custom.db    # SQLite dev; use postgresql:// URL for prod
SOLVER_TIME_LIMIT_MS=5000
SOLVER_MAX_ALTERNATIVES=4
ORTOOLS_AVAILABLE=false             # Set true when OR-Tools installed
OPENAI_API_KEY=                     # Optional: for OpenAI-compatible LLM
OPENAI_BASE_URL=
```

## Production Deployment

### Vercel (recommended)
1. Push the project to GitHub
2. Go to [vercel.com](https://vercel.com) → Import repo
3. Vercel auto-detects Next.js
4. Add environment variables in Vercel dashboard
5. Deploy → get live URL

### PostgreSQL Production
1. Set `DATABASE_URL` to your PostgreSQL connection string
2. Change `provider = "sqlite"` to `provider = "postgresql"` in `prisma/schema.prisma`
3. Run `bun run db:push`
4. Build: `bun run build`
5. Start: `bun run start`

### Enable OR-Tools (optional)
For optimal constraint solving in production:
1. Install Python + Google OR-Tools: `pip install ortools`
2. Set `ORTOOLS_AVAILABLE=true` in environment
3. The API will report `or-tools-cp-sat` as the solver used

## Demo Data

The seed endpoint loads:
- 8 student groups (CS, EE, ME, BA, MATH, PHY, CE, CHEM)
- 10 exams across all groups
- 12 rooms (auditoriums, halls, labs)
- 15 time slots (5 weekdays × 3 sessions)
- 6 invigilators from different departments

## Tests

```bash
bun test
```

15 tests covering:
- Solver feasibility and infeasibility detection
- Room capacity enforcement
- Room/student-group/invigilator conflict prevention
- Fairness constraints (max exams per day, minimum gap)
- All 6 conflict detection rules + 3 fairness checks

## File Structure

```
prisma/schema.prisma              — Database schema
src/lib/
  types.ts                        — Domain types
  solver.ts                       — CP solver (MRV, forward-checking)
  greedy-solver.ts                — Greedy fallback solver
  conflicts.ts                    — 9-rule conflict detection
  ripple.ts                       — Ripple graph builder
  ai.ts                           — LLM integration
  auth.ts                         — Auth store
  store.ts                        — Navigation store
  api.ts                          — TanStack Query hooks
  time.ts, json.ts                — Utilities
src/app/api/ripplemind/           — REST API routes
src/pages/                        — 18 page components
src/components/                   — UI components, CSS charts
tests/                            — Test suite
```

## License

MIT
