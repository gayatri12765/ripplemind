// What-if Simulation Charts — LIGHTWEIGHT CSS version (no Recharts)
'use client';

import { useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CSSHBarChart, CSSProgressBar, SimpleStat } from '@/components/css-charts';
import { TrendingUp, TrendingDown, Minus, Building, UserCheck, Calendar, Activity } from 'lucide-react';
import type { AssignmentProposal, Exam, Invigilator, Room, TimeSlot } from '@/lib/types';
import { formatDate } from '@/lib/time';

interface WhatIfChartsProps {
  original: AssignmentProposal[];
  proposed: AssignmentProposal[];
  conflicts: number;
  feasible: boolean;
  exams: Exam[];
  rooms: Room[];
  timeSlots: TimeSlot[];
  invigilators: Invigilator[];
  changedExams: number;
  roomChanges: number;
}

const COLORS = {
  original: '#8C5A3F',
  proposed: '#FF6B35',
  changed: '#D62828',
  unchanged: '#2D6A4F',
  good: '#2D6A4F',
  bad: '#D62828',
  neutral: '#F77F00',
};

export function WhatIfCharts({
  original, proposed, conflicts, feasible,
  exams, rooms, timeSlots, invigilators,
  changedExams, roomChanges,
}: WhatIfChartsProps) {
  const originalMetrics = useMemo(() => computeMetrics(original, exams, rooms, timeSlots, invigilators), [original, exams, rooms, timeSlots, invigilators]);
  const proposedMetrics = useMemo(() => computeMetrics(proposed, exams, rooms, timeSlots, invigilators), [proposed, exams, rooms, timeSlots, invigilators]);

  // Room utilization comparison
  const allRoomIds = new Set([...original.map(a => a.roomId), ...proposed.map(a => a.roomId)]);
  const roomComparison = Array.from(allRoomIds).map(roomId => {
    const room = rooms.find(r => r.id === roomId);
    return {
      label: room?.name?.length > 12 ? room.name.slice(0, 10) + '…' : (room?.name ?? roomId),
      Original: original.filter(a => a.roomId === roomId).length,
      Proposed: proposed.filter(a => a.roomId === roomId).length,
    };
  }).filter(r => r.Original > 0 || r.Proposed > 0).sort((a, b) => (b.Original + b.Proposed) - (a.Original + a.Proposed)).slice(0, 8);

  // Invigilator workload comparison
  const allInvIds = new Set([...original.flatMap(a => a.invigilatorIds), ...proposed.flatMap(a => a.invigilatorIds)]);
  const invComparison = Array.from(allInvIds).map(invId => {
    const inv = invigilators.find(i => i.id === invId);
    return {
      label: inv?.name?.split(' ').slice(-1)[0] ?? invId,
      Original: original.filter(a => a.invigilatorIds.includes(invId)).length,
      Proposed: proposed.filter(a => a.invigilatorIds.includes(invId)).length,
    };
  }).sort((a, b) => (b.Original + b.Proposed) - (a.Original + a.Proposed));

  // Daily distribution
  const allDates = new Set([...original.map(a => timeSlots.find(s => s.id === a.timeSlotId)?.date ?? '').filter(Boolean),
                            ...proposed.map(a => timeSlots.find(s => s.id === a.timeSlotId)?.date ?? '').filter(Boolean)]);
  const dailyComparison = Array.from(allDates).sort().map(date => ({
    label: formatDate(date).split(' ').slice(0, 2).join(' '),
    Original: original.filter(a => timeSlots.find(s => s.id === a.timeSlotId)?.date === date).length,
    Proposed: proposed.filter(a => timeSlots.find(s => s.id === a.timeSlotId)?.date === date).length,
  }));

  // Metrics comparison
  const metricsComparison = [
    { label: 'Scheduled', Original: originalMetrics.scheduled, Proposed: proposedMetrics.scheduled },
    { label: 'Rooms Used', Original: originalMetrics.roomsUsed, Proposed: proposedMetrics.roomsUsed },
    { label: 'Invigilators', Original: originalMetrics.invigilatorsUsed, Proposed: proposedMetrics.invigilatorsUsed },
    { label: 'Capacity Waste', Original: originalMetrics.capacityWaste, Proposed: proposedMetrics.capacityWaste },
    { label: 'Max Inv Load', Original: originalMetrics.maxInvLoad, Proposed: proposedMetrics.maxInvLoad },
    { label: 'Exam Days', Original: originalMetrics.uniqueDates, Proposed: proposedMetrics.uniqueDates },
  ];

  const deltas = {
    waste: proposedMetrics.capacityWaste - originalMetrics.capacityWaste,
    invLoad: proposedMetrics.maxInvLoad - originalMetrics.maxInvLoad,
    rooms: proposedMetrics.roomsUsed - originalMetrics.roomsUsed,
    days: proposedMetrics.uniqueDates - originalMetrics.uniqueDates,
  };

  return (
    <div className="space-y-4">
      {/* Impact summary */}
      <Card className="border-warm shadow-warm">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-semibold flex items-center gap-2"><Activity className="h-4 w-4 text-[#FF6B35]" /> Ripple Impact Summary</h4>
            <Badge className={feasible ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>{feasible ? 'Feasible' : 'Infeasible'}</Badge>
          </div>
          {/* Stacked bar */}
          <div className="flex h-8 rounded-lg overflow-hidden bg-cream-deep mb-3">
            <div className="flex items-center justify-center text-white text-xs font-medium transition-all duration-700" style={{ width: `${((proposedMetrics.scheduled - changedExams) / (proposedMetrics.scheduled || 1)) * 100}%`, background: COLORS.unchanged, minWidth: '40px' }}>{proposedMetrics.scheduled - changedExams > 0 ? proposedMetrics.scheduled - changedExams : ''}</div>
            <div className="flex items-center justify-center text-white text-xs font-medium transition-all duration-700" style={{ width: `${(changedExams / (proposedMetrics.scheduled || 1)) * 100}%`, background: COLORS.changed, minWidth: '40px' }}>{changedExams > 0 ? changedExams : ''}</div>
            <div className="flex items-center justify-center text-white text-xs font-medium transition-all duration-700" style={{ width: `${(roomChanges / (proposedMetrics.scheduled || 1)) * 100}%`, background: COLORS.neutral, minWidth: '40px' }}>{roomChanges > 0 ? roomChanges : ''}</div>
          </div>
          <div className="flex items-center gap-4 flex-wrap text-xs mb-4">
            <div className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm" style={{ background: COLORS.unchanged }} /><span className="text-warm-muted">Unchanged</span><span className="font-semibold">{proposedMetrics.scheduled - changedExams}</span></div>
            <div className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm" style={{ background: COLORS.changed }} /><span className="text-warm-muted">Changed</span><span className="font-semibold">{changedExams}</span></div>
            <div className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm" style={{ background: COLORS.neutral }} /><span className="text-warm-muted">Room moved</span><span className="font-semibold">{roomChanges}</span></div>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
            <DeltaCard label="Capacity Waste" delta={deltas.waste} unit="seats" />
            <DeltaCard label="Max Inv Load" delta={deltas.invLoad} unit="assignments" />
            <DeltaCard label="Rooms Used" delta={deltas.rooms} unit="rooms" />
            <DeltaCard label="Exam Days" delta={deltas.days} unit="days" />
          </div>
        </CardContent>
      </Card>

      {/* Metrics comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="border-warm shadow-warm">
          <CardContent className="p-5">
            <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><TrendingUp className="h-4 w-4 text-[#FF6B35]" /> Original vs Proposed Metrics</h4>
            <div className="space-y-3">
              {metricsComparison.map((m) => {
                const max = Math.max(m.Original, m.Proposed, 1);
                return (
                  <div key={m.label}>
                    <div className="text-xs font-medium mb-1">{m.label}</div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="text-[10px] text-warm-muted w-16">Original</div>
                      <div className="flex-1 h-3 bg-cream-deep rounded overflow-hidden"><div className="h-full rounded transition-all duration-700" style={{ width: `${(m.Original / max) * 100}%`, background: COLORS.original }} /></div>
                      <div className="text-[10px] font-bold w-8 text-right">{m.Original}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-[10px] text-warm-muted w-16">Proposed</div>
                      <div className="flex-1 h-3 bg-cream-deep rounded overflow-hidden"><div className="h-full rounded transition-all duration-700" style={{ width: `${(m.Proposed / max) * 100}%`, background: COLORS.proposed }} /></div>
                      <div className="text-[10px] font-bold w-8 text-right">{m.Proposed}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Daily distribution */}
        <Card className="border-warm shadow-warm">
          <CardContent className="p-5">
            <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><Calendar className="h-4 w-4 text-[#FF6B35]" /> Daily Exam Distribution</h4>
            <div className="space-y-3">
              {dailyComparison.map((d) => {
                const max = Math.max(d.Original, d.Proposed, 1);
                return (
                  <div key={d.label}>
                    <div className="text-xs font-medium mb-1">{d.label}</div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="text-[10px] text-warm-muted w-16">Original</div>
                      <div className="flex-1 h-3 bg-cream-deep rounded overflow-hidden"><div className="h-full rounded transition-all duration-700" style={{ width: `${(d.Original / max) * 100}%`, background: COLORS.original }} /></div>
                      <div className="text-[10px] font-bold w-8 text-right">{d.Original}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-[10px] text-warm-muted w-16">Proposed</div>
                      <div className="flex-1 h-3 bg-cream-deep rounded overflow-hidden"><div className="h-full rounded transition-all duration-700" style={{ width: `${(d.Proposed / max) * 100}%`, background: COLORS.proposed }} /></div>
                      <div className="text-[10px] font-bold w-8 text-right">{d.Proposed}</div>
                    </div>
                  </div>
                );
              })}
              {dailyComparison.length === 0 && <p className="text-sm text-warm-muted text-center py-4">No data</p>}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Room utilization comparison */}
      <Card className="border-warm shadow-warm">
        <CardContent className="p-5">
          <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><Building className="h-4 w-4 text-[#FF6B35]" /> Room Utilization Comparison</h4>
          <div className="space-y-3">
            {roomComparison.map((r) => {
              const max = Math.max(r.Original, r.Proposed, 1);
              return (
                <div key={r.label}>
                  <div className="text-xs font-medium mb-1">{r.label}</div>
                  <div className="flex items-center gap-2 mb-1">
                    <div className="text-[10px] text-warm-muted w-16">Original</div>
                    <div className="flex-1 h-3 bg-cream-deep rounded overflow-hidden"><div className="h-full rounded transition-all duration-700" style={{ width: `${(r.Original / max) * 100}%`, background: COLORS.original }} /></div>
                    <div className="text-[10px] font-bold w-8 text-right">{r.Original}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-[10px] text-warm-muted w-16">Proposed</div>
                    <div className="flex-1 h-3 bg-cream-deep rounded overflow-hidden"><div className="h-full rounded transition-all duration-700" style={{ width: `${(r.Proposed / max) * 100}%`, background: COLORS.proposed }} /></div>
                    <div className="text-[10px] font-bold w-8 text-right">{r.Proposed}</div>
                  </div>
                </div>
              );
            })}
            {roomComparison.length === 0 && <p className="text-sm text-warm-muted text-center py-4">No data</p>}
          </div>
        </CardContent>
      </Card>

      {/* Invigilator workload */}
      <Card className="border-warm shadow-warm">
        <CardContent className="p-5">
          <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><UserCheck className="h-4 w-4 text-[#FF6B35]" /> Invigilator Workload Comparison</h4>
          <div className="space-y-3">
            {invComparison.map((i) => {
              const max = Math.max(i.Original, i.Proposed, 1);
              return (
                <div key={i.label}>
                  <div className="text-xs font-medium mb-1">{i.label}</div>
                  <div className="flex items-center gap-2 mb-1">
                    <div className="text-[10px] text-warm-muted w-16">Original</div>
                    <div className="flex-1 h-3 bg-cream-deep rounded overflow-hidden"><div className="h-full rounded transition-all duration-700" style={{ width: `${(i.Original / max) * 100}%`, background: COLORS.original }} /></div>
                    <div className="text-[10px] font-bold w-8 text-right">{i.Original}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-[10px] text-warm-muted w-16">Proposed</div>
                    <div className="flex-1 h-3 bg-cream-deep rounded overflow-hidden"><div className="h-full rounded transition-all duration-700" style={{ width: `${(i.Proposed / max) * 100}%`, background: COLORS.proposed }} /></div>
                    <div className="text-[10px] font-bold w-8 text-right">{i.Proposed}</div>
                  </div>
                </div>
              );
            })}
            {invComparison.length === 0 && <p className="text-sm text-warm-muted text-center py-4">No data</p>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DeltaCard({ label, delta, unit }: { label: string; delta: number; unit: string }) {
  const isZero = delta === 0;
  const isGood = label.includes('Waste') || label.includes('Load') ? delta < 0 : delta > 0;
  const color = isZero ? 'text-warm-muted' : isGood ? 'text-green-600' : 'text-red-600';
  const bg = isZero ? 'bg-cream' : isGood ? 'bg-green-50' : 'bg-red-50';
  const Icon = isZero ? Minus : delta > 0 ? TrendingUp : TrendingDown;
  return (
    <div className={`rounded-lg ${bg} p-3 border border-warm/50`}>
      <p className="text-[10px] text-warm-muted uppercase">{label}</p>
      <div className={`flex items-center gap-1 ${color} font-bold text-lg`}><Icon className="h-4 w-4" />{isZero ? '0' : (delta > 0 ? '+' : '') + delta}</div>
      <p className="text-[10px] text-warm-muted">{unit}</p>
    </div>
  );
}

function computeMetrics(assignments: AssignmentProposal[], exams: Exam[], rooms: Room[], timeSlots: TimeSlot[], invigilators: Invigilator[]) {
  const roomsUsed = new Set(assignments.map(a => a.roomId));
  const invsUsed = new Set(assignments.flatMap(a => a.invigilatorIds));
  const dates = new Set(assignments.map(a => timeSlots.find(s => s.id === a.timeSlotId)?.date).filter(Boolean));
  let capacityWaste = 0;
  for (const a of assignments) {
    const exam = exams.find(e => e.id === a.examId);
    const room = rooms.find(r => r.id === a.roomId);
    if (exam && room) capacityWaste += Math.max(0, room.capacity - exam.enrollmentCount);
  }
  const invLoad = new Map<string, number>();
  for (const a of assignments) { for (const inv of a.invigilatorIds) invLoad.set(inv, (invLoad.get(inv) ?? 0) + 1); }
  const maxInvLoad = invLoad.size ? Math.max(...invLoad.values()) : 0;
  return { scheduled: assignments.length, roomsUsed: roomsUsed.size, invigilatorsUsed: invsUsed.size, uniqueDates: dates.size, capacityWaste, maxInvLoad };
}
