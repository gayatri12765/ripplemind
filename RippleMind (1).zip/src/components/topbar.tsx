// Topbar with breadcrumbs, notifications, and menu toggle

'use client';

import { useState } from 'react';
import { useNav, PAGE_TITLES, type PageKey } from '@/lib/store';
import { useNotifications, useMarkNotificationRead } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Popover, PopoverContent, PopoverTrigger,
} from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Menu, Bell, Clock, LogOut, Shield } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

export function Topbar() {
  const { currentPage, pageParams, setSidebarOpen } = useNav();
  const { session, logout } = useAuth();
  const [notifOpen, setNotifOpen] = useState(false);
  // Only fetch notifications when the popover is opened (reduces initial API load)
  const { data: notifications } = useNotifications(notifOpen);
  const markRead = useMarkNotificationRead();
  const unread = notifications?.filter((n: any) => !n.read).length ?? 0;

  const title = PAGE_TITLES[currentPage as PageKey] ?? 'RippleMind';
  const subtitle = pageParams?.subtitle;

  return (
    <header className="sticky top-0 z-20 bg-white/95 backdrop-blur border-b border-warm">
      <div className="flex items-center justify-between gap-4 px-4 lg:px-6 h-16">
        <div className="flex items-center gap-3 min-w-0">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <div className="min-w-0">
            <h2 className="text-lg font-bold text-foreground truncate">{title}</h2>
            {subtitle ? (
              <p className="text-xs text-warm-muted truncate">{subtitle}</p>
            ) : (
              <div className="flex items-center gap-1 text-xs text-warm-muted">
                <Clock className="h-3 w-3" />
                <span>{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</span>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Notifications */}
          <Popover open={notifOpen} onOpenChange={setNotifOpen}>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                {unread > 0 && (
                  <span className="absolute top-1 right-1 h-4 min-w-4 px-1 rounded-full bg-[#D62828] text-white text-[10px] flex items-center justify-center font-bold">
                    {unread > 9 ? '9+' : unread}
                  </span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-0" align="end">
              <div className="p-3 border-b border-warm">
                <p className="font-semibold text-sm">Notifications</p>
                <p className="text-xs text-warm-muted">{unread} unread</p>
              </div>
              <ScrollArea className="h-72">
                {notifications && notifications.length > 0 ? (
                  <div className="divide-y divide-warm">
                    {notifications.slice(0, 20).map((n: any) => (
                      <button
                        key={n.id}
                        onClick={() => !n.read && markRead.mutate(n.id)}
                        className={cn(
                          'w-full text-left p-3 hover:bg-cream-deep transition-colors block',
                          !n.read && 'bg-orange-50/50'
                        )}
                      >
                        <div className="flex items-start gap-2">
                          <span className={cn(
                            'mt-1 h-2 w-2 rounded-full flex-shrink-0',
                            n.type === 'error' ? 'bg-red-500' :
                            n.type === 'warning' ? 'bg-amber-500' :
                            n.type === 'success' ? 'bg-green-500' : 'bg-blue-500'
                          )} />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground">{n.title}</p>
                            <p className="text-xs text-warm-muted mt-0.5">{n.message}</p>
                            <p className="text-[10px] text-warm-muted mt-1">
                              {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
                            </p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center text-sm text-warm-muted">No notifications</div>
                )}
              </ScrollArea>
            </PopoverContent>
          </Popover>

          {/* User avatar + logout */}
          <div className="flex items-center gap-2 pl-2 border-l border-warm">
            <Badge className="bg-gradient-to-r from-[#FF6B35] to-[#F77F00] text-white hidden sm:inline-flex">
              <Shield className="h-3 w-3 mr-1" /> Admin
            </Badge>
            <div className="rounded-full bg-gradient-to-br from-[#FF6B35] to-[#D62828] h-9 w-9 flex items-center justify-center text-white font-semibold text-sm shadow-warm">
              {(session?.name ?? 'AD').charAt(0).toUpperCase()}
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-medium text-foreground leading-tight max-w-[120px] truncate">{session?.name ?? 'Admin'}</p>
              <p className="text-[10px] text-warm-muted">Administrator</p>
            </div>
            <Button variant="ghost" size="icon" onClick={logout} title="Sign out" className="text-red-600 hover:text-red-700 hover:bg-red-50">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
