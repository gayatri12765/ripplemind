// Sidebar navigation component

'use client';

import { useNav, PAGE_GROUPS, type PageKey } from '@/lib/store';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  LayoutDashboard, BarChart3, FileText, Users, DoorOpen, Clock,
  UserCheck, Wand2, Calendar, AlertTriangle, FlaskConical, Share2,
  GitCompare, Sparkles, History, Settings, Waves, GraduationCap, Siren,
} from 'lucide-react';

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  LayoutDashboard, BarChart3, FileText, Users, DoorOpen, Clock,
  UserCheck, Wand2, Calendar, AlertTriangle, FlaskConical, Share2,
  GitCompare, Sparkles, History, Settings, GraduationCap, Siren,
};

export function Sidebar() {
  const { currentPage, navigate, sidebarOpen, setSidebarOpen } = useNav();

  return (
    <>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={cn(
          'fixed lg:sticky top-0 left-0 z-40 h-screen w-64 bg-cream border-r border-warm flex flex-col transition-transform lg:translate-x-0',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        {/* Logo */}
        <div className="p-5 border-b border-warm">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-gradient-to-br from-[#FF6B35] to-[#D62828] p-2 shadow-warm-md">
              <Waves className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground leading-tight">RippleMind</h1>
              <p className="text-[10px] text-warm-muted uppercase tracking-wider">Exam Scheduling</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 px-3 py-4">
          <nav className="space-y-6">
            {PAGE_GROUPS.map((group) => (
              <div key={group.label}>
                <p className="text-[10px] font-semibold text-warm-muted uppercase tracking-wider px-3 mb-2">
                  {group.label}
                </p>
                <div className="space-y-1">
                  {group.pages.map((page) => {
                    const Icon = ICONS[page.icon] ?? FileText;
                    const isActive = currentPage === page.key;
                    return (
                      <button
                        key={page.key}
                        onClick={() => {
                          navigate(page.key as PageKey);
                          setSidebarOpen(false);
                        }}
                        className={cn(
                          'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 text-left group',
                          isActive
                            ? 'bg-gradient-to-r from-[#FF6B35] to-[#F77F00] text-white shadow-warm-md glow-warm'
                            : 'text-foreground hover:bg-accent hover:translate-x-1'
                        )}
                      >
                        <Icon className={cn('h-4 w-4 flex-shrink-0 transition-transform', isActive ? '' : 'group-hover:scale-110')} />
                        <span className="truncate">{page.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </nav>
        </ScrollArea>

        {/* Footer */}
        <div className="p-4 border-t border-warm">
          <p className="text-[10px] text-warm-muted">
            RippleMind v1.0 · Part 1+2
          </p>
        </div>
      </aside>
    </>
  );
}
