// Lightweight CSS-based charts — zero dependencies, uses ~0 extra memory.
// Replaces Recharts for the 4GB sandbox environment.

'use client';

import { type ReactNode } from 'react';

// --- Bar Chart (vertical) ---
export function CSSBarChart({ data, height = 240 }: {
  data: { label: string; values: { name: string; value: number; color: string }[] }[];
  height?: number;
}) {
  const max = Math.max(...data.flatMap(d => d.values.map(v => v.value)), 1);
  return (
    <div className="w-full" style={{ height }}>
      <div className="flex items-end justify-around gap-2 h-full pb-8 relative">
        {data.map((d, i) => (
          <div key={i} className="flex flex-col items-center flex-1 h-full justify-end relative">
            <div className="flex items-end gap-1 h-full w-full justify-center">
              {d.values.map((v, j) => (
                <div key={j} className="flex flex-col items-center justify-end h-full" style={{ width: `${100 / d.values.length}%` }}>
                  <div className="text-[10px] font-bold mb-0.5" style={{ color: v.color }}>{v.value}</div>
                  <div
                    className="w-full rounded-t-md transition-all duration-700 ease-out hover:opacity-80"
                    style={{ height: `${(v.value / max) * 100}%`, background: v.color, minHeight: v.value > 0 ? '4px' : 0 }}
                  />
                </div>
              ))}
            </div>
            <div className="absolute -bottom-6 text-[10px] text-warm-muted text-center w-full truncate" style={{ fontSize: '10px' }}>{d.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// --- Horizontal Bar Chart ---
export function CSSHBarChart({ data, height = 240 }: {
  data: { label: string; value: number; color?: string }[];
  height?: number;
}) {
  const max = Math.max(...data.map(d => d.value), 1);
  return (
    <div className="w-full space-y-2" style={{ height, overflowY: 'auto' }}>
      {data.map((d, i) => (
        <div key={i} className="flex items-center gap-2">
          <div className="text-xs text-warm-muted w-24 truncate">{d.label}</div>
          <div className="flex-1 h-6 bg-cream-deep rounded-md overflow-hidden">
            <div
              className="h-full rounded-md transition-all duration-700 ease-out flex items-center justify-end px-2"
              style={{ width: `${(d.value / max) * 100}%`, background: d.color ?? '#FF6B35' }}
            >
              <span className="text-[10px] font-bold text-white">{d.value}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// --- Grouped Horizontal Bar Chart (for comparisons) ---
export function CSSGroupedHBarChart({ data, height = 280 }: {
  data: { label: string; values: { name: string; value: number; color: string }[] }[];
  height?: number;
}) {
  const max = Math.max(...data.flatMap(d => d.values.map(v => v.value)), 1);
  return (
    <div className="w-full space-y-3" style={{ height, overflowY: 'auto' }}>
      {data.map((d, i) => (
        <div key={i}>
          <div className="text-xs font-medium mb-1">{d.label}</div>
          <div className="space-y-1">
            {d.values.map((v, j) => (
              <div key={j} className="flex items-center gap-2">
                <div className="text-[10px] text-warm-muted w-20 truncate">{v.name}</div>
                <div className="flex-1 h-4 bg-cream-deep rounded overflow-hidden">
                  <div
                    className="h-full rounded transition-all duration-700"
                    style={{ width: `${(v.value / max) * 100}%`, background: v.color }}
                  />
                </div>
                <div className="text-[10px] font-bold w-8 text-right">{v.value}</div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// --- Pie Chart (CSS conic-gradient) ---
export function CSSPieChart({ data, size = 180 }: {
  data: { name: string; value: number; color: string }[];
  size?: number;
}) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  // Compute segments using reduce (no mutation)
  const { segments, gradient } = data.reduce<{ segments: {start: number; end: number; color: string}[]; gradient: string }>(
    (acc, d) => {
      const pct = (d.value / total) * 100;
      const start = acc.segments.length > 0 ? acc.segments[acc.segments.length - 1].end : 0;
      const end = start + pct;
      return {
        segments: [...acc.segments, { start, end, color: d.color }],
        gradient: acc.gradient ? `${acc.gradient}, ${d.color} ${start}% ${end}%` : `${d.color} ${start}% ${end}%`,
      };
    },
    { segments: [], gradient: '' }
  );

  return (
    <div className="flex items-center gap-4 flex-wrap">
      <div
        className="rounded-full shadow-warm flex-shrink-0"
        style={{
          width: size,
          height: size,
          background: `conic-gradient(${gradient})`,
        }}
      />
      <div className="space-y-1">
        {data.map((d, i) => (
          <div key={i} className="flex items-center gap-2 text-xs">
            <span className="w-3 h-3 rounded-sm" style={{ background: d.color }} />
            <span className="text-warm-muted">{d.name}</span>
            <span className="font-bold">{d.value}</span>
            <span className="text-warm-muted">({((d.value / total) * 100).toFixed(0)}%)</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// --- Progress Bar ---
export function CSSProgressBar({ value, max = 100, color = '#FF6B35', label, showValue = true }: {
  value: number;
  max?: number;
  color?: string;
  label?: string;
  showValue?: boolean;
}) {
  const pct = Math.min(100, (value / max) * 100);
  return (
    <div className="w-full">
      {label && (
        <div className="flex justify-between text-xs mb-1">
          <span className="text-warm-muted">{label}</span>
          {showValue && <span className="font-bold">{value}{max === 100 ? '%' : ''}</span>}
        </div>
      )}
      <div className="h-2 bg-cream-deep rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

// --- Stat Card (lightweight) ---
export function SimpleStat({ label, value, subtitle, color = '#FF6B35', icon }: {
  label: string;
  value: string | number;
  subtitle?: string;
  color?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="rounded-xl border-2 p-4 transition-all hover:scale-[1.02]" style={{ borderColor: `${color}40`, background: `${color}08` }}>
      <div className="flex items-center justify-between">
        <p className="text-xs text-warm-muted uppercase tracking-wide">{label}</p>
        {icon && <div className="rounded-lg p-1.5" style={{ background: color, color: 'white' }}>{icon}</div>}
      </div>
      <p className="text-3xl font-bold mt-1" style={{ color }}>{value}</p>
      {subtitle && <p className="text-[10px] text-warm-muted mt-1">{subtitle}</p>}
    </div>
  );
}
