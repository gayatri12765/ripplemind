// StudentTopbar — topbar for student-role users with logout

'use client';

import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { GraduationCap, LogOut, Clock, Bell } from 'lucide-react';
import { useNotifications } from '@/lib/api';
import { useState } from 'react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

export function StudentTopbar() {
  const { session, logout } = useAuth();
  const [notifOpen, setNotifOpen] = useState(false);
  const { data: notifications } = useNotifications(notifOpen);
  const unread = notifications?.filter((n: any) => !n.read).length ?? 0;

  return (
    <header className="sticky top-0 z-20 bg-white/95 backdrop-blur border-b border-warm">
      <div className="flex items-center justify-between gap-4 px-4 lg:px-6 h-16">
        <div className="flex items-center gap-3 min-w-0">
          <div className="lg:hidden rounded-xl bg-gradient-to-br from-[#FF6B35] to-[#D62828] p-2 shadow-warm">
            <GraduationCap className="h-5 w-5 text-white" />
          </div>
          <div className="min-w-0">
            <h2 className="text-lg font-bold text-foreground truncate">My Exam Schedule</h2>
            <div className="flex items-center gap-1 text-xs text-warm-muted">
              <Clock className="h-3 w-3" />
              <span>{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Student badge */}
          <Badge className="bg-gradient-to-r from-[#FF6B35] to-[#F77F00] text-white hidden sm:inline-flex">
            <GraduationCap className="h-3 w-3 mr-1" /> Student
          </Badge>

          {/* Notifications */}
          <Popover open={notifOpen} onOpenChange={setNotifOpen}>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                {unread > 0 && (
                  <span className="absolute top-1 right-1 h-4 min-w-4 px-1 rounded-full bg-[#D62828] text-white text-[10px] flex items-center justify-center font-bold">
                    {unread > 9 ? '9+' : unread}
                  </span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-0" align="end">
              <div className="p-3 border-b border-warm">
                <p className="font-semibold text-sm">Notifications</p>
                <p className="text-xs text-warm-muted">{unread} unread</p>
              </div>
              <ScrollArea className="h-72">
                {notifications && notifications.length > 0 ? (
                  <div className="divide-y divide-warm">
                    {notifications.slice(0, 20).map((n: any) => (
                      <button
                        key={n.id}
                        className={cn(
                          'w-full text-left p-3 hover:bg-cream-deep transition-colors block',
                          !n.read && 'bg-orange-50/50'
                        )}
                      >
                        <div className="flex items-start gap-2">
                          <span className={cn(
                            'mt-1 h-2 w-2 rounded-full flex-shrink-0',
                            n.type === 'error' ? 'bg-red-500' :
                            n.type === 'warning' ? 'bg-amber-500' :
                            n.type === 'success' ? 'bg-green-500' : 'bg-blue-500'
                          )} />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground">{n.title}</p>
                            <p className="text-xs text-warm-muted mt-0.5">{n.message}</p>
                            <p className="text-[10px] text-warm-muted mt-1">
                              {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
                            </p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center text-sm text-warm-muted">No notifications</div>
                )}
              </ScrollArea>
            </PopoverContent>
          </Popover>

          {/* User info + logout */}
          <div className="flex items-center gap-2 pl-2 border-l border-warm">
            <div className="hidden sm:block text-right">
              <p className="text-sm font-medium text-foreground leading-tight max-w-[140px] truncate">{session?.name}</p>
              <p className="text-[10px] text-warm-muted truncate max-w-[140px]">{session?.groupName ?? 'Student'}</p>
            </div>
            <div className="rounded-full bg-gradient-to-br from-[#FF6B35] to-[#D62828] h-9 w-9 flex items-center justify-center text-white font-semibold text-sm shadow-warm">
              {session?.name?.charAt(0).toUpperCase() ?? 'S'}
            </div>
            <Button variant="ghost" size="icon" onClick={logout} title="Sign out" className="text-red-600 hover:text-red-700 hover:bg-red-50">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
