// Shared UI components for RippleMind pages.

'use client';

import { type ReactNode } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Inbox, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

// --- Stat Card ---
export function StatCard({ title, value, icon, accent = 'orange', subtitle, trend }: {
  title: string;
  value: string | number;
  icon: ReactNode;
  accent?: 'orange' | 'red' | 'green' | 'blue' | 'amber';
  subtitle?: string;
  trend?: { value: number; label: string };
}) {
  const accents: Record<string, string> = {
    orange: 'bg-gradient-to-br from-[#FF6B35] to-[#F77F00] text-white',
    red: 'bg-gradient-to-br from-[#D62828] to-[#EF4444] text-white',
    green: 'bg-gradient-to-br from-[#2D6A4F] to-[#52B788] text-white',
    blue: 'bg-gradient-to-br from-[#1E6091] to-[#3C91E6] text-white',
    amber: 'bg-gradient-to-br from-[#FCBF49] to-[#F77F00] text-white',
  };
  return (
    <Card className="overflow-hidden border-warm shadow-warm hover:shadow-warm-md hover:-translate-y-0.5 transition-all duration-200 fade-in-up">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-sm font-medium text-warm-muted">{title}</p>
            <p className="text-3xl font-bold mt-1 text-foreground">{value}</p>
            {subtitle && <p className="text-xs text-warm-muted mt-1">{subtitle}</p>}
            {trend && (
              <p className={cn('text-xs mt-2 font-medium', trend.value >= 0 ? 'text-green-600' : 'text-red-600')}>
                {trend.value >= 0 ? '↑' : '↓'} {Math.abs(trend.value)} {trend.label}
              </p>
            )}
          </div>
          <div className={cn('rounded-xl p-3 shadow-sm hover:scale-110 transition-transform duration-200', accents[accent])}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// --- Loading State ---
export function LoadingState({ message = 'Loading…', rows = 3 }: { message?: string; rows?: number }) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-warm-muted">
        <Loader2 className="h-4 w-4 animate-spin text-[#FF6B35]" />
        <span className="text-sm">{message}</span>
      </div>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-16 w-full rounded-lg shimmer" />
      ))}
    </div>
  );
}

// --- Empty State ---
export function EmptyState({ title, description, action, icon }: {
  title: string;
  description?: string;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
      <div className="rounded-full bg-cream-deep p-4 mb-4">
        {icon ?? <Inbox className="h-8 w-8 text-warm-muted" />}
      </div>
      <h3 className="text-lg font-semibold text-foreground">{title}</h3>
      {description && <p className="text-sm text-warm-muted mt-1 max-w-md">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

// --- Error State ---
export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <Alert className="border-red-200 bg-red-50">
      <AlertCircle className="h-4 w-4 text-red-600" />
      <AlertDescription className="text-red-800">
        <span className="font-medium">Error:</span> {message}
        {onRetry && (
          <button onClick={onRetry} className="ml-2 underline text-red-700 hover:text-red-900">
            Retry
          </button>
        )}
      </AlertDescription>
    </Alert>
  );
}

// --- Page Header ---
export function PageHeader({ title, description, breadcrumbs, actions }: {
  title: string;
  description?: string;
  breadcrumbs?: { label: string; href?: string }[];
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6">
      {breadcrumbs && breadcrumbs.length > 0 && (
        <nav className="text-xs text-warm-muted mb-2 flex items-center gap-1">
          {breadcrumbs.map((b, i) => (
            <span key={i} className="flex items-center gap-1">
              {i > 0 && <span className="opacity-50">/</span>}
              <span className={i === breadcrumbs.length - 1 ? 'text-foreground font-medium' : ''}>{b.label}</span>
            </span>
          ))}
        </nav>
      )}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{title}</h1>
          {description && <p className="text-sm text-warm-muted mt-1 max-w-2xl">{description}</p>}
        </div>
        {actions && <div className="flex items-center gap-2 flex-shrink-0">{actions}</div>}
      </div>
    </div>
  );
}

// --- Severity Badge ---
export function SeverityBadge({ severity }: { severity: 'critical' | 'warning' | 'info' }) {
  const styles = {
    critical: 'bg-red-100 text-red-800 border-red-200',
    warning: 'bg-amber-100 text-amber-800 border-amber-200',
    info: 'bg-blue-100 text-blue-800 border-blue-200',
  };
  return (
    <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border', styles[severity])}>
      {severity}
    </span>
  );
}

// --- Status Badge ---
export function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    scheduled: 'bg-green-100 text-green-800 border-green-200',
    unscheduled: 'bg-gray-100 text-gray-800 border-gray-200',
    analyzed: 'bg-blue-100 text-blue-800 border-blue-200',
    approved: 'bg-green-100 text-green-800 border-green-200',
    discarded: 'bg-red-100 text-red-800 border-red-200',
    draft: 'bg-amber-100 text-amber-800 border-amber-200',
  };
  return (
    <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border', styles[status] ?? 'bg-gray-100 text-gray-800 border-gray-200')}>
      {status}
    </span>
  );
}

// --- Section Card ---
export function SectionCard({ title, description, children, actions }: {
  title?: string;
  description?: string;
  children: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <Card className="border-warm shadow-warm">
      {title && (
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-lg">{title}</CardTitle>
              {description && <p className="text-sm text-warm-muted mt-1">{description}</p>}
            </div>
            {actions}
          </div>
        </CardHeader>
      )}
      <CardContent>{children}</CardContent>
    </Card>
  );
}
