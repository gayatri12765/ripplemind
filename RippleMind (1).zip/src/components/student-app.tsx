// StudentApp — simplified shell for student-role users.
// Shows only the Student Portal with their group pre-selected.
// Includes a minimal topbar with logout.

'use client';

import { useAuth } from '@/lib/auth';
import { StudentPortalPage } from '@/pages/student-portal';
import { StudentTopbar } from '@/components/student-topbar';
import { GraduationCap, Waves } from 'lucide-react';

export function StudentApp() {
  const { session } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <StudentTopbar />
      <div className="flex-1 flex">
        {/* Simplified sidebar for students */}
        <aside className="hidden lg:flex w-16 lg:w-56 bg-cream border-r border-warm flex-col">
          <div className="p-4 border-b border-warm">
            <div className="flex items-center gap-2">
              <div className="rounded-xl bg-gradient-to-br from-[#FF6B35] to-[#D62828] p-2 shadow-warm">
                <Waves className="h-5 w-5 text-white" />
              </div>
              <div className="hidden lg:block">
                <h1 className="text-sm font-bold text-foreground leading-tight">RippleMind</h1>
                <p className="text-[10px] text-warm-muted uppercase tracking-wider">Student Portal</p>
              </div>
            </div>
          </div>
          <div className="flex-1 p-3">
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium bg-gradient-to-r from-[#FF6B35] to-[#F77F00] text-white shadow-warm-md">
              <GraduationCap className="h-4 w-4 flex-shrink-0" />
              <span className="hidden lg:inline truncate">My Exams</span>
            </button>
          </div>
          <div className="p-4 border-t border-warm hidden lg:block">
            <p className="text-[10px] text-warm-muted">
              Logged in as student
            </p>
          </div>
        </aside>
        <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">
          <StudentPortalPage />
        </main>
      </div>
    </div>
  );
}
