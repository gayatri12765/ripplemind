import type { Metadata } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import { Providers } from "./providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "RippleMind — AI-Driven Examination Timetable Simulation",
  description: "Create examination timetables, detect scheduling conflicts, allocate rooms and invigilators, and simulate changes before applying them.",
  keywords: ["RippleMind", "examination", "timetable", "scheduling", "CP-SAT", "OR-Tools", "conflict detection"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} antialiased bg-background text-foreground`}
      >
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
