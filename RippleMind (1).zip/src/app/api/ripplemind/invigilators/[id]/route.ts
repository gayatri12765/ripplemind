// /api/ripplemind/invigilators/[id] — PUT, DELETE
import { db, ok, fail, readBody, rowToInvigilator, validatePositiveInt } from '@/lib/api-helpers';
import { stringifyJSON } from '@/lib/json';

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await readBody<Record<string, unknown>>(req);
  if (!body) return fail('Invalid JSON body');
  try {
    const data: Record<string, unknown> = {};
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim();
    if (body.email !== undefined) data.email = body.email;
    if (body.department !== undefined) data.department = body.department;
    if (body.maxWorkload !== undefined) data.maxWorkload = validatePositiveInt(body.maxWorkload, 'Max workload');
    if (Array.isArray(body.availability)) data.availability = stringifyJSON(body.availability);
    if (typeof body.isAvailable === 'boolean') data.isAvailable = body.isAvailable;
    const row = await db.invigilator.update({ where: { id }, data });
    return ok({ invigilator: rowToInvigilator(row) });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    // Check no published assignments use this invigilator
    const all = await db.examAssignment.findMany();
    const used = all.filter((a) => {
      try {
        const ids = JSON.parse(a.invigilatorIds || '[]') as string[];
        return ids.includes(id);
      } catch {
        return false;
      }
    });
    if (used.length > 0) return fail(`Cannot delete: ${used.length} assignments reference this invigilator`, 409);
    await db.invigilator.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
