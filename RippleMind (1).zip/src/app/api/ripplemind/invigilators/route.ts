// /api/ripplemind/invigilators — GET, POST
import { db, ok, fail, readBody, rowToInvigilator, validatePositiveInt } from '@/lib/api-helpers';
import { stringifyJSON } from '@/lib/json';

export async function GET() {
  try {
    const rows = await db.invigilator.findMany({ orderBy: { name: 'asc' } });
    return ok({ invigilators: rows.map(rowToInvigilator) });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function POST(req: Request) {
  const body = await readBody<{ name?: string; email?: string; department?: string; maxWorkload?: number; availability?: string[]; isAvailable?: boolean }>(req);
  if (!body) return fail('Invalid JSON body');
  if (!body.name?.trim()) return fail('Name is required');
  let maxWorkload: number;
  try {
    maxWorkload = validatePositiveInt(body.maxWorkload ?? 3, 'Max workload');
  } catch (e) {
    return fail((e as Error).message);
  }
  try {
    const row = await db.invigilator.create({
      data: {
        name: body.name.trim(),
        email: body.email ?? null,
        department: body.department ?? null,
        maxWorkload,
        availability: stringifyJSON(body.availability ?? []),
        isAvailable: body.isAvailable ?? true,
      },
    });
    return ok({ invigilator: rowToInvigilator(row) }, 201);
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
