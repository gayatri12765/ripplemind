// /api/ripplemind/student-groups/[id] — PUT, DELETE
import { db, ok, fail, readBody, rowToStudentGroup, validatePositiveInt } from '@/lib/api-helpers';

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await readBody<Record<string, unknown>>(req);
  if (!body) return fail('Invalid JSON body');
  try {
    const data: Record<string, unknown> = {};
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim();
    if (typeof body.code === 'string' && body.code.trim()) {
      const conflict = await db.studentGroup.findFirst({ where: { code: body.code, NOT: { id } } });
      if (conflict) return fail('Code already in use', 409);
      data.code = body.code.trim();
    }
    if (body.studentCount !== undefined) data.studentCount = validatePositiveInt(body.studentCount, 'Student count');
    if (body.program !== undefined) data.program = body.program;
    if (body.year !== undefined) data.year = body.year;
    const row = await db.studentGroup.update({ where: { id }, data });
    return ok({ studentGroup: rowToStudentGroup(row) });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const examCount = await db.exam.count({ where: { studentGroupId: id } });
    if (examCount > 0) return fail(`Cannot delete: ${examCount} exams reference this group`, 409);
    await db.studentGroup.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
