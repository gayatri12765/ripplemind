// /api/ripplemind/student-groups — GET, POST
import { db, ok, fail, readBody, rowToStudentGroup, validatePositiveInt } from '@/lib/api-helpers';

export async function GET() {
  try {
    const rows = await db.studentGroup.findMany({
      orderBy: { name: 'asc' },
      include: { _count: { select: { exams: true } } },
    });
    const groups = rows.map((r) => ({ ...rowToStudentGroup(r), examCount: r._count.exams }));
    return ok({ studentGroups: groups });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function POST(req: Request) {
  const body = await readBody<{ name?: string; code?: string; studentCount?: number; program?: string; year?: number }>(req);
  if (!body) return fail('Invalid JSON body');
  if (!body.name?.trim()) return fail('Name is required');
  if (!body.code?.trim()) return fail('Code is required');
  let studentCount: number;
  try {
    studentCount = validatePositiveInt(body.studentCount, 'Student count');
  } catch (e) {
    return fail((e as Error).message);
  }
  try {
    const existing = await db.studentGroup.findUnique({ where: { code: body.code! } });
    if (existing) return fail('Code already exists', 409);
    const row = await db.studentGroup.create({
      data: {
        name: body.name.trim(),
        code: body.code.trim(),
        studentCount,
        program: body.program ?? null,
        year: body.year ?? null,
      },
    });
    return ok({ studentGroup: rowToStudentGroup(row) }, 201);
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
