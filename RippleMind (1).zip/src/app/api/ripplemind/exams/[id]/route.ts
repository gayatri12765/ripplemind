// /api/ripplemind/exams/[id] — GET, PUT, DELETE
import { db, ok, fail, readBody, rowToExam, validatePositiveInt } from '@/lib/api-helpers';
import { stringifyJSON } from '@/lib/json';

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const row = await db.exam.findUnique({
      where: { id },
      include: { studentGroup: true, assignment: { include: { room: true, timeSlot: true } } },
    });
    if (!row) return fail('Exam not found', 404);
    return ok({ exam: await rowToExam(row) });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await readBody<Record<string, unknown>>(req);
  if (!body) return fail('Invalid JSON body');

  try {
    const existing = await db.exam.findUnique({ where: { id } });
    if (!existing) return fail('Exam not found', 404);

    const data: Record<string, unknown> = {};
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim();
    if (typeof body.subjectCode === 'string' && body.subjectCode.trim()) {
      const conflict = await db.exam.findFirst({ where: { subjectCode: body.subjectCode, NOT: { id } } });
      if (conflict) return fail('Subject code already in use', 409);
      data.subjectCode = body.subjectCode.trim();
    }
    if (body.duration !== undefined) {
      const d = validatePositiveInt(body.duration, 'Duration');
      if (d < 30 || d > 480) return fail('Duration must be 30-480 minutes');
      data.duration = d;
    }
    if (body.enrollmentCount !== undefined) {
      data.enrollmentCount = validatePositiveInt(body.enrollmentCount, 'Enrollment count');
    }
    if (typeof body.examType === 'string') data.examType = body.examType;
    if (body.notes !== undefined) data.notes = body.notes;
    if (body.studentGroupId !== undefined) {
      const sg = await db.studentGroup.findUnique({ where: { id: body.studentGroupId as string } });
      if (!sg) return fail('Student group not found', 404);
      data.studentGroupId = body.studentGroupId;
    }
    if (Array.isArray(body.preferredSlots)) data.preferredSlots = stringifyJSON(body.preferredSlots);
    if (Array.isArray(body.preferredRooms)) data.preferredRooms = stringifyJSON(body.preferredRooms);

    const row = await db.exam.update({
      where: { id },
      data,
      include: { studentGroup: true, assignment: { include: { room: true, timeSlot: true } } },
    });
    return ok({ exam: await rowToExam(row) });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    await db.exam.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
