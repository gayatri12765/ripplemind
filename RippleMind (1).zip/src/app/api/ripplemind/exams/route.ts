// GET /api/ripplemind/exams  |  POST /api/ripplemind/exams
import { db, ok, fail, readBody, rowToExam, validatePositiveInt } from '@/lib/api-helpers';
import { stringifyJSON } from '@/lib/json';

export async function GET() {
  try {
    const rows = await db.exam.findMany({
      include: { studentGroup: true, assignment: { include: { room: true, timeSlot: true } } },
      orderBy: { createdAt: 'desc' },
    });
    const exams = await Promise.all(rows.map(rowToExam));
    return ok({ exams });
  } catch (err) {
    return fail(`Failed to list exams: ${(err as Error).message}`, 500);
  }
}

export async function POST(req: Request) {
  const body = await readBody<{
    name?: string;
    subjectCode?: string;
    duration?: number;
    studentGroupId?: string;
    enrollmentCount?: number;
    examType?: string;
    notes?: string;
    preferredSlots?: string[];
    preferredRooms?: string[];
  }>(req);

  if (!body) return fail('Invalid JSON body');
  if (!body.name?.trim()) return fail('Exam name is required');
  if (!body.subjectCode?.trim()) return fail('Subject code is required');
  if (!body.studentGroupId) return fail('Student group is required');

  let duration: number;
  let enrollment: number;
  try {
    duration = validatePositiveInt(body.duration, 'Duration');
    if (duration < 30 || duration > 480) throw new Error('Duration must be between 30 and 480 minutes');
    enrollment = validatePositiveInt(body.enrollmentCount, 'Enrollment count');
  } catch (e) {
    return fail((e as Error).message);
  }

  try {
    const sg = await db.studentGroup.findUnique({ where: { id: body.studentGroupId } });
    if (!sg) return fail('Student group not found', 404);
    const existing = await db.exam.findUnique({ where: { subjectCode: body.subjectCode! } });
    if (existing) return fail('Subject code already exists', 409);

    const exam = await db.exam.create({
      data: {
        name: body.name.trim(),
        subjectCode: body.subjectCode.trim(),
        duration,
        studentGroupId: body.studentGroupId,
        enrollmentCount: enrollment,
        examType: body.examType ?? 'final',
        notes: body.notes ?? null,
        preferredSlots: stringifyJSON(body.preferredSlots ?? []),
        preferredRooms: stringifyJSON(body.preferredRooms ?? []),
      },
      include: { studentGroup: true, assignment: { include: { room: true, timeSlot: true } } },
    });
    return ok({ exam: await rowToExam(exam) }, 201);
  } catch (err) {
    return fail(`Failed to create exam: ${(err as Error).message}`, 500);
  }
}
