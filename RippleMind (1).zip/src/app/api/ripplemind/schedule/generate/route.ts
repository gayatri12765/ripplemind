// POST /api/ripplemind/schedule/generate — run the solver
// Uses ONLY the greedy solver (lightweight, synchronous, no memory issues)
import { ok, fail, readBody, loadContext, writeAuditLog } from '@/lib/api-helpers';
import { solveGreedy, isORToolsAvailable } from '@/lib/greedy-solver';
import type { SolverConfig, SolverObjectiveWeights } from '@/lib/types';

const DEFAULT_WEIGHTS: SolverObjectiveWeights = {
  minimizeChangedExams: 10,
  minimizeRoomChanges: 8,
  minimizeCapacityWaste: 1,
  respectPreferredSlots: 5,
  balanceInvigilatorWorkload: 4,
};

export async function POST(req: Request) {
  const body = await readBody<{
    examIds?: string[];
    timeLimitMs?: number;
    objectiveWeights?: Partial<SolverObjectiveWeights>;
    solverMode?: 'cp' | 'greedy';
  }>(req);

  try {
    const ctx = await loadContext();
    const examsToSchedule = body?.examIds?.length
      ? ctx.exams.filter((e) => body.examIds!.includes(e.id))
      : ctx.exams;

    const config: SolverConfig = {
      timeLimitMs: body?.timeLimitMs ?? 5000,
      maxAlternatives: 1,
      objectiveWeights: { ...DEFAULT_WEIGHTS, ...body?.objectiveWeights },
    };

    const fixedAssignments = ctx.assignments
      .filter((a) => !examsToSchedule.find((e) => e.id === a.examId))
      .map((a) => ({
        examId: a.examId,
        timeSlotId: a.timeSlotId,
        roomId: a.roomId,
        invigilatorIds: a.invigilatorIds,
      }));

    // Always use greedy solver (fast, synchronous, no memory issues)
    const solution = solveGreedy({
      exams: examsToSchedule,
      rooms: ctx.rooms,
      timeSlots: ctx.timeSlots,
      invigilators: ctx.invigilators,
      studentGroups: ctx.studentGroups,
      config,
      fixedAssignments,
      maxIterations: 50,
    });

    await writeAuditLog({
      action: 'schedule.generated',
      category: 'schedule',
      summary: `Solver run (greedy): ${solution.feasible ? 'feasible' : 'infeasible'} — ${solution.assignments.length}/${examsToSchedule.length} scheduled`,
      details: { metrics: solution.metrics, conflicts: solution.conflicts.length, solverMode: 'greedy', orToolsAvailable: isORToolsAvailable() },
    });

    return ok({ solution, solverUsed: isORToolsAvailable() ? 'or-tools-cp-sat' : 'greedy-fallback' });
  } catch (err) {
    return fail(`Solver failed: ${(err as Error).message}`, 500);
  }
}
