// POST /api/ripplemind/schedule/apply — apply a solver solution to the published timetable (atomic).
// Uses a transaction. Refuses if critical conflicts exist.
// Pushes student-facing change notifications for affected groups.
import { db, ok, fail, readBody, writeAuditLog, pushNotification, loadContext } from '@/lib/api-helpers';
import { detectConflicts } from '@/lib/conflicts';
import { stringifyJSON } from '@/lib/json';
import type { AssignmentProposal } from '@/lib/types';

export async function POST(req: Request) {
  const body = await readBody<{
    assignments: AssignmentProposal[];
    mode?: 'replace' | 'merge';
  }>(req);

  if (!body?.assignments) return fail('assignments array is required');

  try {
    const ctx = await loadContext();
    const conflicts = detectConflicts({
      assignments: body.assignments,
      context: ctx,
    });
    const critical = conflicts.filter((c) => c.severity === 'critical');
    if (critical.length > 0) {
      return fail(
        `Refusing to apply: ${critical.length} critical conflict(s) detected. Resolve them first.`,
        409,
        { conflicts: critical }
      );
    }

    // Snapshot the old assignments so we can compute what changed for student notifications
    const oldAssignments = new Map(ctx.assignments.map((a) => [a.examId, a]));

    await db.$transaction(async (tx) => {
      if (body.mode === 'replace') {
        await tx.examAssignment.deleteMany({});
      } else {
        const examIds = body.assignments.map((a) => a.examId);
        await tx.examAssignment.deleteMany({ where: { examId: { in: examIds } } });
      }
      for (const a of body.assignments) {
        const slot = ctx.timeSlots.find((t) => t.id === a.timeSlotId);
        if (!slot) continue;
        await tx.examAssignment.create({
          data: {
            examId: a.examId,
            timeSlotId: a.timeSlotId,
            roomId: a.roomId,
            date: slot.date,
            invigilatorIds: stringifyJSON(a.invigilatorIds ?? []),
            isPublished: true,
          },
        });
        await tx.exam.update({ where: { id: a.examId }, data: { status: 'scheduled' } });
      }
      const scheduledIds = new Set(body.assignments.map((a) => a.examId));
      const allExamIds = ctx.exams.map((e) => e.id);
      const unscheduledIds = allExamIds.filter((id) => !scheduledIds.has(id));
      if (unscheduledIds.length) {
        await tx.exam.updateMany({
          where: { id: { in: unscheduledIds } },
          data: { status: 'unscheduled' },
        });
      }
    });

    // Compute changes for student notifications
    const changedExams: string[] = [];
    const newExams: string[] = [];
    for (const a of body.assignments) {
      const old = oldAssignments.get(a.examId);
      if (!old) {
        newExams.push(a.examId);
      } else if (old.roomId !== a.roomId || old.timeSlotId !== a.timeSlotId) {
        changedExams.push(a.examId);
      }
    }

    // Determine affected student groups
    const affectedGroupIds = new Set<string>();
    for (const examId of [...changedExams, ...newExams]) {
      const exam = ctx.exams.find((e) => e.id === examId);
      if (exam) affectedGroupIds.add(exam.studentGroupId);
    }

    await writeAuditLog({
      action: 'schedule.applied',
      category: 'schedule',
      summary: `Applied ${body.assignments.length} assignment(s) (${body.mode ?? 'merge'} mode) — ${changedExams.length} changed, ${newExams.length} new`,
      details: {
        count: body.assignments.length,
        mode: body.mode ?? 'merge',
        changedExams: changedExams.length,
        newExams: newExams.length,
        affectedGroups: Array.from(affectedGroupIds),
      },
    });
    await pushNotification({
      type: 'success',
      title: 'Timetable published',
      message: `${body.assignments.length} exam assignments applied to the published timetable.`,
    });

    // Push a student-facing notification per affected group
    for (const groupId of affectedGroupIds) {
      const group = ctx.studentGroups.find((g) => g.id === groupId);
      const groupChanged = changedExams.filter((eid) => ctx.exams.find((e) => e.id === eid)?.studentGroupId === groupId).length;
      const groupNew = newExams.filter((eid) => ctx.exams.find((e) => e.id === eid)?.studentGroupId === groupId).length;
      if (groupChanged > 0 || groupNew > 0) {
        await pushNotification({
          type: 'info',
          title: `Timetable updated for ${group?.name ?? 'your group'}`,
          message: `${groupChanged} exam assignment(s) changed, ${groupNew} new assignment(s). Check the Student Portal for details.`,
        });
      }
    }

    return ok({ applied: body.assignments.length, conflicts, changedExams: changedExams.length, newExams: newExams.length });
  } catch (err) {
    return fail(`Failed to apply: ${(err as Error).message}`, 500);
  }
}
