// GET /api/ripplemind/assignments — list all published assignments (the timetable)
import { ok, fail, loadContext } from '@/lib/api-helpers';

export async function GET() {
  try {
    const ctx = await loadContext();
    return ok({ assignments: ctx.assignments });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
