// POST /api/ripplemind/emergency/outage
// Simulate a room outage: mark a room as unavailable and re-schedule all affected exams.
// Uses the greedy solver for fast results. Returns the proposed revised timetable.
// Does NOT modify the published timetable until the admin applies it.

import { db, ok, fail, readBody, loadContext, writeAuditLog, pushNotification } from '@/lib/api-helpers';
import { solveGreedy, isORToolsAvailable } from '@/lib/greedy-solver';
import type { SolverConfig, SolverObjectiveWeights } from '@/lib/types';

const DEFAULT_WEIGHTS: SolverObjectiveWeights = {
  minimizeChangedExams: 100, // Heavy weight on stability for emergencies
  minimizeRoomChanges: 50,
  minimizeCapacityWaste: 1,
  respectPreferredSlots: 5,
  balanceInvigilatorWorkload: 4,
};

export async function POST(req: Request) {
  const body = await readBody<{
    roomId?: string;
    reason?: string;
    useGreedy?: boolean;
    timeLimitMs?: number;
  }>(req);

  if (!body?.roomId) return fail('roomId is required');
  if (!body.reason?.trim()) return fail('reason is required');

  try {
    const ctx = await loadContext();
    const outageRoom = ctx.rooms.find((r) => r.id === body.roomId);
    if (!outageRoom) return fail('Room not found', 404);

    // Find all exams currently assigned to the outage room
    const affectedAssignments = ctx.assignments.filter((a) => a.roomId === body.roomId);
    const affectedExamIds = affectedAssignments.map((a) => a.examId);
    const affectedExams = ctx.exams.filter((e) => affectedExamIds.includes(e.id));

    if (affectedExams.length === 0) {
      return ok({
        message: `Room "${outageRoom.name}" has no assigned exams. No re-scheduling needed.`,
        affectedExams: [],
        solution: null,
        orToolsAvailable: isORToolsAvailable(),
      });
    }

    // Build solver config — baseline is the current published assignments (for stability)
    const baseline = Object.fromEntries(
      ctx.assignments.map((a) => [a.examId, {
        examId: a.examId,
        timeSlotId: a.timeSlotId,
        roomId: a.roomId,
        invigilatorIds: a.invigilatorIds,
      }])
    );

    const config: SolverConfig = {
      timeLimitMs: body?.timeLimitMs ?? 5000,
      maxAlternatives: 1,
      objectiveWeights: DEFAULT_WEIGHTS,
      baseline,
    };

    // Use greedy solver (fast, with OR-Tools fallback documentation)
    const solution = solveGreedy({
      exams: ctx.exams,
      rooms: ctx.rooms,
      timeSlots: ctx.timeSlots,
      invigilators: ctx.invigilators,
      studentGroups: ctx.studentGroups,
      config,
      excludedRoomIds: [body.roomId], // exclude the outage room
      maxIterations: 100,
    });

    // Compute which exams changed
    const changedExams = solution.assignments.filter((a) => {
      const orig = baseline[a.examId];
      return !orig || orig.roomId !== a.roomId || orig.timeSlotId !== a.timeSlotId;
    }).map((a) => a.examId);

    // Affected exams that couldn't be re-scheduled
    const stillUnscheduled = solution.unscheduled.filter((u) => affectedExamIds.includes(u.examId));

    await writeAuditLog({
      action: 'emergency.outage_simulated',
      category: 'scenario',
      summary: `Emergency outage simulated for room "${outageRoom.name}" — ${affectedExams.length} exams affected, ${changedExams.length} re-scheduled, ${stillUnscheduled.length} unscheduled`,
      details: {
        roomId: body.roomId,
        roomName: outageRoom.name,
        reason: body.reason,
        affectedExamIds,
        changedExams,
        unscheduledExamIds: stillUnscheduled.map((u) => u.examId),
        feasible: solution.feasible,
        orToolsUsed: isORToolsAvailable(),
      },
    });

    await pushNotification({
      type: solution.feasible ? 'warning' : 'error',
      title: `Emergency outage: ${outageRoom.name}`,
      message: `${affectedExams.length} exams were in this room. ${changedExams.length} can be re-scheduled, ${stillUnscheduled.length} have no alternative. Review the proposal in the Emergency Simulation page.`,
    });

    return ok({
      outageRoom: {
        id: outageRoom.id,
        name: outageRoom.name,
        code: outageRoom.code,
        capacity: outageRoom.capacity,
      },
      reason: body.reason,
      affectedExams: affectedExams.map((e) => ({
        id: e.id,
        name: e.name,
        subjectCode: e.subjectCode,
        enrollmentCount: e.enrollmentCount,
        originalAssignment: affectedAssignments.find((a) => a.examId === e.id),
      })),
      solution,
      changedExamIds: changedExams,
      stillUnscheduled,
      orToolsAvailable: isORToolsAvailable(),
      solverUsed: isORToolsAvailable() ? 'or-tools-cp-sat' : 'greedy-fallback',
    });
  } catch (err) {
    return fail(`Emergency simulation failed: ${(err as Error).message}`, 500);
  }
}
