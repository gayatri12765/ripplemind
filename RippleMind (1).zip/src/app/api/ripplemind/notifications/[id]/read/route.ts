// POST /api/ripplemind/notifications/[id]/read — mark a notification as read
import { db, ok, fail } from '@/lib/api-helpers';

export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    await db.notification.update({ where: { id }, data: { read: true } });
    return ok({ read: true });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
