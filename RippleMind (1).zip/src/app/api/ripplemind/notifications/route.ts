// GET /api/ripplemind/notifications — list notifications
// POST /api/ripplemind/notifications — create a notification (admin use)
import { db, ok, fail, readBody } from '@/lib/api-helpers';

export async function GET() {
  try {
    const rows = await db.notification.findMany({
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    return ok({ notifications: rows });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function POST(req: Request) {
  const body = await readBody<{ type?: string; title?: string; message?: string }>(req);
  if (!body?.title || !body?.message) return fail('title and message are required');
  try {
    const row = await db.notification.create({
      data: {
        type: body.type ?? 'info',
        title: body.title,
        message: body.message,
      },
    });
    return ok({ notification: row }, 201);
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
