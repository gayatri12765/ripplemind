// /api/ripplemind/scenarios — GET (list) and POST (create + analyze)
import { db, ok, fail, readBody, loadContext, writeAuditLog, pushNotification } from '@/lib/api-helpers';
import { solve, solveWithAlternatives } from '@/lib/solver';
import { detectConflicts } from '@/lib/conflicts';
import { stringifyJSON } from '@/lib/json';
import type { AssignmentProposal, ScenarioChangeSummary, SolverConfig, SolverObjectiveWeights } from '@/lib/types';

const DEFAULT_WEIGHTS: SolverObjectiveWeights = {
  minimizeChangedExams: 50, // Heavy weight on minimal change for what-if
  minimizeRoomChanges: 20,
  minimizeCapacityWaste: 1,
  respectPreferredSlots: 5,
  balanceInvigilatorWorkload: 4,
};

export async function GET() {
  try {
    const rows = await db.scenario.findMany({ orderBy: { createdAt: 'desc' } });
    return ok({
      scenarios: rows.map((r) => ({
        ...r,
        changeSummary: JSON.parse(r.changeSummary || '{}'),
        originalState: JSON.parse(r.originalState || '[]'),
        proposedState: JSON.parse(r.proposedState || '[]'),
        conflictReport: JSON.parse(r.conflictReport || '[]'),
        solverMetrics: JSON.parse(r.solverMetrics || '{}'),
        alternatives: JSON.parse(r.alternatives || '[]'),
      })),
    });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function POST(req: Request) {
  const body = await readBody<{
    name?: string;
    description?: string;
    examId?: string;
    change: {
      targetSlotId?: string;
      targetRoomId?: string;
      targetInvigilatorIds?: string[];
      targetDuration?: number;
    };
    generateAlternatives?: boolean;
    timeLimitMs?: number;
  }>(req);

  if (!body?.name?.trim()) return fail('Scenario name is required');
  if (!body?.examId) return fail('examId is required');
  if (!body?.change) return fail('change is required');

  try {
    const ctx = await loadContext();
    const exam = ctx.exams.find((e) => e.id === body.examId);
    if (!exam) return fail('Exam not found', 404);

    // Snapshot the original assignment for this exam (if any)
    const originalAssignment = ctx.assignments.find((a) => a.examId === body.examId);
    const originalState: AssignmentProposal[] = ctx.assignments.map((a) => ({
      examId: a.examId,
      timeSlotId: a.timeSlotId,
      roomId: a.roomId,
      invigilatorIds: a.invigilatorIds,
    }));

    // Build the proposed change description
    const changeSummary: ScenarioChangeSummary = {
      kind: 'mixed',
      examId: body.examId,
      from: originalAssignment
        ? {
            examId: originalAssignment.examId,
            timeSlotId: originalAssignment.timeSlotId,
            roomId: originalAssignment.roomId,
            invigilatorIds: originalAssignment.invigilatorIds,
          }
        : undefined,
      to: {
        examId: body.examId,
        timeSlotId: body.change.targetSlotId,
        roomId: body.change.targetRoomId,
        invigilatorIds: body.change.targetInvigilatorIds,
      },
      description: buildChangeDescription(exam.name, originalAssignment, body.change),
    };
    if (body.change.targetDuration !== undefined && body.change.targetDuration !== exam.duration) {
      changeSummary.kind = 'duration';
    } else if (body.change.targetSlotId && body.change.targetSlotId !== originalAssignment?.timeSlotId) {
      changeSummary.kind = 'move';
    } else if (body.change.targetRoomId && body.change.targetRoomId !== originalAssignment?.roomId) {
      changeSummary.kind = 'room';
    } else if (body.change.targetInvigilatorIds) {
      changeSummary.kind = 'invigilator';
    }

    // Build a modified exam list (duration change) and a baseline for minimal-change optimization
    const modifiedExams = ctx.exams.map((e) =>
      e.id === body.examId && body.change.targetDuration !== undefined
        ? { ...e, duration: body.change.targetDuration }
        : e
    );

    // The proposed assignment for the initiator exam
    const initiatorProposal: AssignmentProposal | null = body.change.targetSlotId && body.change.targetRoomId
      ? {
          examId: body.examId,
          timeSlotId: body.change.targetSlotId,
          roomId: body.change.targetRoomId,
          invigilatorIds: body.change.targetInvigilatorIds ?? [],
        }
      : null;

    // Run the solver with the baseline = current published assignments
    // The solver will minimize changes while honoring the initiator's new constraint.
    const config: SolverConfig = {
      timeLimitMs: body?.timeLimitMs ?? Number(process.env.SOLVER_TIME_LIMIT_MS ?? 8000),
      maxAlternatives: 4,
      objectiveWeights: DEFAULT_WEIGHTS,
      baseline: Object.fromEntries(originalState.map((a) => [a.examId, a])),
    };

    // If we have an initiator proposal, pin it as a fixed assignment
    const fixedAssignments: AssignmentProposal[] = [];
    if (initiatorProposal) fixedAssignments.push(initiatorProposal);
    // Also fix any assignment that's NOT in scope (only the initiator exam + downstream are re-solved)
    // We re-solve the entire set so the solver can find the minimal-change ripple.

    const solution = await solve({
      exams: modifiedExams,
      rooms: ctx.rooms,
      timeSlots: ctx.timeSlots,
      invigilators: ctx.invigilators,
      studentGroups: ctx.studentGroups,
      config,
      fixedAssignments,
    });

    let alternatives: typeof solution[] = [];
    if (body.generateAlternatives && solution.feasible) {
      const withAlts = await solveWithAlternatives({
        exams: modifiedExams,
        rooms: ctx.rooms,
        timeSlots: ctx.timeSlots,
        invigilators: ctx.invigilators,
        studentGroups: ctx.studentGroups,
        config,
        fixedAssignments,
      });
      alternatives = withAlts.alternatives ?? [];
    }

    const proposedState = solution.assignments;
    const conflicts = solution.conflicts;

    const row = await db.scenario.create({
      data: {
        name: body.name.trim(),
        description: body.description ?? null,
        status: 'analyzed',
        initiatorExamId: body.examId,
        changeSummary: stringifyJSON(changeSummary),
        originalState: stringifyJSON(originalState),
        proposedState: stringifyJSON(proposedState),
        conflictReport: stringifyJSON(conflicts),
        solverMetrics: stringifyJSON(solution.metrics),
        isFeasible: solution.feasible,
        alternatives: stringifyJSON(alternatives),
      },
    });

    await writeAuditLog({
      action: 'scenario.created',
      category: 'scenario',
      summary: `Scenario "${row.name}" created — ${solution.feasible ? 'feasible' : 'infeasible'}`,
      target: row.id,
      scenarioId: row.id,
      details: { changeSummary, metrics: solution.metrics },
    });

    await pushNotification({
      type: solution.feasible ? 'info' : 'warning',
      title: `Scenario "${row.name}" analyzed`,
      message: solution.feasible
        ? `Proposed change is feasible. ${solution.metrics.changedExamsFromBaseline ?? 0} exam(s) affected.`
        : solution.provenInfeasible
          ? 'Proposed change is infeasible given current constraints.'
          : 'Solver timed out — try again with a longer time limit.',
    });

    return ok({
      scenario: {
        ...row,
        changeSummary: JSON.parse(row.changeSummary || '{}'),
        originalState: JSON.parse(row.originalState || '[]'),
        proposedState: JSON.parse(row.proposedState || '[]'),
        conflictReport: JSON.parse(row.conflictReport || '[]'),
        solverMetrics: JSON.parse(row.solverMetrics || '{}'),
        alternatives: JSON.parse(row.alternatives || '[]'),
      },
      solution,
    }, 201);
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

function buildChangeDescription(
  examName: string,
  from: { timeSlotId: string; roomId: string; invigilatorIds: string[] } | undefined,
  change: { targetSlotId?: string; targetRoomId?: string; targetInvigilatorIds?: string[]; targetDuration?: number }
): string {
  const parts: string[] = [];
  if (change.targetSlotId) parts.push(`move to slot ${change.targetSlotId}`);
  if (change.targetRoomId) parts.push(`use room ${change.targetRoomId}`);
  if (change.targetInvigilatorIds) parts.push(`assign invigilators ${change.targetInvigilatorIds.join(', ')}`);
  if (change.targetDuration) parts.push(`change duration to ${change.targetDuration} min`);
  return `${examName}: ${parts.join(' + ') || 'no change'}`;
}
