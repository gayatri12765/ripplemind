// GET /api/ripplemind/scenarios/[id]/ripple — build ripple-effect graph for visualization
import { ok, fail, loadContext } from '@/lib/api-helpers';
import { buildRippleGraph } from '@/lib/ripple';
import { db } from '@/lib/db';

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const row = await db.scenario.findUnique({ where: { id } });
    if (!row) return fail('Scenario not found', 404);

    const ctxData = await loadContext();
    const originalState = JSON.parse(row.originalState || '[]');
    const proposedState = JSON.parse(row.proposedState || '[]');
    const conflicts = JSON.parse(row.conflictReport || '[]');

    const graph = buildRippleGraph({
      baseline: originalState,
      proposed: proposedState,
      conflicts,
      exams: ctxData.exams,
      rooms: ctxData.rooms,
      timeSlots: ctxData.timeSlots,
      invigilators: ctxData.invigilators,
      studentGroups: ctxData.studentGroups,
    });

    return ok({ graph });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
