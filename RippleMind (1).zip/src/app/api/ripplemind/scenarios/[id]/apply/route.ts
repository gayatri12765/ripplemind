// POST /api/ripplemind/scenarios/[id]/apply — apply an approved scenario to the published timetable.
// Uses a transaction. Refuses if scenario is infeasible or has critical conflicts.
import { db, ok, fail, writeAuditLog, pushNotification, loadContext } from '@/lib/api-helpers';
import { detectConflicts } from '@/lib/conflicts';
import { stringifyJSON } from '@/lib/json';
import type { AssignmentProposal } from '@/lib/types';

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  const alternativeIndex = typeof body.alternativeIndex === 'number' ? body.alternativeIndex : null;

  try {
    const row = await db.scenario.findUnique({ where: { id } });
    if (!row) return fail('Scenario not found', 404);
    if (row.status === 'discarded') return fail('Scenario was discarded', 409);
    if (row.isFeasible !== true) return fail('Scenario is not feasible — cannot apply', 409);

    // Determine which proposed state to apply (default or selected alternative)
    let proposedState: AssignmentProposal[] = JSON.parse(row.proposedState || '[]');
    if (alternativeIndex !== null) {
      const alts: AssignmentProposal[][] = JSON.parse(row.alternatives || '[]');
      if (alternativeIndex < 0 || alternativeIndex >= alts.length) {
        return fail('Invalid alternative index', 400);
      }
      proposedState = alts[alternativeIndex];
    }

    const ctxData = await loadContext();
    const conflicts = detectConflicts({
      assignments: proposedState,
      context: ctxData,
    });
    const critical = conflicts.filter((c) => c.severity === 'critical');
    if (critical.length > 0) {
      return fail(`Refusing to apply: ${critical.length} critical conflict(s) detected.`, 409, { conflicts: critical });
    }

    await db.$transaction(async (tx) => {
      // Replace the entire published timetable with the proposed state
      await tx.examAssignment.deleteMany({});
      for (const a of proposedState) {
        const slot = ctxData.timeSlots.find((t) => t.id === a.timeSlotId);
        if (!slot) continue;
        await tx.examAssignment.create({
          data: {
            examId: a.examId,
            timeSlotId: a.timeSlotId,
            roomId: a.roomId,
            date: slot.date,
            invigilatorIds: stringifyJSON(a.invigilatorIds ?? []),
            isPublished: true,
          },
        });
        await tx.exam.update({ where: { id: a.examId }, data: { status: 'scheduled' } });
      }
      const scheduledIds = new Set(proposedState.map((a) => a.examId));
      const unscheduledIds = ctxData.exams.map((e) => e.id).filter((eid) => !scheduledIds.has(eid));
      if (unscheduledIds.length) {
        await tx.exam.updateMany({ where: { id: { in: unscheduledIds } }, data: { status: 'unscheduled' } });
      }
      await tx.scenario.update({
        where: { id },
        data: { status: 'approved', appliedAt: new Date() },
      });
    });

    await writeAuditLog({
      action: 'scenario.applied',
      category: 'scenario',
      summary: `Scenario "${row.name}" applied to published timetable${alternativeIndex !== null ? ` (alternative #${alternativeIndex})` : ''}`,
      target: id,
      scenarioId: id,
      details: { alternativeIndex, assignmentCount: proposedState.length },
    });
    await pushNotification({
      type: 'success',
      title: 'Scenario applied',
      message: `"${row.name}" has been published. ${proposedState.length} assignments updated.`,
    });

    return ok({ applied: proposedState.length, scenarioId: id });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
