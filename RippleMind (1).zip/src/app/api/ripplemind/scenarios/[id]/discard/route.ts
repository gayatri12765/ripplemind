// POST /api/ripplemind/scenarios/[id]/discard — discard a scenario (does NOT modify published timetable)
import { db, ok, fail, writeAuditLog } from '@/lib/api-helpers';

export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const row = await db.scenario.findUnique({ where: { id } });
    if (!row) return fail('Scenario not found', 404);
    await db.scenario.update({ where: { id }, data: { status: 'discarded' } });
    await writeAuditLog({
      action: 'scenario.discarded',
      category: 'scenario',
      summary: `Scenario "${row.name}" discarded`,
      target: id,
      scenarioId: id,
    });
    return ok({ discarded: true });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
