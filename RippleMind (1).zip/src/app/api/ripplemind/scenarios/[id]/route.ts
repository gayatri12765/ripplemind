// /api/ripplemind/scenarios/[id] — GET, DELETE
import { db, ok, fail, writeAuditLog } from '@/lib/api-helpers';

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const row = await db.scenario.findUnique({ where: { id } });
    if (!row) return fail('Scenario not found', 404);
    return ok({
      scenario: {
        ...row,
        changeSummary: JSON.parse(row.changeSummary || '{}'),
        originalState: JSON.parse(row.originalState || '[]'),
        proposedState: JSON.parse(row.proposedState || '[]'),
        conflictReport: JSON.parse(row.conflictReport || '[]'),
        solverMetrics: JSON.parse(row.solverMetrics || '{}'),
        alternatives: JSON.parse(row.alternatives || '[]'),
      },
    });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    await db.scenario.delete({ where: { id } });
    await writeAuditLog({
      action: 'scenario.deleted',
      category: 'scenario',
      summary: `Scenario ${id} deleted`,
      target: id,
    });
    return ok({ deleted: true });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
