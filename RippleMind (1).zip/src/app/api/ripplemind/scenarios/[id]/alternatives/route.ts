// POST /api/ripplemind/scenarios/[id]/alternatives — regenerate alternatives for a scenario
import { db, ok, fail, readBody, loadContext } from '@/lib/api-helpers';
import { solveWithAlternatives } from '@/lib/solver';
import { stringifyJSON } from '@/lib/json';
import type { SolverConfig, SolverObjectiveWeights } from '@/lib/types';

const DEFAULT_WEIGHTS: SolverObjectiveWeights = {
  minimizeChangedExams: 50,
  minimizeRoomChanges: 20,
  minimizeCapacityWaste: 1,
  respectPreferredSlots: 5,
  balanceInvigilatorWorkload: 4,
};

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await readBody<{ maxAlternatives?: number; timeLimitMs?: number }>(req);
  try {
    const row = await db.scenario.findUnique({ where: { id } });
    if (!row) return fail('Scenario not found', 404);

    const ctxData = await loadContext();
    const originalState = JSON.parse(row.originalState || '[]') as { examId: string; timeSlotId: string; roomId: string; invigilatorIds: string[] }[];
    const changeSummary = JSON.parse(row.changeSummary || '{}');

    const config: SolverConfig = {
      timeLimitMs: body?.timeLimitMs ?? Number(process.env.SOLVER_TIME_LIMIT_MS ?? 8000),
      maxAlternatives: body?.maxAlternatives ?? 4,
      objectiveWeights: DEFAULT_WEIGHTS,
      baseline: Object.fromEntries(originalState.map((a) => [a.examId, a])),
    };

    // Pin the initiator's proposed change
    const fixedAssignments = changeSummary.to?.timeSlotId && changeSummary.to?.roomId
      ? [{
          examId: changeSummary.examId,
          timeSlotId: changeSummary.to.timeSlotId,
          roomId: changeSummary.to.roomId,
          invigilatorIds: changeSummary.to.invigilatorIds ?? [],
        }]
      : [];

    const solution = await solveWithAlternatives({
      exams: ctxData.exams,
      rooms: ctxData.rooms,
      timeSlots: ctxData.timeSlots,
      invigilators: ctxData.invigilators,
      studentGroups: ctxData.studentGroups,
      config,
      fixedAssignments,
    });

    const alternatives = solution.alternatives ?? [];
    await db.scenario.update({
      where: { id },
      data: { alternatives: stringifyJSON(alternatives) },
    });

    return ok({ alternatives, count: alternatives.length });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
