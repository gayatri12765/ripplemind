// GET /api/ripplemind/settings — list settings
// PUT /api/ripplemind/settings — update settings
import { db, ok, fail, readBody } from '@/lib/api-helpers';

export async function GET() {
  try {
    const rows = await db.setting.findMany();
    const settings: Record<string, string> = {};
    for (const r of rows) settings[r.key] = r.value;
    return ok({ settings });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function PUT(req: Request) {
  const body = await readBody<Record<string, string>>(req);
  if (!body) return fail('Invalid JSON body');
  try {
    for (const [key, value] of Object.entries(body)) {
      const existing = await db.setting.findUnique({ where: { key } });
      if (existing) {
        await db.setting.update({ where: { key }, data: { value } });
      } else {
        await db.setting.create({ data: { key, value } });
      }
    }
    return ok({ updated: Object.keys(body).length });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
