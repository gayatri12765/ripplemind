// POST /api/ripplemind/reset — clear all data
import { db, ok, fail, writeAuditLog } from '@/lib/api-helpers';

export async function POST() {
  try {
    await db.notification.deleteMany();
    await db.auditLog.deleteMany();
    await db.scenario.deleteMany();
    await db.examAssignment.deleteMany();
    await db.exam.deleteMany();
    await db.studentGroup.deleteMany();
    await db.room.deleteMany();
    await db.timeSlot.deleteMany();
    await db.invigilator.deleteMany();
    await db.setting.deleteMany();
    await writeAuditLog({
      action: 'system.reset',
      category: 'system',
      summary: 'All data cleared',
    });
    return ok({ reset: true });
  } catch (err) {
    return fail(`Reset failed: ${(err as Error).message}`, 500);
  }
}
