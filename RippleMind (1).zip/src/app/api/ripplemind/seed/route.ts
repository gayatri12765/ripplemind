// POST /api/ripplemind/seed — load rich demo data
// POST /api/ripplemind/reset — clear all data
import { db, ok, fail, writeAuditLog, pushNotification } from '@/lib/api-helpers';
import { stringifyJSON } from '@/lib/json';
import { toISODate, addDays, dayOfWeek } from '@/lib/time';

export async function POST() {
  try {
    // Clear existing data first
    await db.notification.deleteMany();
    await db.auditLog.deleteMany();
    await db.scenario.deleteMany();
    await db.examAssignment.deleteMany();
    await db.exam.deleteMany();
    await db.studentGroup.deleteMany();
    await db.room.deleteMany();
    await db.timeSlot.deleteMany();
    await db.invigilator.deleteMany();
    await db.setting.deleteMany();

    // --- Student Groups ---
    const groups = await Promise.all([
      db.studentGroup.create({ data: { name: 'Computer Science Y3', code: 'CS-Y3', studentCount: 120, program: 'BSc Computer Science', year: 3 } }),
      db.studentGroup.create({ data: { name: 'Electrical Engineering Y2', code: 'EE-Y2', studentCount: 85, program: 'BEng Electrical', year: 2 } }),
      db.studentGroup.create({ data: { name: 'Mechanical Engineering Y2', code: 'ME-Y2', studentCount: 90, program: 'BEng Mechanical', year: 2 } }),
      db.studentGroup.create({ data: { name: 'Business Administration Y1', code: 'BA-Y1', studentCount: 150, program: 'BBA', year: 1 } }),
      db.studentGroup.create({ data: { name: 'Mathematics Y2', code: 'MATH-Y2', studentCount: 60, program: 'BSc Mathematics', year: 2 } }),
      db.studentGroup.create({ data: { name: 'Physics Y3', code: 'PHY-Y3', studentCount: 45, program: 'BSc Physics', year: 3 } }),
      db.studentGroup.create({ data: { name: 'Civil Engineering Y4', code: 'CE-Y4', studentCount: 70, program: 'BEng Civil', year: 4 } }),
      db.studentGroup.create({ data: { name: 'Chemistry Y2', code: 'CHEM-Y2', studentCount: 55, program: 'BSc Chemistry', year: 2 } }),
    ]);

    // --- Rooms ---
    const rooms = await Promise.all([
      db.room.create({ data: { name: 'Auditorium A', code: 'AUD-A', capacity: 200, location: 'Main Building', building: 'Main', floor: 1, features: stringifyJSON(['projector', 'audio']) } }),
      db.room.create({ data: { name: 'Auditorium B', code: 'AUD-B', capacity: 180, location: 'Main Building', building: 'Main', floor: 1, features: stringifyJSON(['projector']) } }),
      db.room.create({ data: { name: 'Hall 101', code: 'H101', capacity: 120, location: 'Block A', building: 'A', floor: 1, features: stringifyJSON(['whiteboard']) } }),
      db.room.create({ data: { name: 'Hall 102', code: 'H102', capacity: 100, location: 'Block A', building: 'A', floor: 1, features: stringifyJSON(['whiteboard']) } }),
      db.room.create({ data: { name: 'Hall 201', code: 'H201', capacity: 90, location: 'Block A', building: 'A', floor: 2, features: stringifyJSON(['projector']) } }),
      db.room.create({ data: { name: 'Hall 202', code: 'H202', capacity: 80, location: 'Block A', building: 'A', floor: 2, features: stringifyJSON(['whiteboard']) } }),
      db.room.create({ data: { name: 'Room 301', code: 'R301', capacity: 60, location: 'Block B', building: 'B', floor: 3, features: stringifyJSON(['whiteboard']) } }),
      db.room.create({ data: { name: 'Room 302', code: 'R302', capacity: 50, location: 'Block B', building: 'B', floor: 3, features: stringifyJSON(['whiteboard']) } }),
      db.room.create({ data: { name: 'Room 303', code: 'R303', capacity: 40, location: 'Block B', building: 'B', floor: 3, features: stringifyJSON(['projector']) } }),
      db.room.create({ data: { name: 'Lab 1', code: 'LAB-1', capacity: 50, location: 'Lab Wing', building: 'Lab', floor: 1, features: stringifyJSON(['computers']) } }),
      db.room.create({ data: { name: 'Lab 2', code: 'LAB-2', capacity: 40, location: 'Lab Wing', building: 'Lab', floor: 1, features: stringifyJSON(['computers']) } }),
      db.room.create({ data: { name: 'Seminar Room', code: 'SEM-1', capacity: 30, location: 'Library', building: 'Library', floor: 2, features: stringifyJSON(['oval-table']) } }),
    ]);

    // --- Time Slots (next 5 weekdays, 3 slots per day = 15 slots) ---
    const today = toISODate(new Date());
    const weekdayDates: string[] = [];
    let cursor = today;
    while (weekdayDates.length < 5) {
      if (dayOfWeek(cursor) !== 0 && dayOfWeek(cursor) !== 6) {
        weekdayDates.push(cursor);
      }
      cursor = addDays(cursor, 1);
    }
    const slotTemplates = [
      { start: '09:00', end: '11:00', label: 'Morning 1' },
      { start: '12:00', end: '14:00', label: 'Afternoon 1' },
      { start: '15:00', end: '17:00', label: 'Afternoon 2' },
    ];
    const timeSlots = [];
    for (const date of weekdayDates) {
      for (const tmpl of slotTemplates) {
        timeSlots.push(await db.timeSlot.create({
          data: {
            date,
            startTime: tmpl.start,
            endTime: tmpl.end,
            label: tmpl.label,
            dayOfWeek: dayOfWeek(date),
            isAvailable: true,
          },
        }));
      }
    }

    // --- Invigilators ---
    const invigilators = await Promise.all([
      db.invigilator.create({ data: { name: 'Dr. Anjali Rao', email: 'anjali.rao@college.edu', department: 'Computer Science', maxWorkload: 3, availability: stringifyJSON([]) } }),
      db.invigilator.create({ data: { name: 'Prof. Vikram Shah', email: 'vikram.shah@college.edu', department: 'Electrical', maxWorkload: 3, availability: stringifyJSON([]) } }),
      db.invigilator.create({ data: { name: 'Dr. Meera Iyer', email: 'meera.iyer@college.edu', department: 'Mathematics', maxWorkload: 2, availability: stringifyJSON([]) } }),
      db.invigilator.create({ data: { name: 'Prof. Rajesh Khanna', email: 'rajesh.khanna@college.edu', department: 'Mechanical', maxWorkload: 3, availability: stringifyJSON([]) } }),
      db.invigilator.create({ data: { name: 'Dr. Sunita Pillai', email: 'sunita.pillai@college.edu', department: 'Business', maxWorkload: 2, availability: stringifyJSON([]) } }),
      db.invigilator.create({ data: { name: 'Prof. Arjun Nair', email: 'arjun.nair@college.edu', department: 'Physics', maxWorkload: 3, availability: stringifyJSON([]) } }),
    ]);

    // --- Exams (10 exams across the student groups) ---
    const examDefs = [
      { name: 'Data Structures & Algorithms', subjectCode: 'CS301', duration: 180, group: 0, enrollment: 120, type: 'final' },
      { name: 'Database Management Systems', subjectCode: 'CS302', duration: 180, group: 0, enrollment: 120, type: 'final' },
      { name: 'Operating Systems', subjectCode: 'CS303', duration: 180, group: 0, enrollment: 120, type: 'final' },
      { name: 'Circuit Theory', subjectCode: 'EE201', duration: 180, group: 1, enrollment: 85, type: 'final' },
      { name: 'Signals & Systems', subjectCode: 'EE202', duration: 120, group: 1, enrollment: 85, type: 'midterm' },
      { name: 'Thermodynamics', subjectCode: 'ME201', duration: 180, group: 2, enrollment: 90, type: 'final' },
      { name: 'Principles of Management', subjectCode: 'BA101', duration: 120, group: 3, enrollment: 150, type: 'final' },
      { name: 'Linear Algebra', subjectCode: 'MATH201', duration: 120, group: 4, enrollment: 60, type: 'final' },
      { name: 'Quantum Mechanics', subjectCode: 'PHY301', duration: 180, group: 5, enrollment: 45, type: 'final' },
      { name: 'Structural Analysis', subjectCode: 'CE401', duration: 180, group: 6, enrollment: 70, type: 'final' },
    ];
    for (const e of examDefs) {
      await db.exam.create({
        data: {
          name: e.name,
          subjectCode: e.subjectCode,
          duration: e.duration,
          studentGroupId: groups[e.group].id,
          enrollmentCount: e.enrollment,
          examType: e.type,
          preferredSlots: stringifyJSON([]),
          preferredRooms: stringifyJSON([]),
        },
      });
    }

    await writeAuditLog({
      action: 'system.seeded',
      category: 'system',
      summary: 'Demo data loaded',
      details: {
        groups: groups.length,
        rooms: rooms.length,
        timeSlots: timeSlots.length,
        invigilators: invigilators.length,
        exams: examDefs.length,
      },
    });
    await pushNotification({
      type: 'success',
      title: 'Demo data loaded',
      message: `${groups.length} student groups, ${rooms.length} rooms, ${timeSlots.length} time slots, ${invigilators.length} invigilators, ${examDefs.length} exams. Try Generate Timetable next.`,
    });

    return ok({
      seeded: true,
      counts: { groups: groups.length, rooms: rooms.length, timeSlots: timeSlots.length, invigilators: invigilators.length, exams: examDefs.length },
    });
  } catch (err) {
    return fail(`Seed failed: ${(err as Error).message}`, 500);
  }
}
