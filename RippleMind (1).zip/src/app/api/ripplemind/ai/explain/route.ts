// POST /api/ripplemind/ai/explain — LLM-powered explanation
import { ok, fail, readBody, loadContext } from '@/lib/api-helpers';
import { explain, type AIExplainRequest } from '@/lib/ai';
import { db } from '@/lib/db';

export async function POST(req: Request) {
  const body = await readBody<{ topic: AIExplainRequest['topic']; question: string; scenarioId?: string }>(req);
  if (!body?.question) return fail('question is required');
  if (!body?.topic) return fail('topic is required');

  try {
    const ctx = await loadContext();
    let scenario = null;
    if (body.scenarioId) {
      const row = await db.scenario.findUnique({ where: { id: body.scenarioId } });
      if (row) {
        scenario = {
          ...row,
          changeSummary: JSON.parse(row.changeSummary || '{}'),
          originalState: JSON.parse(row.originalState || '[]'),
          proposedState: JSON.parse(row.proposedState || '[]'),
          conflictReport: JSON.parse(row.conflictReport || '[]'),
          solverMetrics: JSON.parse(row.solverMetrics || '{}'),
          alternatives: JSON.parse(row.alternatives || '[]'),
        } as any;
      }
    }

    const result = await explain({
      topic: body.topic,
      question: body.question,
      context: {
        exams: ctx.exams,
        rooms: ctx.rooms,
        timeSlots: ctx.timeSlots,
        invigilators: ctx.invigilators,
        studentGroups: ctx.studentGroups,
        assignments: ctx.assignments,
        conflicts: body.topic === 'conflict' ? undefined : undefined,
        scenario,
      },
    });
    return ok(result);
  } catch (err) {
    return fail(`AI explain failed: ${(err as Error).message}`, 500);
  }
}
