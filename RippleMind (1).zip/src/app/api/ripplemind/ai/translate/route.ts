// POST /api/ripplemind/ai/translate — translate natural-language request to structured proposals
import { ok, fail, readBody, loadContext } from '@/lib/api-helpers';
import { translateNLToProposal } from '@/lib/ai';

export async function POST(req: Request) {
  const body = await readBody<{ query: string }>(req);
  if (!body?.query) return fail('query is required');

  try {
    const ctx = await loadContext();
    const result = await translateNLToProposal({
      query: body.query,
      context: {
        exams: ctx.exams,
        rooms: ctx.rooms,
        timeSlots: ctx.timeSlots,
        invigilators: ctx.invigilators,
        studentGroups: ctx.studentGroups,
        assignments: ctx.assignments,
      },
    });
    return ok(result);
  } catch (err) {
    return fail(`AI translate failed: ${(err as Error).message}`, 500);
  }
}
