// GET /api/ripplemind/audit — audit log list
import { db, ok, fail } from '@/lib/api-helpers';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const limit = Number(url.searchParams.get('limit') ?? 100);
  const category = url.searchParams.get('category');
  try {
    const rows = await db.auditLog.findMany({
      where: category ? { category } : undefined,
      orderBy: { createdAt: 'desc' },
      take: Math.min(limit, 500),
    });
    return ok({
      auditLogs: rows.map((r) => ({
        ...r,
        details: JSON.parse(r.details || '{}'),
      })),
    });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
