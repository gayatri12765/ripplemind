// GET /api/ripplemind/analytics — analytics data for the Analytics page
import { ok, fail, loadContext } from '@/lib/api-helpers';
import { detectConflicts } from '@/lib/conflicts';
import { toISODate, addDays, dayOfWeek } from '@/lib/time';

export async function GET() {
  try {
    const ctx = await loadContext();
    const conflicts = detectConflicts({
      assignments: ctx.assignments.map((a) => ({
        examId: a.examId,
        timeSlotId: a.timeSlotId,
        roomId: a.roomId,
        invigilatorIds: a.invigilatorIds,
      })),
      context: ctx,
    });

    // Room utilization
    const roomUsage = new Map<string, number>();
    for (const a of ctx.assignments) {
      roomUsage.set(a.roomId, (roomUsage.get(a.roomId) ?? 0) + 1);
    }
    const roomUtilization = ctx.rooms.map((r) => ({
      roomName: r.name,
      roomCode: r.code,
      capacity: r.capacity,
      assignments: roomUsage.get(r.id) ?? 0,
      utilization: ctx.assignments.length ? ((roomUsage.get(r.id) ?? 0) / ctx.assignments.length) * 100 : 0,
    }));

    // Invigilator workload
    const invLoad = new Map<string, number>();
    for (const a of ctx.assignments) {
      for (const inv of a.invigilatorIds) {
        invLoad.set(inv, (invLoad.get(inv) ?? 0) + 1);
      }
    }
    const invigilatorWorkload = ctx.invigilators.map((i) => ({
      name: i.name,
      department: i.department ?? '—',
      assignments: invLoad.get(i.id) ?? 0,
      maxWorkload: i.maxWorkload,
      utilization: i.maxWorkload ? ((invLoad.get(i.id) ?? 0) / i.maxWorkload) * 100 : 0,
    }));

    // Daily exam distribution (next 14 days from earliest assignment, or today)
    const today = toISODate(new Date());
    const startDate = ctx.assignments.length
      ? ctx.assignments.map((a) => a.date).sort()[0]
      : today;
    const days: string[] = [];
    for (let i = 0; i < 14; i++) days.push(addDays(startDate, i));
    const dailyExams = days.map((d) => ({
      date: d,
      dayOfWeek: dayOfWeek(d),
      count: ctx.assignments.filter((a) => a.date === d).length,
    }));

    // Conflicts by kind
    const conflictsByKind = new Map<string, number>();
    for (const c of conflicts) {
      conflictsByKind.set(c.kind, (conflictsByKind.get(c.kind) ?? 0) + 1);
    }

    // Capacity waste
    let totalWaste = 0;
    let totalCapacity = 0;
    for (const a of ctx.assignments) {
      const exam = ctx.exams.find((e) => e.id === a.examId);
      const room = ctx.rooms.find((r) => r.id === a.roomId);
      if (exam && room) {
        totalWaste += Math.max(0, room.capacity - exam.enrollmentCount);
        totalCapacity += room.capacity;
      }
    }

    // Schedule quality score (0-100): weighted blend of feasibility, utilization, balance, preference
    const feasibility = conflicts.length === 0 ? 25 : Math.max(0, 25 - conflicts.length * 2);
    const utilization = ctx.rooms.length ? Math.min(25, (roomUsage.size / ctx.rooms.length) * 25) : 0;
    const loadBalance = invigilatorWorkload.length
      ? 25 - Math.min(25, Math.max(0, Math.max(...invigilatorWorkload.map((w) => w.utilization)) - 100) * 0.5)
      : 0;
    const wasteScore = totalCapacity ? 25 - Math.min(25, (totalWaste / totalCapacity) * 50) : 0;
    const qualityScore = Math.round(feasibility + utilization + loadBalance + wasteScore);

    // Student-group workload indicators
    const groupWorkload = ctx.studentGroups.map((g) => {
      const groupExams = ctx.exams.filter((e) => e.studentGroupId === g.id);
      const groupAssignments = ctx.assignments.filter((a) => groupExams.some((e) => e.id === a.examId));
      const dates = new Set(groupAssignments.map((a) => a.date));
      const byDate = new Map<string, number>();
      for (const a of groupAssignments) {
        byDate.set(a.date, (byDate.get(a.date) ?? 0) + 1);
      }
      const maxPerDay = byDate.size ? Math.max(...byDate.values()) : 0;
      const uniqueRooms = new Set(groupAssignments.map((a) => a.roomId)).size;
      return {
        groupId: g.id,
        groupName: g.name,
        groupCode: g.code,
        studentCount: g.studentCount,
        totalExams: groupExams.length,
        scheduledExams: groupAssignments.length,
        unscheduledExams: groupExams.length - groupAssignments.length,
        examDays: dates.size,
        maxExamsPerDay: maxPerDay,
        roomsUsed: uniqueRooms,
        workloadStatus: maxPerDay >= 3 ? 'overloaded' : maxPerDay === 2 ? 'balanced' : maxPerDay === 1 ? 'light' : 'none',
      };
    }).sort((a, b) => b.scheduledExams - a.scheduledExams);

    // Seat utilization (enrolled students vs room capacity)
    const seatUtilization = ctx.assignments.map((a) => {
      const exam = ctx.exams.find((e) => e.id === a.examId);
      const room = ctx.rooms.find((r) => r.id === a.roomId);
      if (!exam || !room) return null;
      const utilization = room.capacity > 0 ? (exam.enrollmentCount / room.capacity) * 100 : 0;
      return {
        examName: exam.name,
        subjectCode: exam.subjectCode,
        roomName: room.name,
        enrolled: exam.enrollmentCount,
        capacity: room.capacity,
        utilization: Math.round(utilization),
        waste: Math.max(0, room.capacity - exam.enrollmentCount),
        status: utilization >= 90 ? 'full' : utilization >= 70 ? 'good' : utilization >= 50 ? 'moderate' : 'low',
      };
    }).filter(Boolean).sort((a: any, b: any) => b.utilization - a.utilization);

    return ok({
      roomUtilization,
      invigilatorWorkload,
      groupWorkload,
      seatUtilization,
      dailyExams,
      conflictsByKind: Array.from(conflictsByKind.entries()).map(([kind, count]) => ({ kind, count })),
      totalConflicts: conflicts.length,
      capacityWaste: totalWaste,
      capacityTotal: totalCapacity,
      scheduleQualityScore: qualityScore,
      qualityBreakdown: { feasibility: Math.round(feasibility), utilization: Math.round(utilization), loadBalance: Math.round(loadBalance), wasteScore: Math.round(wasteScore) },
      totalExams: ctx.exams.length,
      scheduledExams: ctx.assignments.length,
      unscheduledExams: ctx.exams.length - ctx.assignments.length,
      seatUtilizationRate: totalCapacity ? Math.round(((totalCapacity - totalWaste) / totalCapacity) * 100) : 0,
    });
  } catch (err) {
    return fail(`Analytics failed: ${(err as Error).message}`, 500);
  }
}
