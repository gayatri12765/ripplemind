// GET /api/ripplemind/student-portal?groupId=<id>
// Returns a student-facing view of the timetable for a specific group,
// including room details, invigilators, and recent change notifications.

import { db, ok, fail, loadContext } from '@/lib/api-helpers';
import { toISODate, addDays, formatDate, dayName } from '@/lib/time';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const groupId = url.searchParams.get('groupId');

  if (!groupId) {
    return fail('groupId query parameter is required', 400);
  }

  try {
    const ctx = await loadContext();
    const group = ctx.studentGroups.find((g) => g.id === groupId);
    if (!group) return fail('Student group not found', 404);

    // Filter exams for this group
    const groupExams = ctx.exams.filter((e) => e.studentGroupId === groupId);
    const groupExamIds = new Set(groupExams.map((e) => e.id));

    // Filter assignments for these exams
    const groupAssignments = ctx.assignments
      .filter((a) => groupExamIds.has(a.examId))
      .sort((a, b) => a.date.localeCompare(b.date) || (a.timeSlot?.startTime ?? '').localeCompare(b.timeSlot?.startTime ?? ''));

    // Build detailed schedule entries
    const schedule = groupAssignments.map((a) => {
      const exam = ctx.exams.find((e) => e.id === a.examId);
      const room = ctx.rooms.find((r) => r.id === a.roomId);
      const slot = ctx.timeSlots.find((t) => t.id === a.timeSlotId);
      const invigilators = a.invigilatorIds
        .map((id) => ctx.invigilators.find((i) => i.id === id))
        .filter(Boolean)
        .map((i) => ({ id: i!.id, name: i!.name, department: i!.department }));
      return {
        assignmentId: a.id,
        examId: a.examId,
        examName: exam?.name ?? '',
        subjectCode: exam?.subjectCode ?? '',
        examType: exam?.examType ?? 'final',
        duration: exam?.duration ?? 0,
        enrollmentCount: exam?.enrollmentCount ?? 0,
        date: a.date,
        dayName: dayName(a.date),
        startTime: slot?.startTime ?? '',
        endTime: slot?.endTime ?? '',
        slotLabel: slot?.label ?? null,
        room: room ? {
          id: room.id,
          name: room.name,
          code: room.code,
          capacity: room.capacity,
          location: room.location,
          building: room.building,
          floor: room.floor,
          features: room.features,
        } : null,
        invigilators,
        isPublished: a.isPublished,
        updatedAt: a.updatedAt,
      };
    });

    // Pending (unscheduled) exams for this group
    const scheduledExamIds = new Set(groupAssignments.map((a) => a.examId));
    const pendingExams = groupExams
      .filter((e) => !scheduledExamIds.has(e.id))
      .map((e) => ({
        examId: e.id,
        examName: e.name,
        subjectCode: e.subjectCode,
        examType: e.examType,
        duration: e.duration,
      }));

    // Recent changes from audit log
    const recentAudit = await db.auditLog.findMany({
      where: {
        OR: [
          { action: 'schedule.applied' },
          { action: 'scenario.applied' },
          { action: 'schedule.generated' },
        ],
      },
      orderBy: { createdAt: 'desc' },
      take: 10,
    });

    const changes = recentAudit.map((log) => ({
      id: log.id,
      action: log.action,
      summary: log.summary,
      timestamp: log.createdAt,
      relativeTime: getRelativeTime(log.createdAt),
    }));

    // Stats for this group
    const stats = {
      totalExams: groupExams.length,
      scheduledExams: groupAssignments.length,
      pendingExams: pendingExams.length,
      uniqueDates: new Set(groupAssignments.map((a) => a.date)).size,
      uniqueRooms: new Set(groupAssignments.map((a) => a.roomId)).size,
      totalInvigilators: new Set(groupAssignments.flatMap((a) => a.invigilatorIds)).size,
    };

    // Group info
    const groupInfo = {
      id: group.id,
      name: group.name,
      code: group.code,
      studentCount: group.studentCount,
      program: group.program,
      year: group.year,
    };

    return ok({
      group: groupInfo,
      schedule,
      pendingExams,
      changes,
      stats,
    });
  } catch (err) {
    return fail(`Student portal error: ${(err as Error).message}`, 500);
  }
}

function getRelativeTime(date: Date): string {
  const now = Date.now();
  const diff = now - new Date(date).getTime();
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
  if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
  return 'just now';
}
