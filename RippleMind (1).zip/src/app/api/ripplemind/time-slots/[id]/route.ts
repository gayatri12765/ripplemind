// /api/ripplemind/time-slots/[id] — PUT, DELETE
import { db, ok, fail, readBody, rowToTimeSlot } from '@/lib/api-helpers';
import { dayOfWeek } from '@/lib/time';

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await readBody<Record<string, unknown>>(req);
  if (!body) return fail('Invalid JSON body');
  try {
    const data: Record<string, unknown> = {};
    if (typeof body.date === 'string') {
      if (!body.date.match(/^\d{4}-\d{2}-\d{2}$/)) return fail('Date must be YYYY-MM-DD');
      data.date = body.date;
      data.dayOfWeek = dayOfWeek(body.date);
    }
    if (typeof body.startTime === 'string') {
      if (!body.startTime.match(/^\d{2}:\d{2}$/)) return fail('Start time must be HH:mm');
      data.startTime = body.startTime;
    }
    if (typeof body.endTime === 'string') {
      if (!body.endTime.match(/^\d{2}:\d{2}$/)) return fail('End time must be HH:mm');
      data.endTime = body.endTime;
    }
    if (data.startTime && data.endTime && data.startTime >= data.endTime) {
      return fail('Start time must be before end time');
    }
    if (body.label !== undefined) data.label = body.label;
    if (typeof body.isAvailable === 'boolean') data.isAvailable = body.isAvailable;
    const row = await db.timeSlot.update({ where: { id }, data });
    return ok({ timeSlot: rowToTimeSlot(row) });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const usage = await db.examAssignment.count({ where: { timeSlotId: id } });
    if (usage > 0) return fail(`Cannot delete: ${usage} assignments reference this slot`, 409);
    await db.timeSlot.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
