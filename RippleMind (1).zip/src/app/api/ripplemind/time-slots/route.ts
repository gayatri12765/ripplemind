// /api/ripplemind/time-slots — GET, POST
import { db, ok, fail, readBody, rowToTimeSlot } from '@/lib/api-helpers';
import { dayOfWeek } from '@/lib/time';

export async function GET() {
  try {
    const rows = await db.timeSlot.findMany({ orderBy: [{ date: 'asc' }, { startTime: 'asc' }] });
    return ok({ timeSlots: rows.map(rowToTimeSlot) });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function POST(req: Request) {
  const body = await readBody<{ date?: string; startTime?: string; endTime?: string; label?: string; isAvailable?: boolean }>(req);
  if (!body) return fail('Invalid JSON body');
  if (!body.date?.match(/^\d{4}-\d{2}-\d{2}$/)) return fail('Date must be YYYY-MM-DD');
  if (!body.startTime?.match(/^\d{2}:\d{2}$/)) return fail('Start time must be HH:mm');
  if (!body.endTime?.match(/^\d{2}:\d{2}$/)) return fail('End time must be HH:mm');
  if (body.startTime >= body.endTime) return fail('Start time must be before end time');
  try {
    const row = await db.timeSlot.create({
      data: {
        date: body.date,
        startTime: body.startTime,
        endTime: body.endTime,
        label: body.label ?? null,
        dayOfWeek: dayOfWeek(body.date),
        isAvailable: body.isAvailable ?? true,
      },
    });
    return ok({ timeSlot: rowToTimeSlot(row) }, 201);
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
