// GET /api/ripplemind/dashboard — real metrics from DB
import { ok, fail, loadContext } from '@/lib/api-helpers';
import { detectConflicts } from '@/lib/conflicts';
import { addDays, toISODate } from '@/lib/time';

export async function GET() {
  try {
    const ctx = await loadContext();
    const conflicts = detectConflicts({
      assignments: ctx.assignments.map((a) => ({
        examId: a.examId,
        timeSlotId: a.timeSlotId,
        roomId: a.roomId,
        invigilatorIds: a.invigilatorIds,
      })),
      context: ctx,
    });

    const totalExams = ctx.exams.length;
    const scheduledExams = ctx.assignments.length;
    const unscheduledExams = totalExams - scheduledExams;
    const availableRooms = ctx.rooms.filter((r) => r.isAvailable).length;
    const availableInvigilators = ctx.invigilators.filter((i) => i.isAvailable).length;

    const roomUsage = new Map<string, number>();
    for (const a of ctx.assignments) {
      roomUsage.set(a.roomId, (roomUsage.get(a.roomId) ?? 0) + 1);
    }
    const roomUtilization = ctx.rooms.length
      ? (roomUsage.size / ctx.rooms.length) * 100
      : 0;

    const invLoads = new Map<string, number>();
    for (const a of ctx.assignments) {
      for (const inv of a.invigilatorIds) {
        invLoads.set(inv, (invLoads.get(inv) ?? 0) + 1);
      }
    }
    const avgInvigilatorLoad = invLoads.size
      ? Array.from(invLoads.values()).reduce((s, v) => s + v, 0) / invLoads.size
      : 0;

    const today = toISODate(new Date());
    const horizonEnd = addDays(today, 30);
    const upcoming = ctx.assignments
      .filter((a) => a.date >= today && a.date <= horizonEnd)
      .sort((a, b) => a.date.localeCompare(b.date) || (a.timeSlot?.startTime ?? '').localeCompare(b.timeSlot?.startTime ?? ''))
      .slice(0, 8)
      .map((a) => ({
        id: a.id,
        name: a.exam?.name ?? 'Unknown',
        subjectCode: a.exam?.subjectCode ?? '',
        date: a.date,
        startTime: a.timeSlot?.startTime ?? '',
        endTime: a.timeSlot?.endTime ?? '',
        roomName: a.room?.name ?? '',
        studentGroupName: a.exam?.studentGroup?.name ?? '',
      }));

    const severityCounts = new Map<string, number>();
    for (const c of conflicts) {
      severityCounts.set(c.severity, (severityCounts.get(c.severity) ?? 0) + 1);
    }

    const typeCounts = new Map<string, number>();
    for (const e of ctx.exams) {
      typeCounts.set(e.examType, (typeCounts.get(e.examType) ?? 0) + 1);
    }

    const roomUtilByRoom = ctx.rooms.map((r) => ({
      roomId: r.id,
      roomName: r.name,
      utilization: ctx.assignments.length ? ((roomUsage.get(r.id) ?? 0) / ctx.assignments.length) * 100 : 0,
      assignments: roomUsage.get(r.id) ?? 0,
    })).sort((a, b) => b.assignments - a.assignments);

    return ok({
      totalExams,
      totalStudentGroups: ctx.studentGroups.length,
      availableRooms,
      availableInvigilators,
      scheduledExams,
      unscheduledExams,
      detectedConflicts: conflicts.length,
      roomUtilization,
      avgInvigilatorLoad,
      upcomingExaminations: upcoming,
      conflictsBySeverity: [
        { severity: 'critical', count: severityCounts.get('critical') ?? 0 },
        { severity: 'warning', count: severityCounts.get('warning') ?? 0 },
        { severity: 'info', count: severityCounts.get('info') ?? 0 },
      ],
      examsByType: Array.from(typeCounts.entries()).map(([type, count]) => ({ type, count })),
      roomUtilizationByRoom: roomUtilByRoom,
    });
  } catch (err) {
    return fail(`Dashboard error: ${(err as Error).message}`, 500);
  }
}
