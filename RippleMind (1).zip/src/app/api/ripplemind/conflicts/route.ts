// GET /api/ripplemind/conflicts — list all conflicts in the published timetable
import { ok, fail, loadContext } from '@/lib/api-helpers';
import { detectConflicts } from '@/lib/conflicts';

export async function GET() {
  try {
    const ctx = await loadContext();
    const conflicts = detectConflicts({
      assignments: ctx.assignments.map((a) => ({
        examId: a.examId,
        timeSlotId: a.timeSlotId,
        roomId: a.roomId,
        invigilatorIds: a.invigilatorIds,
      })),
      context: ctx,
    });
    return ok({ conflicts, totalConflicts: conflicts.length });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
