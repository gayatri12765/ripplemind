// /api/ripplemind/rooms/[id] — PUT, DELETE
import { db, ok, fail, readBody, rowToRoom, validatePositiveInt } from '@/lib/api-helpers';
import { stringifyJSON } from '@/lib/json';

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await readBody<Record<string, unknown>>(req);
  if (!body) return fail('Invalid JSON body');
  try {
    const data: Record<string, unknown> = {};
    if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim();
    if (typeof body.code === 'string' && body.code.trim()) {
      const conflict = await db.room.findFirst({ where: { code: body.code, NOT: { id } } });
      if (conflict) return fail('Code already in use', 409);
      data.code = body.code.trim();
    }
    if (body.capacity !== undefined) data.capacity = validatePositiveInt(body.capacity, 'Capacity');
    if (body.location !== undefined) data.location = body.location;
    if (body.building !== undefined) data.building = body.building;
    if (body.floor !== undefined) data.floor = body.floor;
    if (Array.isArray(body.features)) data.features = stringifyJSON(body.features);
    if (typeof body.isAvailable === 'boolean') data.isAvailable = body.isAvailable;
    const row = await db.room.update({ where: { id }, data });
    return ok({ room: rowToRoom(row) });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const usage = await db.examAssignment.count({ where: { roomId: id } });
    if (usage > 0) return fail(`Cannot delete: ${usage} assignments reference this room`, 409);
    await db.room.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
