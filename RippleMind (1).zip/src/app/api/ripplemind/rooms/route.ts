// /api/ripplemind/rooms — GET, POST
import { db, ok, fail, readBody, rowToRoom, validatePositiveInt, writeAuditLog } from '@/lib/api-helpers';
import { stringifyJSON } from '@/lib/json';

export async function GET() {
  try {
    const rows = await db.room.findMany({ orderBy: { name: 'asc' } });
    return ok({ rooms: rows.map(rowToRoom) });
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}

export async function POST(req: Request) {
  const body = await readBody<{ name?: string; code?: string; capacity?: number; location?: string; building?: string; floor?: number; features?: string[]; isAvailable?: boolean }>(req);
  if (!body) return fail('Invalid JSON body');
  if (!body.name?.trim()) return fail('Name is required');
  if (!body.code?.trim()) return fail('Code is required');
  let capacity: number;
  try {
    capacity = validatePositiveInt(body.capacity, 'Capacity');
  } catch (e) {
    return fail((e as Error).message);
  }
  try {
    const existing = await db.room.findUnique({ where: { code: body.code! } });
    if (existing) return fail('Code already exists', 409);
    const row = await db.room.create({
      data: {
        name: body.name.trim(),
        code: body.code.trim(),
        capacity,
        location: body.location ?? null,
        building: body.building ?? null,
        floor: body.floor ?? null,
        features: stringifyJSON(body.features ?? []),
        isAvailable: body.isAvailable ?? true,
      },
    });
    await writeAuditLog({ action: 'room.created', category: 'data', summary: `Created room ${row.name} (${row.code})`, target: row.id });
    return ok({ room: rowToRoom(row) }, 201);
  } catch (err) {
    return fail(`Failed: ${(err as Error).message}`, 500);
  }
}
