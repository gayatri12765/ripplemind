// RippleMind — main page. Handles auth-gated routing.
// Dynamic imports — only the current page compiles (keeps memory low for 4GB sandbox).

'use client';

import { useAuth } from '@/lib/auth';
import { LoginPage } from '@/pages/login';
import { StudentApp } from '@/components/student-app';
import { useNav } from '@/lib/store';
import { Sidebar } from '@/components/sidebar';
import { Topbar } from '@/components/topbar';
import dynamic from 'next/dynamic';
import { LoadingState } from '@/components/shared';

const DashboardPage = dynamic(() => import('@/pages/dashboard').then(m => ({ default: m.DashboardPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const ExamsPage = dynamic(() => import('@/pages/exams').then(m => ({ default: m.ExamsPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const StudentGroupsPage = dynamic(() => import('@/pages/student-groups').then(m => ({ default: m.StudentGroupsPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const RoomsPage = dynamic(() => import('@/pages/rooms').then(m => ({ default: m.RoomsPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const TimeSlotsPage = dynamic(() => import('@/pages/time-slots').then(m => ({ default: m.TimeSlotsPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const InvigilatorsPage = dynamic(() => import('@/pages/invigilators').then(m => ({ default: m.InvigilatorsPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const GenerateTimetablePage = dynamic(() => import('@/pages/generate-timetable').then(m => ({ default: m.GenerateTimetablePage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const TimetableViewerPage = dynamic(() => import('@/pages/timetable-viewer').then(m => ({ default: m.TimetableViewerPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const ConflictReportsPage = dynamic(() => import('@/pages/conflict-reports').then(m => ({ default: m.ConflictReportsPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const StudentPortalPage = dynamic(() => import('@/pages/student-portal').then(m => ({ default: m.StudentPortalPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const EmergencySimulationPage = dynamic(() => import('@/pages/emergency-simulation').then(m => ({ default: m.EmergencySimulationPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const SettingsPage = dynamic(() => import('@/pages/settings').then(m => ({ default: m.SettingsPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const WhatIfSimulationPage = dynamic(() => import('@/pages/what-if-simulation').then(m => ({ default: m.WhatIfSimulationPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const RippleAnalysisPage = dynamic(() => import('@/pages/ripple-analysis').then(m => ({ default: m.RippleAnalysisPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const AlternativeComparisonPage = dynamic(() => import('@/pages/alternative-comparison').then(m => ({ default: m.AlternativeComparisonPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const AIAssistantPage = dynamic(() => import('@/pages/ai-assistant').then(m => ({ default: m.AIAssistantPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const ScenarioHistoryPage = dynamic(() => import('@/pages/scenario-history').then(m => ({ default: m.ScenarioHistoryPage })), { loading: () => <LoadingState rows={3} />, ssr: false });
const AnalyticsPage = dynamic(() => import('@/pages/analytics').then(m => ({ default: m.AnalyticsPage })), { loading: () => <LoadingState rows={3} />, ssr: false });

export default function Home() {
  const { session } = useAuth();
  const { currentPage } = useNav();

  if (!session) return <LoginPage />;
  if (session.role === 'student') return <StudentApp />;

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard': return <DashboardPage />;
      case 'exams': return <ExamsPage />;
      case 'student-groups': return <StudentGroupsPage />;
      case 'rooms': return <RoomsPage />;
      case 'time-slots': return <TimeSlotsPage />;
      case 'invigilators': return <InvigilatorsPage />;
      case 'generate-timetable': return <GenerateTimetablePage />;
      case 'timetable-viewer': return <TimetableViewerPage />;
      case 'conflict-reports': return <ConflictReportsPage />;
      case 'student-portal': return <StudentPortalPage />;
      case 'emergency-simulation': return <EmergencySimulationPage />;
      case 'settings': return <SettingsPage />;
      case 'what-if-simulation': return <WhatIfSimulationPage />;
      case 'ripple-analysis': return <RippleAnalysisPage />;
      case 'alternative-comparison': return <AlternativeComparisonPage />;
      case 'ai-assistant': return <AIAssistantPage />;
      case 'scenario-history': return <ScenarioHistoryPage />;
      case 'analytics': return <AnalyticsPage />;
      default: return <DashboardPage />;
    }
  };

  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar />
        <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
