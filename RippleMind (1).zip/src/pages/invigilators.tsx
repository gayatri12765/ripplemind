// Invigilators Management page

'use client';

import { useState } from 'react';
import { useInvigilators, useCreateInvigilator, useUpdateInvigilator, useDeleteInvigilator } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, EmptyState } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { UserCheck, Plus, Pencil, Trash2, Search, Mail } from 'lucide-react';
import { toast } from 'sonner';
import type { Invigilator } from '@/lib/types';

export function InvigilatorsPage() {
  const { data: invs, isLoading, isError, refetch } = useInvigilators();
  const createMut = useCreateInvigilator();
  const updateMut = useUpdateInvigilator();
  const deleteMut = useDeleteInvigilator();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Invigilator | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ name: '', email: '', department: '', maxWorkload: 3, isAvailable: true });

  const filtered = invs?.filter((i) => i.name.toLowerCase().includes(search.toLowerCase()) || (i.department ?? '').toLowerCase().includes(search.toLowerCase())) ?? [];

  const openCreate = () => { setEditing(null); setForm({ name: '', email: '', department: '', maxWorkload: 3, isAvailable: true }); setDialogOpen(true); };
  const openEdit = (i: Invigilator) => { setEditing(i); setForm({ name: i.name, email: i.email ?? '', department: i.department ?? '', maxWorkload: i.maxWorkload, isAvailable: i.isAvailable }); setDialogOpen(true); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) { toast.error('Name is required'); return; }
    if (form.maxWorkload <= 0) { toast.error('Max workload must be positive'); return; }
    try {
      const payload = { ...form, email: form.email || undefined, department: form.department || undefined, availability: [] };
      if (editing) { await updateMut.mutateAsync({ id: editing.id, data: payload }); toast.success('Invigilator updated'); }
      else { await createMut.mutateAsync(payload); toast.success('Invigilator created'); }
      setDialogOpen(false);
    } catch (err) { toast.error((err as Error).message); }
  };
  const handleDelete = async () => { if (!deleteId) return; try { await deleteMut.mutateAsync(deleteId); toast.success('Deleted'); setDeleteId(null); } catch (err) { toast.error((err as Error).message); } };

  return (
    <div className="space-y-6">
      <PageHeader title="Invigilators" description="Manage invigilators with availability, department, and maximum daily workload."
        breadcrumbs={[{ label: 'Home' }, { label: 'Resources' }, { label: 'Invigilators' }]}
        actions={<Button onClick={openCreate} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Plus className="h-4 w-4 mr-1" /> Add Invigilator</Button>} />

      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-warm-muted" />
          <Input placeholder="Search invigilators…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
      </div>

      {isLoading ? <LoadingState message="Loading invigilators…" /> :
       isError ? <ErrorState message="Failed to load" onRetry={() => refetch()} /> :
       filtered.length === 0 ? (
         <EmptyState title="No invigilators" description="Add your first invigilator." icon={<UserCheck className="h-8 w-8 text-warm-muted" />}
           action={!search && <Button onClick={openCreate} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Plus className="h-4 w-4 mr-1" /> Add Invigilator</Button>} />
       ) : (
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
           {filtered.map((i) => (
             <Card key={i.id} className={`border-warm shadow-warm hover:shadow-warm-md transition-shadow ${!i.isAvailable ? 'opacity-60' : ''}`}>
               <CardContent className="p-5">
                 <div className="flex items-start justify-between">
                   <div className={`rounded-full p-2.5 shadow-warm ${i.isAvailable ? 'bg-gradient-to-br from-[#FF6B35] to-[#D62828]' : 'bg-gray-300'}`}>
                     <UserCheck className="h-5 w-5 text-white" />
                   </div>
                   <div className="flex gap-1">
                     <Button variant="ghost" size="icon" onClick={() => openEdit(i)}><Pencil className="h-4 w-4" /></Button>
                     <Button variant="ghost" size="icon" onClick={() => setDeleteId(i.id)}><Trash2 className="h-4 w-4 text-red-600" /></Button>
                   </div>
                 </div>
                 <h3 className="font-bold text-foreground mt-3">{i.name}</h3>
                 {i.email && <p className="text-xs text-warm-muted flex items-center gap-1 mt-1"><Mail className="h-3 w-3" />{i.email}</p>}
                 <div className="mt-3 space-y-1.5 text-sm">
                   {i.department && <div className="flex items-center justify-between"><span className="text-warm-muted">Department</span><Badge variant="outline" className="text-xs">{i.department}</Badge></div>}
                   <div className="flex items-center justify-between"><span className="text-warm-muted">Max workload</span><span className="font-semibold">{i.maxWorkload}/day</span></div>
                   <div className="flex items-center justify-between pt-1">
                     <span className="text-xs text-warm-muted">Available</span>
                     <Switch checked={i.isAvailable} onCheckedChange={async (v) => { await updateMut.mutateAsync({ id: i.id, data: { isAvailable: v } }); toast.success(`Invigilator ${v ? 'enabled' : 'disabled'}`); }} />
                   </div>
                 </div>
               </CardContent>
             </Card>
           ))}
         </div>
       )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editing ? 'Edit Invigilator' : 'Add Invigilator'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2"><Label>Name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
            <div className="space-y-2"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-2"><Label>Department</Label><Input value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} /></div>
            <div className="space-y-2"><Label>Max Workload (assignments per day)</Label><Input type="number" min={1} max={10} value={form.maxWorkload} onChange={(e) => setForm({ ...form, maxWorkload: Number(e.target.value) })} /></div>
            <div className="flex items-center gap-2"><Switch checked={form.isAvailable} onCheckedChange={(v) => setForm({ ...form, isAvailable: v })} /><Label>Available for scheduling</Label></div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-[#FF6B35] hover:bg-[#E85D04] text-white" disabled={createMut.isPending || updateMut.isPending}>{editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete this invigilator?</AlertDialogTitle><AlertDialogDescription>Assignments using this invigilator must be removed first.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
