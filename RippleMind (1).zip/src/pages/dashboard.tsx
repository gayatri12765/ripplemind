// Dashboard page — LIGHTWEIGHT version (no Recharts) for reliable preview in 4GB sandbox
'use client';

import { useDashboard } from '@/lib/api';
import { PageHeader, StatCard, LoadingState, ErrorState, SectionCard } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useNav } from '@/lib/store';
import {
  FileText, Users, DoorOpen, UserCheck, CalendarCheck, AlertTriangle,
  TrendingUp, Clock, ArrowRight, Activity,
} from 'lucide-react';
import { formatDate, formatTimeRange } from '@/lib/time';

export function DashboardPage() {
  const { data: metrics, isLoading, isError, refetch } = useDashboard();
  const { navigate } = useNav();

  if (isLoading) return <LoadingState message="Loading dashboard metrics…" rows={4} />;
  if (isError || !metrics) return <ErrorState message="Failed to load dashboard" onRetry={() => refetch()} />;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dashboard"
        description="Real-time overview of examinations, resources, conflicts, and scheduling status."
        breadcrumbs={[{ label: 'Home' }, { label: 'Dashboard' }]}
      />

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Exams" value={metrics.totalExams} icon={<FileText className="h-5 w-5" />} accent="orange" subtitle={`${metrics.scheduledExams} scheduled · ${metrics.unscheduledExams} pending`} />
        <StatCard title="Student Groups" value={metrics.totalStudentGroups} icon={<Users className="h-5 w-5" />} accent="amber" />
        <StatCard title="Available Rooms" value={metrics.availableRooms} icon={<DoorOpen className="h-5 w-5" />} accent="green" subtitle={`${Math.round(metrics.roomUtilization)}% utilized`} />
        <StatCard title="Invigilators" value={metrics.availableInvigilators} icon={<UserCheck className="h-5 w-5" />} accent="blue" subtitle={`${metrics.avgInvigilatorLoad.toFixed(1)} avg load`} />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Scheduled Exams" value={metrics.scheduledExams} icon={<CalendarCheck className="h-5 w-5" />} accent="green" />
        <StatCard title="Detected Conflicts" value={metrics.detectedConflicts} icon={<AlertTriangle className="h-5 w-5" />} accent="red" subtitle={metrics.detectedConflicts === 0 ? 'All clear' : 'Needs attention'} />
        <StatCard title="Room Utilization" value={`${metrics.roomUtilization.toFixed(1)}%`} icon={<TrendingUp className="h-5 w-5" />} accent="orange" />
        <StatCard title="Avg Invigilator Load" value={metrics.avgInvigilatorLoad.toFixed(1)} icon={<Clock className="h-5 w-5" />} accent="amber" />
      </div>

      {/* Conflicts by severity (CSS bars, no Recharts) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SectionCard title="Conflicts by Severity" description="Current conflict distribution">
          <div className="space-y-3">
            {metrics.conflictsBySeverity.map((s) => {
              const max = Math.max(...metrics.conflictsBySeverity.map((x) => x.count), 1);
              const pct = (s.count / max) * 100;
              const color = s.severity === 'critical' ? '#D62828' : s.severity === 'warning' ? '#F77F00' : '#3C91E6';
              return (
                <div key={s.severity}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium capitalize">{s.severity}</span>
                    <span className="text-sm font-bold" style={{ color }}>{s.count}</span>
                  </div>
                  <div className="h-3 bg-cream-deep rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: color }} />
                  </div>
                </div>
              );
            })}
            {metrics.detectedConflicts === 0 && (
              <div className="flex flex-col items-center justify-center py-6 text-center">
                <div className="rounded-full bg-green-50 p-3 mb-2">
                  <CalendarCheck className="h-6 w-6 text-green-600" />
                </div>
                <p className="font-semibold text-green-700">No conflicts detected</p>
                <p className="text-xs text-warm-muted">The current timetable is clean.</p>
              </div>
            )}
          </div>
        </SectionCard>

        {/* Exam types (CSS bars) */}
        <SectionCard title="Exams by Type" description="Distribution across exam categories">
          <div className="space-y-3">
            {metrics.examsByType.map((e, i) => {
              const max = Math.max(...metrics.examsByType.map((x) => x.count), 1);
              const pct = (e.count / max) * 100;
              const colors = ['#FF6B35', '#D62828', '#F77F00', '#FCBF49', '#8C2F0C'];
              return (
                <div key={e.type}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium capitalize">{e.type}</span>
                    <span className="text-sm font-bold">{e.count}</span>
                  </div>
                  <div className="h-3 bg-cream-deep rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: colors[i % colors.length] }} />
                  </div>
                </div>
              );
            })}
            {metrics.examsByType.length === 0 && <p className="text-sm text-warm-muted text-center py-6">No exam data yet.</p>}
          </div>
        </SectionCard>
      </div>

      {/* Upcoming examinations */}
      <SectionCard
        title="Upcoming Examinations"
        description="Next scheduled exams"
        actions={<Button variant="ghost" size="sm" onClick={() => navigate('timetable-viewer')}>View all <ArrowRight className="h-3 w-3 ml-1" /></Button>}
      >
        {metrics.upcomingExaminations.length > 0 ? (
          <div className="space-y-2 max-h-[300px] overflow-y-auto scrollbar-thin">
            {metrics.upcomingExaminations.map((exam) => (
              <div key={exam.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-cream-deep transition-colors">
                <div className="rounded-lg bg-gradient-to-br from-[#FF6B35] to-[#F77F00] text-white p-2 text-center min-w-[52px]">
                  <p className="text-[10px] uppercase">{formatDate(exam.date).split(' ')[0]}</p>
                  <p className="text-lg font-bold leading-none">{formatDate(exam.date).split(' ')[1]}</p>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{exam.name}</p>
                  <p className="text-xs text-warm-muted">{exam.subjectCode} · {exam.studentGroupName}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-medium text-foreground">{formatTimeRange(exam.startTime, exam.endTime)}</p>
                  <p className="text-[10px] text-warm-muted">{exam.roomName}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-sm text-warm-muted">No upcoming examinations scheduled.</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={() => navigate('generate-timetable')}>
              Generate Timetable
            </Button>
          </div>
        )}
      </SectionCard>

      {/* Quick actions */}
      <SectionCard title="Quick Actions" description="Common administrative tasks">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <Button variant="outline" className="justify-start" onClick={() => navigate('generate-timetable')}>
            <CalendarCheck className="h-4 w-4 mr-2" /> Generate Timetable
          </Button>
          <Button variant="outline" className="justify-start" onClick={() => navigate('what-if-simulation')}>
            <AlertTriangle className="h-4 w-4 mr-2" /> What-if Simulation
          </Button>
          <Button variant="outline" className="justify-start" onClick={() => navigate('conflict-reports')}>
            <AlertTriangle className="h-4 w-4 mr-2" /> View Conflicts
          </Button>
          <Button variant="outline" className="justify-start" onClick={() => navigate('emergency-simulation')}>
            <Activity className="h-4 w-4 mr-2" /> Emergency Simulation
          </Button>
        </div>
      </SectionCard>
    </div>
  );
}
