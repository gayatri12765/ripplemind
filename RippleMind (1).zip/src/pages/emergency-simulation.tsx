// Emergency Room Outage Simulation page
// Simulate a room going offline (maintenance, flood, fire, etc.) and re-schedule affected exams.

'use client';

import { useState } from 'react';
import { useRooms, useExams, useTimeSlots, useInvigilators, useStudentGroups, useEmergencyOutage, useApplySchedule } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, EmptyState, SectionCard } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Siren, AlertTriangle, CheckCircle2, XCircle, Clock, DoorOpen, Users,
  Building, Zap, ArrowRight, ShieldAlert, Activity,
} from 'lucide-react';
import { toast } from 'sonner';
import { CSSHBarChart } from '@/components/css-charts';
import { formatDate, formatTimeRange } from '@/lib/time';

export function EmergencySimulationPage() {
  const { data: rooms, isLoading: roomsLoading } = useRooms();
  const { data: exams } = useExams();
  const { data: slots } = useTimeSlots();
  const { data: invs } = useInvigilators();
  const { data: groups } = useStudentGroups();
  const outageMut = useEmergencyOutage();
  const applyMut = useApplySchedule();

  const [roomId, setRoomId] = useState('');
  const [reason, setReason] = useState('');
  const [result, setResult] = useState<any>(null);

  const handleSimulate = async () => {
    if (!roomId) { toast.error('Select a room to simulate outage'); return; }
    if (!reason.trim()) { toast.error('Please describe the reason for the outage'); return; }
    try {
      const res = await outageMut.mutateAsync({ roomId, reason: reason.trim() });
      setResult(res);
      if (res.solution?.feasible) {
        toast.success(`Emergency re-scheduling complete: ${res.changedExamIds.length} exams moved`);
      } else if (res.solution) {
        toast.warning(`Re-scheduling done with ${res.solution.unscheduled.length} unscheduled exams`);
      } else {
        toast.info(res.message);
      }
    } catch (err) { toast.error((err as Error).message); }
  };

  const handleApply = async () => {
    if (!result?.solution?.feasible) return;
    try {
      await applyMut.mutateAsync({ assignments: result.solution.assignments, mode: 'replace' });
      toast.success('Emergency timetable published');
      setResult(null);
    } catch (err) { toast.error((err as Error).message); }
  };

  const selectedRoom = rooms?.find((r) => r.id === roomId);
  const affectedExams = result?.affectedExams ?? [];

  // Build before/after comparison data
  const comparisonData = result ? [
    { name: 'Affected', Original: affectedExams.length, Reassigned: affectedExams.filter((e: any) => result.solution.assignments.find((a: any) => a.examId === e.id)).length },
    { name: 'Unscheduled', Original: 0, Reassigned: result.solution.unscheduled.length },
    { name: 'Conflicts', Original: 0, Reassigned: result.solution.conflicts.length },
    { name: 'Capacity Waste', Original: 0, Reassigned: result.solution.metrics.capacityWaste },
  ] : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Emergency Simulation"
        description="Simulate a room outage (maintenance, damage, double-booking) and automatically re-schedule all affected exams. The solver uses Google OR-Tools CP-SAT when available, with a greedy fallback."
        breadcrumbs={[{ label: 'Home' }, { label: 'Scheduling' }, { label: 'Emergency' }]}
      />

      {/* Solver status banner */}
      <Alert className="border-[#FF6B35]/30 bg-orange-50">
        <ShieldAlert className="h-4 w-4 text-[#FF6B35]" />
        <AlertDescription className="text-orange-800 text-sm">
          <strong>Solver:</strong> {result?.orToolsAvailable ? 'Google OR-Tools CP-SAT (installed)' : 'Greedy fallback (OR-Tools not installed)'}.
          The greedy solver uses first-fit assignment with local search optimization, considering room capacity, scheduling conflicts, exam duration, and assignment stability.
        </AlertDescription>
      </Alert>

      {/* Step 1: Select room and reason */}
      <SectionCard title="Step 1: Declare Room Outage" description="Select the room that is unavailable and describe the reason.">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Affected Room *</Label>
              <Select value={roomId} onValueChange={setRoomId}>
                <SelectTrigger><SelectValue placeholder="Select the unavailable room…" /></SelectTrigger>
                <SelectContent>
                  {rooms?.map((r) => {
                    const examCount = exams?.filter((e) => e.assignment?.roomId === r.id).length ?? 0;
                    return (
                      <SelectItem key={r.id} value={r.id}>
                        {r.name} ({r.code}) — cap {r.capacity} · {examCount} exam(s)
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Reason for Outage *</Label>
              <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. HVAC failure, flooding, fire safety" />
            </div>
          </div>

          {selectedRoom && (
            <Alert className="border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800 text-sm">
                <strong>{selectedRoom.name}</strong> ({selectedRoom.code}) has capacity {selectedRoom.capacity} and is located at {selectedRoom.location ?? 'unknown location'}.
                All exams assigned to this room will need to be re-scheduled.
              </AlertDescription>
            </Alert>
          )}

          <div className="flex justify-end">
            <Button onClick={handleSimulate} disabled={outageMut.isPending || !roomId || !reason.trim()}
              className="bg-gradient-to-r from-[#D62828] to-[#FF6B35] text-white hover:opacity-90">
              {outageMut.isPending ? <><Clock className="h-4 w-4 mr-2 animate-spin" /> Simulating…</> : <><Siren className="h-4 w-4 mr-2" /> Simulate Outage</>}
            </Button>
          </div>
        </div>
      </SectionCard>

      {/* Results */}
      {result && result.solution && (
        <SectionCard
          title="Step 2: Re-scheduling Results"
          description={result.solution.feasible
            ? `${result.changedExamIds.length} exam(s) re-scheduled successfully. ${result.solution.unscheduled.length} could not be placed.`
            : 'Re-scheduling completed with issues. Review the unscheduled exams below.'}
          actions={
            result.solution.feasible && result.solution.assignments.length > 0 && (
              <Button onClick={handleApply} disabled={applyMut.isPending} className="bg-green-600 hover:bg-green-700 text-white">
                <CheckCircle2 className="h-4 w-4 mr-2" /> Apply Revised Timetable
              </Button>
            )
          }
        >
          <div className="space-y-4">
            {/* Stat cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div className={`rounded-xl p-4 border-2 ${result.solution.feasible ? 'border-green-300 bg-green-50' : 'border-red-300 bg-red-50'}`}>
                <p className="text-xs text-warm-muted uppercase">Status</p>
                <div className="flex items-center gap-2 mt-1">
                  {result.solution.feasible
                    ? <><CheckCircle2 className="h-5 w-5 text-green-600" /><span className="text-lg font-bold text-green-700">Feasible</span></>
                    : <><XCircle className="h-5 w-5 text-red-600" /><span className="text-lg font-bold text-red-700">Issues</span></>}
                </div>
              </div>
              <div className="rounded-xl p-4 border-2 border-[#FF6B35]/30 bg-orange-50">
                <p className="text-xs text-warm-muted uppercase flex items-center gap-1"><Activity className="h-3 w-3" /> Re-scheduled</p>
                <p className="text-2xl font-bold text-[#FF6B35] mt-1">{result.changedExamIds.length}</p>
                <p className="text-[10px] text-warm-muted">of {affectedExams.length} affected</p>
              </div>
              <div className="rounded-xl p-4 border-2 border-red-200 bg-red-50">
                <p className="text-xs text-warm-muted uppercase">Unscheduled</p>
                <p className="text-2xl font-bold text-red-600 mt-1">{result.solution.unscheduled.length}</p>
                <p className="text-[10px] text-warm-muted">no alternative found</p>
              </div>
              <div className="rounded-xl p-4 border-2 border-blue-200 bg-blue-50">
                <p className="text-xs text-warm-muted uppercase flex items-center gap-1"><Zap className="h-3 w-3" /> Solver Time</p>
                <p className="text-2xl font-bold text-blue-600 mt-1">{result.solution.metrics.elapsedMs}<span className="text-sm">ms</span></p>
                <p className="text-[10px] text-warm-muted">{result.solverUsed}</p>
              </div>
            </div>

            {/* Comparison chart */}
            {comparisonData.length > 0 && (
              <Card className="border-warm shadow-warm">
                <CardContent className="p-5">
                  <h4 className="text-sm font-semibold mb-3">Impact Comparison</h4>
                  <div className="space-y-3">
                    {comparisonData.map((c, i) => {
                      const max = Math.max(c.Original, c.Reassigned, 1);
                      return (
                        <div key={i}>
                          <div className="text-xs font-medium mb-1">{c.name}</div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] text-warm-muted w-16">Original</span>
                            <div className="flex-1 h-3 bg-cream-deep rounded overflow-hidden"><div className="h-full rounded transition-all duration-700" style={{ width: `${(c.Original / max) * 100}%`, background: '#8C5A3F' }} /></div>
                            <span className="text-[10px] font-bold w-8 text-right">{c.Original}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-warm-muted w-16">Reassigned</span>
                            <div className="flex-1 h-3 bg-cream-deep rounded overflow-hidden"><div className="h-full rounded transition-all duration-700" style={{ width: `${(c.Reassigned / max) * 100}%`, background: '#FF6B35' }} /></div>
                            <span className="text-[10px] font-bold w-8 text-right">{c.Reassigned}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Affected exams detail */}
            <div>
              <h4 className="text-sm font-semibold mb-2">Affected Exams ({affectedExams.length})</h4>
              <div className="rounded-lg border border-warm overflow-hidden overflow-x-auto">
                <table className="w-full text-sm min-w-[600px]">
                  <thead className="bg-cream-deep">
                    <tr>
                      <th className="text-left p-2">Exam</th>
                      <th className="text-left p-2">Original</th>
                      <th className="text-left p-2">New Assignment</th>
                      <th className="text-center p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {affectedExams.map((exam: any) => {
                      const newAssign = result.solution.assignments.find((a: any) => a.examId === exam.id);
                      const newRoom = newAssign ? rooms?.find((r) => r.id === newAssign.roomId) : null;
                      const newSlot = newAssign ? slots?.find((s) => s.id === newAssign.timeSlotId) : null;
                      const origSlot = exam.originalAssignment?.timeSlotId ? slots?.find((s) => s.id === exam.originalAssignment.timeSlotId) : null;
                      const origRoom = exam.originalAssignment?.roomId ? rooms?.find((r) => r.id === exam.originalAssignment.roomId) : null;
                      return (
                        <tr key={exam.id} className="border-t border-warm">
                          <td className="p-2">
                            <div className="font-medium">{exam.name}</div>
                            <div className="text-xs text-warm-muted font-mono">{exam.subjectCode}</div>
                          </td>
                          <td className="p-2 text-xs">
                            <div>{origSlot ? formatDate(origSlot.date) : '—'}</div>
                            <div className="text-warm-muted">{origSlot ? formatTimeRange(origSlot.startTime, origSlot.endTime) : ''}</div>
                            <div className="text-warm-muted">{origRoom?.name ?? '—'}</div>
                          </td>
                          <td className="p-2 text-xs">
                            {newAssign ? (
                              <>
                                <div>{newSlot ? formatDate(newSlot.date) : '—'}</div>
                                <div className="text-warm-muted">{newSlot ? formatTimeRange(newSlot.startTime, newSlot.endTime) : ''}</div>
                                <div className="font-medium text-[#FF6B35]">{newRoom?.name ?? '—'}</div>
                              </>
                            ) : (
                              <Badge variant="destructive" className="text-xs">No alternative</Badge>
                            )}
                          </td>
                          <td className="p-2 text-center">
                            {newAssign
                              ? <Badge className="bg-green-100 text-green-800 text-xs">Reassigned</Badge>
                              : <Badge variant="destructive" className="text-xs">Unscheduled</Badge>}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Unscheduled exams */}
            {result.solution.unscheduled.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold mb-2 text-red-700">Unscheduled Exams ({result.solution.unscheduled.length})</h4>
                <div className="space-y-1">
                  {result.solution.unscheduled.map((u: any) => {
                    const exam = exams?.find((e) => e.id === u.examId);
                    return (
                      <div key={u.examId} className="text-sm p-2 rounded-lg bg-red-50 border border-red-100">
                        <span className="font-medium">{exam?.name ?? u.examId}</span>
                        <span className="text-warm-muted ml-2">— {u.reason}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Conflicts */}
            {result.solution.conflicts.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold mb-2 text-amber-700">Conflicts in Revised Schedule ({result.solution.conflicts.length})</h4>
                <div className="space-y-1 max-h-40 overflow-y-auto scrollbar-thin">
                  {result.solution.conflicts.slice(0, 10).map((c: any) => (
                    <div key={c.id} className="text-sm p-2 rounded-lg bg-amber-50 border border-amber-100">
                      <Badge variant={c.severity === 'critical' ? 'destructive' : 'secondary'} className="text-xs mr-2">{c.severity}</Badge>
                      <span className="font-medium">{c.title}:</span> <span className="text-warm-muted">{c.description}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </SectionCard>
      )}

      {roomsLoading && <LoadingState message="Loading rooms…" />}
    </div>
  );
}
