// Generate Timetable page — runs the CP solver and applies the solution

'use client';

import { useState } from 'react';
import { useGenerateSchedule, useApplySchedule, useExams, useRooms, useTimeSlots, useInvigilators } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, SectionCard, StatCard } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Wand2, Play, CheckCircle2, XCircle, AlertTriangle, Clock, Cpu, Gauge, Zap } from 'lucide-react';
import { toast } from 'sonner';
import type { SolverSolution } from '@/lib/types';

export function GenerateTimetablePage() {
  const generateMut = useGenerateSchedule();
  const applyMut = useApplySchedule();
  const { data: exams } = useExams();
  const { data: rooms } = useRooms();
  const { data: slots } = useTimeSlots();
  const { data: invs } = useInvigilators();

  const [solution, setSolution] = useState<SolverSolution | null>(null);
  const [generateAlts, setGenerateAlts] = useState(false);
  const [timeLimit, setTimeLimit] = useState(3000);
  const [solverMode, setSolverMode] = useState<'cp' | 'greedy'>('cp');
  const [solverUsed, setSolverUsed] = useState<string>('');
  const [weights, setWeights] = useState({ changedExams: 10, roomChanges: 8, capacityWaste: 1, preferredSlots: 5, workload: 4 });

  const handleGenerate = async () => {
    setSolution(null);
    try {
      const res = await generateMut.mutateAsync({
        generateAlternatives: generateAlts,
        timeLimitMs: timeLimit,
        maxAlternatives: 3,
        solverMode,
        objectiveWeights: {
          minimizeChangedExams: weights.changedExams,
          minimizeRoomChanges: weights.roomChanges,
          minimizeCapacityWaste: weights.capacityWaste,
          respectPreferredSlots: weights.preferredSlots,
          balanceInvigilatorWorkload: weights.workload,
        },
      });
      setSolution(res.solution);
      setSolverUsed(res.solverUsed ?? '');
      if (res.solution.feasible) toast.success(`Feasible schedule found: ${res.solution.assignments.length} exams scheduled`);
      else if (res.solution.provenInfeasible) toast.error('No feasible schedule exists with the current constraints');
      else toast.warning('Solver timed out — try increasing the time limit');
    } catch (err) { toast.error((err as Error).message); }
  };

  const handleApply = async () => {
    if (!solution?.feasible) return;
    try {
      await applyMut.mutateAsync({ assignments: solution.assignments, mode: 'replace' });
      toast.success('Timetable published successfully');
    } catch (err) { toast.error((err as Error).message); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Generate Timetable" description="Run the constraint-programming solver to automatically assign exams to rooms, time slots, and invigilators."
        breadcrumbs={[{ label: 'Home' }, { label: 'Scheduling' }, { label: 'Generate' }]} />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Exams to Schedule" value={exams?.length ?? 0} icon={<Wand2 className="h-5 w-5" />} accent="orange" />
        <StatCard title="Available Rooms" value={rooms?.filter(r => r.isAvailable).length ?? 0} icon={<Clock className="h-5 w-5" />} accent="green" />
        <StatCard title="Time Slots" value={slots?.filter(s => s.isAvailable).length ?? 0} icon={<Clock className="h-5 w-5" />} accent="blue" />
        <StatCard title="Invigilators" value={invs?.filter(i => i.isAvailable).length ?? 0} icon={<Cpu className="h-5 w-5" />} accent="amber" />
      </div>

      <SectionCard title="Solver Configuration" description="Adjust objective weights to influence the solver's priorities. Hard constraints are always enforced.">
        <div className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label className="mb-2 block">Solver Mode</Label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSolverMode('cp')}
                    className={`p-3 rounded-lg border-2 text-left transition-all ${solverMode === 'cp' ? 'border-[#FF6B35] bg-orange-50 shadow-warm' : 'border-warm bg-white hover:bg-cream-deep'}`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Cpu className="h-4 w-4 text-[#FF6B35]" />
                      <span className="font-medium text-sm">CP Solver</span>
                    </div>
                    <p className="text-[10px] text-warm-muted">OR-Tools CP-SAT (optimal, slower)</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSolverMode('greedy')}
                    className={`p-3 rounded-lg border-2 text-left transition-all ${solverMode === 'greedy' ? 'border-[#FF6B35] bg-orange-50 shadow-warm' : 'border-warm bg-white hover:bg-cream-deep'}`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Zap className="h-4 w-4 text-[#FF6B35]" />
                      <span className="font-medium text-sm">Greedy</span>
                    </div>
                    <p className="text-[10px] text-warm-muted">First-fit + local search (fast)</p>
                  </button>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>Time Limit: {timeLimit}ms</Label>
                  <Badge variant="outline">{(timeLimit / 1000).toFixed(1)}s</Badge>
                </div>
                <Slider value={[timeLimit]} min={1000} max={15000} step={1000} onValueChange={(v) => setTimeLimit(v[0])} />
              </div>
              <div className="flex items-center justify-between">
                <div><Label>Generate Alternatives</Label><p className="text-xs text-warm-muted">Produce multiple feasible solutions for comparison</p></div>
                <Switch checked={generateAlts} onCheckedChange={setGenerateAlts} />
              </div>
            </div>
            <div className="space-y-3">
              <Label>Objective Weights</Label>
              {([
                ['changedExams', 'Minimize changed exams'],
                ['roomChanges', 'Minimize room changes'],
                ['capacityWaste', 'Minimize capacity waste'],
                ['preferredSlots', 'Respect preferred slots'],
                ['workload', 'Balance invigilator workload'],
              ] as const).map(([key, label]) => (
                <div key={key}>
                  <div className="flex justify-between text-xs mb-1"><span>{label}</span><span className="font-mono">{weights[key]}</span></div>
                  <Slider value={[weights[key]]} min={0} max={100} step={1} onValueChange={(v) => setWeights({ ...weights, [key]: v[0] })} />
                </div>
              ))}
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-warm">
            <Button onClick={handleGenerate} disabled={generateMut.isPending} className="bg-gradient-to-r from-[#FF6B35] to-[#D62828] text-white hover:opacity-90">
              {generateMut.isPending ? <><Clock className="h-4 w-4 mr-2 animate-spin" /> Solving…</> : <><Wand2 className="h-4 w-4 mr-2" /> Generate Timetable</>}
            </Button>
          </div>
        </div>
      </SectionCard>

      {solution && (
        <SectionCard title="Solver Results" description={solution.feasible ? 'Feasible schedule found' : solution.provenInfeasible ? 'No feasible schedule exists' : 'Solver timed out'}
          actions={
            solution.feasible && (
              <Button onClick={handleApply} disabled={applyMut.isPending} className="bg-green-600 hover:bg-green-700 text-white">
                <CheckCircle2 className="h-4 w-4 mr-2" /> Apply & Publish
              </Button>
            )
          }>
          <div className="space-y-4">
            {solverUsed && (
              <div className="flex items-center gap-2 text-xs">
                <Badge variant="outline" className="bg-cream">
                  {solverUsed === 'or-tools-cp-sat' ? 'OR-Tools CP-SAT' : solverUsed === 'greedy-fallback' ? 'Greedy Fallback' : 'TypeScript CP Solver'}
                </Badge>
                <span className="text-warm-muted">was used for this run</span>
              </div>
            )}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="rounded-lg bg-cream p-3"><p className="text-xs text-warm-muted">Scheduled</p><p className="text-xl font-bold text-green-600">{solution.metrics.scheduledExams}</p></div>
              <div className="rounded-lg bg-cream p-3"><p className="text-xs text-warm-muted">Unscheduled</p><p className="text-xl font-bold text-red-600">{solution.unscheduled.length}</p></div>
              <div className="rounded-lg bg-cream p-3"><p className="text-xs text-warm-muted">Conflicts</p><p className="text-xl font-bold text-amber-600">{solution.conflicts.length}</p></div>
              <div className="rounded-lg bg-cream p-3"><p className="text-xs text-warm-muted">Solver Nodes</p><p className="text-xl font-bold">{solution.metrics.searchNodes}</p></div>
            </div>

            {solution.feasible ? (
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  Feasible schedule found in {solution.metrics.elapsedMs}ms. Room utilization: {solution.metrics.roomUtilization.toFixed(1)}%. Avg invigilator load: {solution.metrics.avgInvigilatorLoad.toFixed(1)}.
                  Click <strong>Apply & Publish</strong> to commit this timetable.
                </AlertDescription>
              </Alert>
            ) : solution.provenInfeasible ? (
              <Alert className="border-red-200 bg-red-50">
                <XCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  <strong>Proven infeasible.</strong> The solver exhausted all possibilities. Add more rooms, time slots, or invigilators, or reduce enrollment counts.
                </AlertDescription>
              </Alert>
            ) : (
              <Alert className="border-amber-200 bg-amber-50">
                <Clock className="h-4 w-4 text-amber-600" />
                <AlertDescription className="text-amber-800">
                  <strong>Timed out.</strong> The solver could not exhaust the search tree within {timeLimit}ms. Try increasing the time limit or simplifying constraints.
                </AlertDescription>
              </Alert>
            )}

            {solution.unscheduled.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold mb-2 text-red-700">Unscheduled Exams ({solution.unscheduled.length})</h4>
                <div className="space-y-1">
                  {solution.unscheduled.map((u) => {
                    const exam = exams?.find((e) => e.id === u.examId);
                    return (
                      <div key={u.examId} className="text-sm p-2 rounded-lg bg-red-50 border border-red-100">
                        <span className="font-medium">{exam?.name ?? u.examId}</span>
                        <span className="text-warm-muted ml-2">— {u.reason}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {solution.feasible && solution.assignments.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold mb-2">Proposed Assignments ({solution.assignments.length})</h4>
                <div className="rounded-lg border border-warm overflow-hidden max-h-96 overflow-y-auto scrollbar-thin">
                  <table className="w-full text-sm">
                    <thead className="bg-cream-deep sticky top-0">
                      <tr><th className="text-left p-2">Exam</th><th className="text-left p-2">Date</th><th className="text-left p-2">Time</th><th className="text-left p-2">Room</th></tr>
                    </thead>
                    <tbody>
                      {solution.assignments.map((a) => {
                        const exam = exams?.find((e) => e.id === a.examId);
                        const room = rooms?.find((r) => r.id === a.roomId);
                        const slot = slots?.find((s) => s.id === a.timeSlotId);
                        return (
                          <tr key={a.examId} className="border-t border-warm hover:bg-cream/50">
                            <td className="p-2 font-medium">{exam?.name ?? a.examId}</td>
                            <td className="p-2">{slot?.date ?? '—'}</td>
                            <td className="p-2">{slot ? `${slot.startTime}-${slot.endTime}` : '—'}</td>
                            <td className="p-2">{room?.name ?? a.roomId}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </SectionCard>
      )}
    </div>
  );
}
