// Scenario History page — list, compare, restore, or discard saved scenarios

'use client';

import { useScenarios, useDeleteScenario, useDiscardScenario, useApplyScenario } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, EmptyState, SectionCard, StatusBadge } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { History, Trash2, CheckCircle2, XCircle, ArrowRight, GitCompare, Sparkles, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';
import { useState } from 'react';
import { useNav } from '@/lib/store';
import { formatDistanceToNow } from 'date-fns';
import type { Scenario } from '@/lib/types';

export function ScenarioHistoryPage() {
  const { data: scenarios, isLoading, isError, refetch } = useScenarios();
  const deleteMut = useDeleteScenario();
  const discardMut = useDiscardScenario();
  const applyMut = useApplyScenario();
  const { navigate } = useNav();
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [restoreId, setRestoreId] = useState<string | null>(null);

  const handleDiscard = async (id: string) => {
    try { await discardMut.mutateAsync(id); toast.success('Scenario discarded'); }
    catch (err) { toast.error((err as Error).message); }
  };
  const handleDelete = async () => {
    if (!deleteId) return;
    try { await deleteMut.mutateAsync(deleteId); toast.success('Scenario deleted'); setDeleteId(null); }
    catch (err) { toast.error((err as Error).message); }
  };
  const handleRestore = async () => {
    if (!restoreId) return;
    try { await applyMut.mutateAsync({ id: restoreId }); toast.success('Scenario applied — timetable restored'); setRestoreId(null); navigate('timetable-viewer'); }
    catch (err) { toast.error((err as Error).message); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Scenario History" description="Saved simulation scenarios with original and proposed states. Restore a feasible scenario to roll back to that timetable, or discard scenarios you no longer need."
        breadcrumbs={[{ label: 'Home' }, { label: 'Simulation' }, { label: 'History' }]}
        actions={<Button variant="outline" onClick={() => navigate('what-if-simulation')}><Sparkles className="h-4 w-4 mr-2" /> New Simulation</Button>} />

      {isLoading ? <LoadingState message="Loading scenarios…" /> :
       isError ? <ErrorState message="Failed to load" onRetry={() => refetch()} /> :
       !scenarios || scenarios.length === 0 ? (
         <EmptyState title="No scenarios yet" description="Create a what-if simulation to see it here." icon={<History className="h-8 w-8 text-warm-muted" />}
           action={<Button onClick={() => navigate('what-if-simulation')} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Sparkles className="h-4 w-4 mr-2" /> New Simulation</Button>} />
       ) : (
         <div className="space-y-3">
           {scenarios.map((s: Scenario) => (
             <Card key={s.id} className={`border-warm shadow-warm hover:shadow-warm-md transition-shadow ${s.status === 'discarded' ? 'opacity-60' : ''}`}>
               <CardContent className="p-4">
                 <div className="flex items-start justify-between gap-3 flex-wrap">
                   <div className="flex-1 min-w-0">
                     <div className="flex items-center gap-2 mb-1">
                       <h3 className="font-bold text-foreground">{s.name}</h3>
                       <StatusBadge status={s.status} />
                       {s.isFeasible === true && <Badge className="bg-green-100 text-green-800 text-xs">feasible</Badge>}
                       {s.isFeasible === false && <Badge className="bg-red-100 text-red-800 text-xs">infeasible</Badge>}
                     </div>
                     {s.description && <p className="text-sm text-warm-muted mb-2">{s.description}</p>}
                     <div className="flex items-center gap-3 text-xs text-warm-muted flex-wrap">
                       <span>Created {formatDistanceToNow(new Date(s.createdAt), { addSuffix: true })}</span>
                       {s.appliedAt && <span className="text-green-600 font-medium">· Applied {formatDistanceToNow(new Date(s.appliedAt), { addSuffix: true })}</span>}
                       <span>· {s.proposedState.length} proposed assignments</span>
                       <span>· {s.alternatives.length} alternative(s)</span>
                       {s.conflictReport.length > 0 && <span className="text-red-600">· {s.conflictReport.length} conflict(s)</span>}
                     </div>
                   </div>
                   <div className="flex items-center gap-1 flex-shrink-0">
                     <Button variant="ghost" size="sm" onClick={() => navigate('ripple-analysis', { scenarioId: s.id })}><Sparkles className="h-3.5 w-3.5 mr-1" /> Ripple</Button>
                     {s.alternatives.length > 1 && <Button variant="ghost" size="sm" onClick={() => navigate('alternative-comparison', { scenarioId: s.id })}><GitCompare className="h-3.5 w-3.5 mr-1" /> Compare</Button>}
                     {s.isFeasible && s.status !== 'approved' && (
                       <Button variant="ghost" size="sm" className="text-green-700" onClick={() => setRestoreId(s.id)}><RotateCcw className="h-3.5 w-3.5 mr-1" /> Apply</Button>
                     )}
                     {s.status !== 'discarded' && s.status !== 'approved' && (
                       <Button variant="ghost" size="sm" className="text-amber-600" onClick={() => handleDiscard(s.id)}><XCircle className="h-3.5 w-3.5 mr-1" /> Discard</Button>
                     )}
                     <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setDeleteId(s.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                   </div>
                 </div>
                 {/* Change summary */}
                 {s.changeSummary && (
                   <div className="mt-3 p-2 rounded-lg bg-cream text-xs">
                     <span className="font-medium text-warm-muted">Change:</span> {s.changeSummary.description}
                   </div>
                 )}
               </CardContent>
             </Card>
           ))}
         </div>
       )}

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete this scenario?</AlertDialogTitle><AlertDialogDescription>This permanently removes the scenario and its data. The published timetable is not affected.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!restoreId} onOpenChange={(open) => !open && setRestoreId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Apply this scenario?</AlertDialogTitle><AlertDialogDescription>This will REPLACE the current published timetable with this scenario's proposed assignments. The current timetable will be overwritten.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleRestore} className="bg-green-600 hover:bg-green-700">Apply & Publish</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
