// Conflict Reports page — displays all detected scheduling conflicts

'use client';

import { useConflicts, useExams, useRooms, useTimeSlots, useInvigilators } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, EmptyState, SeverityBadge, SectionCard } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle2, Filter } from 'lucide-react';
import { useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export function ConflictReportsPage() {
  const { data: conflictData, isLoading, isError, refetch } = useConflicts();
  const { data: exams } = useExams();
  const { data: rooms } = useRooms();
  const { data: slots } = useTimeSlots();
  const { data: invs } = useInvigilators();
  const [severityFilter, setSeverityFilter] = useState('all');

  const conflicts = conflictData?.conflicts ?? [];
  const filtered = severityFilter === 'all' ? conflicts : conflicts.filter((c) => c.severity === severityFilter);
  const counts = {
    critical: conflicts.filter((c) => c.severity === 'critical').length,
    warning: conflicts.filter((c) => c.severity === 'warning').length,
    info: conflicts.filter((c) => c.severity === 'info').length,
  };

  const examName = (id: string) => exams?.find((e) => e.id === id)?.name ?? id;
  const roomName = (id: string) => rooms?.find((r) => r.id === id)?.name ?? id;
  const slotName = (id: string) => { const s = slots?.find((t) => t.id === id); return s ? `${s.date} ${s.startTime}-${s.endTime}` : id; };
  const invName = (id: string) => invs?.find((i) => i.id === id)?.name ?? id;

  return (
    <div className="space-y-6">
      <PageHeader title="Conflict Reports" description="All scheduling conflicts detected in the published timetable. Critical conflicts violate hard constraints and must be resolved."
        breadcrumbs={[{ label: 'Home' }, { label: 'Scheduling' }, { label: 'Conflicts' }]} />

      <div className="grid grid-cols-3 gap-4">
        <Card className={`border-warm shadow-warm ${counts.critical > 0 ? 'ring-2 ring-red-300' : ''}`}>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-xl bg-red-100 p-3"><AlertTriangle className="h-6 w-6 text-red-600" /></div>
            <div><p className="text-xs text-warm-muted">Critical</p><p className="text-2xl font-bold text-red-600">{counts.critical}</p></div>
          </CardContent>
        </Card>
        <Card className="border-warm shadow-warm">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-xl bg-amber-100 p-3"><AlertTriangle className="h-6 w-6 text-amber-600" /></div>
            <div><p className="text-xs text-warm-muted">Warnings</p><p className="text-2xl font-bold text-amber-600">{counts.warning}</p></div>
          </CardContent>
        </Card>
        <Card className="border-warm shadow-warm">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="rounded-xl bg-blue-100 p-3"><AlertTriangle className="h-6 w-6 text-blue-600" /></div>
            <div><p className="text-xs text-warm-muted">Info</p><p className="text-2xl font-bold text-blue-600">{counts.info}</p></div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-2">
        <Filter className="h-4 w-4 text-warm-muted" />
        <Select value={severityFilter} onValueChange={setSeverityFilter}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All severities</SelectItem>
            <SelectItem value="critical">Critical only</SelectItem>
            <SelectItem value="warning">Warnings only</SelectItem>
            <SelectItem value="info">Info only</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? <LoadingState message="Checking for conflicts…" /> :
       isError ? <ErrorState message="Failed to check conflicts" onRetry={() => refetch()} /> :
       filtered.length === 0 ? (
         <EmptyState title="No conflicts detected" description={severityFilter === 'all' ? 'The published timetable has no conflicts. All hard constraints are satisfied.' : `No ${severityFilter} conflicts.`}
           icon={<CheckCircle2 className="h-8 w-8 text-green-600" />} />
       ) : (
         <div className="space-y-3">
           {filtered.map((c) => (
             <Card key={c.id} className="border-warm shadow-warm">
               <CardContent className="p-4">
                 <div className="flex items-start gap-3">
                   <div className={`rounded-lg p-2 ${c.severity === 'critical' ? 'bg-red-100' : c.severity === 'warning' ? 'bg-amber-100' : 'bg-blue-100'}`}>
                     <AlertTriangle className={`h-5 w-5 ${c.severity === 'critical' ? 'text-red-600' : c.severity === 'warning' ? 'text-amber-600' : 'text-blue-600'}`} />
                   </div>
                   <div className="flex-1 min-w-0">
                     <div className="flex items-center gap-2 mb-1">
                       <h3 className="font-bold text-foreground">{c.title}</h3>
                       <SeverityBadge severity={c.severity} />
                       <Badge variant="outline" className="text-xs">{c.kind.replace(/_/g, ' ')}</Badge>
                     </div>
                     <p className="text-sm text-foreground">{c.description}</p>
                     {c.suggestedFix && <p className="text-xs text-warm-muted mt-2"><span className="font-medium">Suggested fix:</span> {c.suggestedFix}</p>}
                     <div className="mt-3 grid grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
                       {c.examIds.length > 0 && <div><span className="text-warm-muted">Exams:</span> {c.examIds.map(examName).join(', ')}</div>}
                       {c.roomIds.length > 0 && <div><span className="text-warm-muted">Rooms:</span> {c.roomIds.map(roomName).join(', ')}</div>}
                       {c.timeSlotIds.length > 0 && <div><span className="text-warm-muted">Slots:</span> {c.timeSlotIds.map(slotName).join(', ')}</div>}
                       {c.invigilatorIds.length > 0 && <div><span className="text-warm-muted">Invigilators:</span> {c.invigilatorIds.map(invName).join(', ')}</div>}
                     </div>
                   </div>
                 </div>
               </CardContent>
             </Card>
           ))}
         </div>
       )}
    </div>
  );
}
