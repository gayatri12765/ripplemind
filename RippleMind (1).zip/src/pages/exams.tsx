// Exams Management page

'use client';

import { useState } from 'react';
import { useExams, useStudentGroups, useCreateExam, useUpdateExam, useDeleteExam } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, EmptyState, SectionCard } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Plus, Pencil, Trash2, FileText, Search } from 'lucide-react';
import { toast } from 'sonner';
import type { Exam } from '@/lib/types';
import { formatDuration } from '@/lib/time';

export function ExamsPage() {
  const { data: exams, isLoading, isError, refetch } = useExams();
  const { data: groups } = useStudentGroups();
  const createExam = useCreateExam();
  const updateExam = useUpdateExam();
  const deleteExam = useDeleteExam();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Exam | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const [form, setForm] = useState({
    name: '', subjectCode: '', duration: 180, studentGroupId: '',
    enrollmentCount: 0, examType: 'final', notes: '',
  });

  const filtered = exams?.filter((e) =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    e.subjectCode.toLowerCase().includes(search.toLowerCase())
  ) ?? [];

  const openCreate = () => {
    setEditing(null);
    setForm({ name: '', subjectCode: '', duration: 180, studentGroupId: groups?.[0]?.id ?? '', enrollmentCount: 0, examType: 'final', notes: '' });
    setDialogOpen(true);
  };

  const openEdit = (exam: Exam) => {
    setEditing(exam);
    setForm({
      name: exam.name, subjectCode: exam.subjectCode, duration: exam.duration,
      studentGroupId: exam.studentGroupId, enrollmentCount: exam.enrollmentCount,
      examType: exam.examType, notes: exam.notes ?? '',
    });
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.subjectCode.trim() || !form.studentGroupId) {
      toast.error('Name, subject code, and student group are required');
      return;
    }
    if (form.enrollmentCount <= 0) { toast.error('Enrollment must be positive'); return; }
    if (form.duration < 30 || form.duration > 480) { toast.error('Duration must be 30–480 minutes'); return; }

    try {
      if (editing) {
        await updateExam.mutateAsync({ id: editing.id, data: form });
        toast.success('Exam updated');
      } else {
        await createExam.mutateAsync(form);
        toast.success('Exam created');
      }
      setDialogOpen(false);
    } catch (err) {
      toast.error((err as Error).message);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteExam.mutateAsync(deleteId);
      toast.success('Exam deleted');
      setDeleteId(null);
    } catch (err) {
      toast.error((err as Error).message);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Exams Management"
        description="Create and manage examination records. Each exam has a subject code, duration, student group, and enrollment count."
        breadcrumbs={[{ label: 'Home' }, { label: 'Resources' }, { label: 'Exams' }]}
        actions={
          <Button onClick={openCreate} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white">
            <Plus className="h-4 w-4 mr-1" /> Add Exam
          </Button>
        }
      />

      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-warm-muted" />
          <Input placeholder="Search by name or code…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Badge variant="outline" className="ml-auto">{filtered.length} exam{filtered.length !== 1 ? 's' : ''}</Badge>
      </div>

      {isLoading ? <LoadingState message="Loading exams…" /> :
       isError ? <ErrorState message="Failed to load exams" onRetry={() => refetch()} /> :
       filtered.length === 0 ? (
         <EmptyState
           title="No exams found"
           description={search ? "No exams match your search." : "Create your first exam to get started."}
           icon={<FileText className="h-8 w-8 text-warm-muted" />}
           action={!search && <Button onClick={openCreate} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Plus className="h-4 w-4 mr-1" /> Add Exam</Button>}
         />
       ) : (
         <Card className="border-warm shadow-warm">
           <CardContent className="p-0">
             <Table>
               <TableHeader>
                 <TableRow className="bg-cream-deep hover:bg-cream-deep">
                   <TableHead>Subject Code</TableHead>
                   <TableHead>Exam Name</TableHead>
                   <TableHead>Student Group</TableHead>
                   <TableHead className="text-center">Enrollment</TableHead>
                   <TableHead className="text-center">Duration</TableHead>
                   <TableHead className="text-center">Type</TableHead>
                   <TableHead className="text-center">Status</TableHead>
                   <TableHead className="text-right">Actions</TableHead>
                 </TableRow>
               </TableHeader>
               <TableBody>
                 {filtered.map((exam) => (
                   <TableRow key={exam.id} className="hover:bg-cream/50">
                     <TableCell className="font-mono text-xs font-medium">{exam.subjectCode}</TableCell>
                     <TableCell className="font-medium">{exam.name}</TableCell>
                     <TableCell className="text-sm">{exam.studentGroup?.name ?? '—'}</TableCell>
                     <TableCell className="text-center">{exam.enrollmentCount}</TableCell>
                     <TableCell className="text-center text-sm">{formatDuration(exam.duration)}</TableCell>
                     <TableCell className="text-center"><Badge variant="outline" className="text-xs">{exam.examType}</Badge></TableCell>
                     <TableCell className="text-center">
                       <Badge variant={exam.status === 'scheduled' ? 'default' : 'secondary'} className={exam.status === 'scheduled' ? 'bg-green-100 text-green-800' : ''}>
                         {exam.status}
                       </Badge>
                     </TableCell>
                     <TableCell className="text-right">
                       <Button variant="ghost" size="icon" onClick={() => openEdit(exam)}><Pencil className="h-4 w-4" /></Button>
                       <Button variant="ghost" size="icon" onClick={() => setDeleteId(exam.id)}><Trash2 className="h-4 w-4 text-red-600" /></Button>
                     </TableCell>
                   </TableRow>
                 ))}
               </TableBody>
             </Table>
           </CardContent>
         </Card>
       )}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Exam' : 'Add Exam'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Exam Name *</Label>
              <Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Data Structures Final" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="subjectCode">Subject Code *</Label>
                <Input id="subjectCode" value={form.subjectCode} onChange={(e) => setForm({ ...form, subjectCode: e.target.value })} placeholder="e.g. CS301" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="examType">Exam Type</Label>
                <Select value={form.examType} onValueChange={(v) => setForm({ ...form, examType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="final">Final</SelectItem>
                    <SelectItem value="midterm">Midterm</SelectItem>
                    <SelectItem value="quiz">Quiz</SelectItem>
                    <SelectItem value="makeup">Makeup</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="studentGroupId">Student Group *</Label>
              <Select value={form.studentGroupId} onValueChange={(v) => setForm({ ...form, studentGroupId: v })}>
                <SelectTrigger><SelectValue placeholder="Select group" /></SelectTrigger>
                <SelectContent>
                  {groups?.map((g) => (
                    <SelectItem key={g.id} value={g.id}>{g.name} ({g.studentCount} students)</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="enrollmentCount">Enrollment Count *</Label>
                <Input id="enrollmentCount" type="number" min={1} value={form.enrollmentCount} onChange={(e) => setForm({ ...form, enrollmentCount: Number(e.target.value) })} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration">Duration (minutes) *</Label>
                <Input id="duration" type="number" min={30} max={480} value={form.duration} onChange={(e) => setForm({ ...form, duration: Number(e.target.value) })} required />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea id="notes" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} placeholder="Optional notes" />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-[#FF6B35] hover:bg-[#E85D04] text-white" disabled={createExam.isPending || updateExam.isPending}>
                {editing ? 'Update' : 'Create'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this exam?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the exam and any associated assignment. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
