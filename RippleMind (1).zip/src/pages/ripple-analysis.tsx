// Ripple-effect Analysis page — LIGHTWEIGHT CSS version (no React Flow)
'use client';

import { useState } from 'react';
import { useScenarioRipple, useScenarios } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, EmptyState, SectionCard } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Share2, FileText, DoorOpen, Clock, UserCheck, Users, ArrowRight } from 'lucide-react';
import { useNav } from '@/lib/store';

const nodeColors: Record<string, string> = {
  exam: '#FF6B35',
  room: '#2D6A4F',
  timeslot: '#3C91E6',
  invigilator: '#D62828',
  studentgroup: '#F77F00',
};

const nodeIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  exam: FileText,
  room: DoorOpen,
  timeslot: Clock,
  invigilator: UserCheck,
  studentgroup: Users,
};

export function RippleAnalysisPage() {
  const { data: scenarios } = useScenarios();
  const { pageParams, navigate } = useNav();
  const [userSelectedId, setUserSelectedId] = useState('');
  const effectiveId = userSelectedId || pageParams.scenarioId || scenarios?.[0]?.id || '';
  const { data: rippleData, isLoading, isError } = useScenarioRipple(effectiveId || null);

  return (
    <div className="space-y-6">
      <PageHeader title="Ripple-effect Analysis" description="Visualization of how a proposed change cascades through the timetable. Changed nodes are red, affected nodes are orange."
        breadcrumbs={[{ label: 'Home' }, { label: 'Simulation' }, { label: 'Ripple Analysis' }]} />

      <div className="flex items-center gap-3 flex-wrap">
        <Select value={effectiveId} onValueChange={setUserSelectedId}>
          <SelectTrigger className="w-80"><SelectValue placeholder="Select a scenario" /></SelectTrigger>
          <SelectContent>
            {scenarios?.map((s) => <SelectItem key={s.id} value={s.id}>{s.name} {s.isFeasible ? '✓' : '✗'}</SelectItem>)}
          </SelectContent>
        </Select>
        {effectiveId && (
          <Button variant="outline" onClick={() => navigate('what-if-simulation', { scenarioId: effectiveId })}>
            <ArrowRight className="h-4 w-4 mr-2" /> View Scenario
          </Button>
        )}
      </div>

      {!effectiveId ? (
        <EmptyState title="No scenario selected" description="Create a what-if simulation first, then select it here to visualize the ripple effect." icon={<Share2 className="h-8 w-8 text-warm-muted" />}
          action={<Button onClick={() => navigate('what-if-simulation')} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white">Create Simulation</Button>} />
      ) : isLoading ? <LoadingState message="Building ripple graph…" /> :
        isError ? <ErrorState message="Failed to load ripple data" /> :
        !rippleData || rippleData.graph.nodes.length === 0 ? (
          <EmptyState title="No ripple data" description="This scenario has no changes to visualize." icon={<Share2 className="h-8 w-8 text-warm-muted" />} />
        ) : (
          <div className="space-y-4">
            {/* Graph visualization — CSS grid layout */}
            <Card className="border-warm shadow-warm">
              <CardContent className="p-5">
                <h4 className="text-sm font-semibold mb-4">Ripple Graph</h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                  {rippleData.graph.nodes.map((node: any) => {
                    const Icon = nodeIcons[node.type] ?? FileText;
                    const color = nodeColors[node.type] ?? '#FF6B35';
                    return (
                      <div
                        key={node.id}
                        className={`rounded-lg border-2 p-3 transition-all hover:scale-105 ${
                          node.changed ? 'border-red-400 bg-red-50' :
                          node.affected ? 'border-orange-400 bg-orange-50' :
                          'border-warm bg-white'
                        }`}
                        style={{ borderLeftWidth: '4px', borderLeftColor: color }}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <div className="rounded p-1" style={{ background: color }}>
                            <Icon className="h-3 w-3 text-white" />
                          </div>
                          <span className="text-[10px] uppercase font-semibold text-warm-muted">{node.type}</span>
                        </div>
                        <p className="text-sm font-bold text-foreground truncate">{node.label}</p>
                        {node.sublabel && <p className="text-[10px] text-warm-muted truncate">{node.sublabel}</p>}
                        {node.changed && <Badge className="bg-red-500 text-white text-[9px] mt-1">CHANGED</Badge>}
                        {node.affected && !node.changed && <Badge className="bg-orange-500 text-white text-[9px] mt-1">AFFECTED</Badge>}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Legend + Summary */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <SectionCard title="Legend">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2"><span className="w-4 h-4 rounded border-2 border-red-400 bg-red-50"></span> Changed (directly modified)</div>
                  <div className="flex items-center gap-2"><span className="w-4 h-4 rounded border-2 border-orange-400 bg-orange-50"></span> Affected (ripple effect)</div>
                  <div className="flex items-center gap-2"><span className="w-4 h-4 rounded border-2 border-[#FF6B35] bg-white"></span> Exam node</div>
                  <div className="flex items-center gap-2"><span className="w-4 h-4 rounded border-2 border-[#2D6A4F] bg-white"></span> Room node</div>
                  <div className="flex items-center gap-2"><span className="w-4 h-4 rounded border-2 border-[#3C91E6] bg-white"></span> Time slot node</div>
                  <div className="flex items-center gap-2"><span className="w-4 h-4 rounded border-2 border-[#D62828] bg-white"></span> Invigilator node</div>
                </div>
              </SectionCard>

              <SectionCard title="Impact Summary">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between p-2 rounded-lg bg-cream">
                    <span className="flex items-center gap-2"><FileText className="h-4 w-4 text-[#FF6B35]" /> Exams in graph</span>
                    <Badge>{rippleData.graph.nodes.filter((n: any) => n.type === 'exam').length}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-lg bg-cream">
                    <span className="flex items-center gap-2"><DoorOpen className="h-4 w-4 text-[#2D6A4F]" /> Rooms affected</span>
                    <Badge>{rippleData.graph.nodes.filter((n: any) => n.type === 'room').length}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-lg bg-cream">
                    <span className="flex items-center gap-2"><Clock className="h-4 w-4 text-[#3C91E6]" /> Time slots</span>
                    <Badge>{rippleData.graph.nodes.filter((n: any) => n.type === 'timeslot').length}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-lg bg-cream">
                    <span className="flex items-center gap-2"><UserCheck className="h-4 w-4 text-[#D62828]" /> Invigilators</span>
                    <Badge>{rippleData.graph.nodes.filter((n: any) => n.type === 'invigilator').length}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-lg bg-cream">
                    <span className="flex items-center gap-2"><Users className="h-4 w-4 text-[#F77F00]" /> Student groups</span>
                    <Badge>{rippleData.graph.nodes.filter((n: any) => n.type === 'studentgroup').length}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-lg bg-red-50">
                    <span className="font-medium">Conflict edges</span>
                    <Badge variant="destructive">{rippleData.graph.edges.filter((e: any) => e.kind === 'conflicts').length}</Badge>
                  </div>
                </div>
              </SectionCard>
            </div>
          </div>
        )}
    </div>
  );
}
