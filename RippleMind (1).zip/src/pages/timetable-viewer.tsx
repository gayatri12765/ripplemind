// Timetable Viewer page — displays the published timetable in a calendar/table format

'use client';

import { useState } from 'react';
import { useAssignments, useExams, useRooms, useTimeSlots, useInvigilators, useStudentGroups } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, EmptyState } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, Download, FileText, Users } from 'lucide-react';
import { toast } from 'sonner';
import { formatDate, formatTimeRange, dayName } from '@/lib/time';

export function TimetableViewerPage() {
  const { data: assignments, isLoading, isError, refetch } = useAssignments();
  const { data: exams } = useExams();
  const { data: rooms } = useRooms();
  const { data: slots } = useTimeSlots();
  const { data: invs } = useInvigilators();
  const { data: groups } = useStudentGroups();
  const [view, setView] = useState<'table' | 'calendar'>('table');
  const [groupFilter, setGroupFilter] = useState('all');

  const filtered = assignments?.filter((a) => {
    if (groupFilter === 'all') return true;
    const exam = exams?.find((e) => e.id === a.examId);
    return exam?.studentGroupId === groupFilter;
  }) ?? [];

  // Group by date for calendar view
  const byDate = new Map<string, typeof filtered>();
  for (const a of filtered) {
    if (!byDate.has(a.date)) byDate.set(a.date, []);
    byDate.get(a.date)!.push(a);
  }
  const sortedDates = Array.from(byDate.keys()).sort();

  const handleExport = () => {
    if (!filtered.length) { toast.error('Nothing to export'); return; }
    const rows = [['Date', 'Day', 'Start', 'End', 'Subject Code', 'Exam Name', 'Student Group', 'Enrollment', 'Room', 'Capacity', 'Invigilators']];
    for (const a of filtered) {
      const exam = exams?.find((e) => e.id === a.examId);
      const room = rooms?.find((r) => r.id === a.roomId);
      const slot = slots?.find((s) => s.id === a.timeSlotId);
      const group = groups?.find((g) => g.id === exam?.studentGroupId);
      const invNames = a.invigilatorIds.map((id) => invs?.find((i) => i.id === id)?.name ?? id).join('; ');
      rows.push([a.date, dayName(a.date), slot?.startTime ?? '', slot?.endTime ?? '', exam?.subjectCode ?? '', exam?.name ?? '', group?.name ?? '', String(exam?.enrollmentCount ?? 0), room?.name ?? '', String(room?.capacity ?? 0), invNames]);
    }
    const csv = rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'timetable.csv'; a.click();
    URL.revokeObjectURL(url);
    toast.success('Timetable exported as CSV');
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Timetable Viewer" description="View the published examination timetable in table or calendar format."
        breadcrumbs={[{ label: 'Home' }, { label: 'Scheduling' }, { label: 'Viewer' }]}
        actions={<Button variant="outline" onClick={handleExport}><Download className="h-4 w-4 mr-2" /> Export CSV</Button>} />

      <div className="flex items-center gap-3 flex-wrap">
        <Select value={groupFilter} onValueChange={setGroupFilter}>
          <SelectTrigger className="w-56"><SelectValue placeholder="Filter by group" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All student groups</SelectItem>
            {groups?.map((g) => <SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Tabs value={view} onValueChange={(v) => setView(v as 'table' | 'calendar')}>
          <TabsList>
            <TabsTrigger value="table">Table</TabsTrigger>
            <TabsTrigger value="calendar">Calendar</TabsTrigger>
          </TabsList>
        </Tabs>
        <Badge variant="outline" className="ml-auto">{filtered.length} assignment(s)</Badge>
      </div>

      {isLoading ? <LoadingState message="Loading timetable…" /> :
       isError ? <ErrorState message="Failed to load" onRetry={() => refetch()} /> :
       filtered.length === 0 ? (
         <EmptyState title="No assignments" description="Generate a timetable first, or adjust your filter." icon={<Calendar className="h-8 w-8 text-warm-muted" />} />
       ) : view === 'table' ? (
         <Card className="border-warm shadow-warm">
           <CardContent className="p-0 overflow-x-auto">
             <table className="w-full text-sm">
               <thead className="bg-cream-deep">
                 <tr>
                   <th className="text-left p-3 font-semibold">Date</th>
                   <th className="text-left p-3 font-semibold">Time</th>
                   <th className="text-left p-3 font-semibold">Exam</th>
                   <th className="text-left p-3 font-semibold">Group</th>
                   <th className="text-center p-3 font-semibold">Enr.</th>
                   <th className="text-left p-3 font-semibold">Room</th>
                   <th className="text-left p-3 font-semibold">Invigilators</th>
                 </tr>
               </thead>
               <tbody>
                 {filtered.map((a) => {
                   const exam = exams?.find((e) => e.id === a.examId);
                   const room = rooms?.find((r) => r.id === a.roomId);
                   const slot = slots?.find((s) => s.id === a.timeSlotId);
                   const group = groups?.find((g) => g.id === exam?.studentGroupId);
                   return (
                     <tr key={a.id} className="border-t border-warm hover:bg-cream/50">
                       <td className="p-3"><div className="font-medium">{formatDate(a.date)}</div><div className="text-xs text-warm-muted">{dayName(a.date)}</div></td>
                       <td className="p-3 font-mono text-xs">{slot ? formatTimeRange(slot.startTime, slot.endTime) : '—'}</td>
                       <td className="p-3"><div className="font-medium">{exam?.name}</div><div className="text-xs text-warm-muted font-mono">{exam?.subjectCode}</div></td>
                       <td className="p-3">{group?.name ?? '—'}</td>
                       <td className="p-3 text-center">{exam?.enrollmentCount}</td>
                       <td className="p-3"><div>{room?.name}</div><div className="text-xs text-warm-muted">cap {room?.capacity}</div></td>
                       <td className="p-3 text-xs">{a.invigilatorIds.map((id) => invs?.find((i) => i.id === id)?.name ?? id).join(', ') || '—'}</td>
                     </tr>
                   );
                 })}
               </tbody>
             </table>
           </CardContent>
         </Card>
       ) : (
         <div className="space-y-4">
           {sortedDates.map((date) => (
             <Card key={date} className="border-warm shadow-warm">
               <CardContent className="p-4">
                 <div className="flex items-center gap-2 mb-3">
                   <Calendar className="h-4 w-4 text-[#FF6B35]" />
                   <h3 className="font-bold">{formatDate(date)}</h3>
                   <Badge variant="outline" className="text-xs">{dayName(date)}</Badge>
                 </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                   {byDate.get(date)!.sort((a, b) => (slots?.find((s) => s.id === a.timeSlotId)?.startTime ?? '').localeCompare(slots?.find((s) => s.id === b.timeSlotId)?.startTime ?? '')).map((a) => {
                     const exam = exams?.find((e) => e.id === a.examId);
                     const room = rooms?.find((r) => r.id === a.roomId);
                     const slot = slots?.find((s) => s.id === a.timeSlotId);
                     const group = groups?.find((g) => g.id === exam?.studentGroupId);
                     return (
                       <div key={a.id} className="rounded-lg border border-warm p-3 bg-cream/50">
                         <div className="flex items-start justify-between mb-2">
                           <Badge className="bg-[#FF6B35] text-white">{slot?.startTime}</Badge>
                           <span className="text-xs text-warm-muted">{slot?.endTime}</span>
                         </div>
                         <p className="font-semibold text-sm">{exam?.name}</p>
                         <p className="text-xs text-warm-muted font-mono">{exam?.subjectCode}</p>
                         <div className="mt-2 space-y-1 text-xs">
                           <div className="flex items-center gap-1"><Users className="h-3 w-3 text-warm-muted" />{group?.name} ({exam?.enrollmentCount})</div>
                           <div className="flex items-center gap-1"><FileText className="h-3 w-3 text-warm-muted" />{room?.name} (cap {room?.capacity})</div>
                         </div>
                       </div>
                     );
                   })}
                 </div>
               </CardContent>
             </Card>
           ))}
         </div>
       )}
    </div>
  );
}
