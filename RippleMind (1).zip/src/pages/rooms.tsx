// Rooms Management page

'use client';

import { useState } from 'react';
import { useRooms, useCreateRoom, useUpdateRoom, useDeleteRoom } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, EmptyState } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { DoorOpen, Plus, Pencil, Trash2, Search, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import type { Room } from '@/lib/types';

export function RoomsPage() {
  const { data: rooms, isLoading, isError, refetch } = useRooms();
  const createMut = useCreateRoom();
  const updateMut = useUpdateRoom();
  const deleteMut = useDeleteRoom();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Room | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ name: '', code: '', capacity: 50, location: '', building: '', floor: 1, isAvailable: true });

  const filtered = rooms?.filter((r) => r.name.toLowerCase().includes(search.toLowerCase()) || r.code.toLowerCase().includes(search.toLowerCase())) ?? [];

  const openCreate = () => { setEditing(null); setForm({ name: '', code: '', capacity: 50, location: '', building: '', floor: 1, isAvailable: true }); setDialogOpen(true); };
  const openEdit = (r: Room) => { setEditing(r); setForm({ name: r.name, code: r.code, capacity: r.capacity, location: r.location ?? '', building: r.building ?? '', floor: r.floor ?? 1, isAvailable: r.isAvailable }); setDialogOpen(true); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.code.trim()) { toast.error('Name and code required'); return; }
    if (form.capacity <= 0) { toast.error('Capacity must be positive'); return; }
    try {
      const payload = { ...form, location: form.location || undefined, building: form.building || undefined, features: [] };
      if (editing) { await updateMut.mutateAsync({ id: editing.id, data: payload }); toast.success('Room updated'); }
      else { await createMut.mutateAsync(payload); toast.success('Room created'); }
      setDialogOpen(false);
    } catch (err) { toast.error((err as Error).message); }
  };
  const handleDelete = async () => { if (!deleteId) return; try { await deleteMut.mutateAsync(deleteId); toast.success('Deleted'); setDeleteId(null); } catch (err) { toast.error((err as Error).message); } };

  return (
    <div className="space-y-6">
      <PageHeader title="Rooms Management" description="Manage examination rooms with capacity, location, and availability."
        breadcrumbs={[{ label: 'Home' }, { label: 'Resources' }, { label: 'Rooms' }]}
        actions={<Button onClick={openCreate} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Plus className="h-4 w-4 mr-1" /> Add Room</Button>} />

      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-warm-muted" />
          <Input placeholder="Search rooms…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
      </div>

      {isLoading ? <LoadingState message="Loading rooms…" /> :
       isError ? <ErrorState message="Failed to load" onRetry={() => refetch()} /> :
       filtered.length === 0 ? (
         <EmptyState title="No rooms" description="Add your first room." icon={<DoorOpen className="h-8 w-8 text-warm-muted" />}
           action={!search && <Button onClick={openCreate} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Plus className="h-4 w-4 mr-1" /> Add Room</Button>} />
       ) : (
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
           {filtered.map((r) => (
             <Card key={r.id} className={`border-warm shadow-warm hover:shadow-warm-md transition-shadow ${!r.isAvailable ? 'opacity-60' : ''}`}>
               <CardContent className="p-5">
                 <div className="flex items-start justify-between">
                   <div className={`rounded-xl p-2.5 shadow-warm ${r.isAvailable ? 'bg-gradient-to-br from-[#FF6B35] to-[#F77F00]' : 'bg-gray-300'}`}>
                     <DoorOpen className="h-5 w-5 text-white" />
                   </div>
                   <div className="flex gap-1">
                     <Button variant="ghost" size="icon" onClick={() => openEdit(r)}><Pencil className="h-4 w-4" /></Button>
                     <Button variant="ghost" size="icon" onClick={() => setDeleteId(r.id)}><Trash2 className="h-4 w-4 text-red-600" /></Button>
                   </div>
                 </div>
                 <h3 className="font-bold text-foreground mt-3">{r.name}</h3>
                 <p className="text-xs font-mono text-warm-muted">{r.code}</p>
                 <div className="mt-3 space-y-1 text-sm">
                   <div className="flex items-center justify-between"><span className="text-warm-muted">Capacity</span><Badge variant="outline" className="font-semibold">{r.capacity}</Badge></div>
                   {r.location && <div className="flex items-center gap-1 text-xs text-warm-muted"><MapPin className="h-3 w-3" />{r.location}</div>}
                   <div className="flex items-center justify-between pt-1">
                     <span className="text-xs text-warm-muted">Available</span>
                     <Switch checked={r.isAvailable} onCheckedChange={async (v) => { await updateMut.mutateAsync({ id: r.id, data: { isAvailable: v } }); toast.success(`Room ${v ? 'enabled' : 'disabled'}`); }} />
                   </div>
                 </div>
               </CardContent>
             </Card>
           ))}
         </div>
       )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editing ? 'Edit Room' : 'Add Room'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2"><Label>Room Name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Code *</Label><Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="e.g. H101" required /></div>
              <div className="space-y-2"><Label>Capacity *</Label><Input type="number" min={1} value={form.capacity} onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} required /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Building</Label><Input value={form.building} onChange={(e) => setForm({ ...form, building: e.target.value })} /></div>
              <div className="space-y-2"><Label>Floor</Label><Input type="number" min={0} value={form.floor} onChange={(e) => setForm({ ...form, floor: Number(e.target.value) })} /></div>
            </div>
            <div className="space-y-2"><Label>Location</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="e.g. Main Building" /></div>
            <div className="flex items-center gap-2"><Switch checked={form.isAvailable} onCheckedChange={(v) => setForm({ ...form, isAvailable: v })} /><Label>Available for scheduling</Label></div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-[#FF6B35] hover:bg-[#E85D04] text-white" disabled={createMut.isPending || updateMut.isPending}>{editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete this room?</AlertDialogTitle><AlertDialogDescription>Assignments using this room must be removed first.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
