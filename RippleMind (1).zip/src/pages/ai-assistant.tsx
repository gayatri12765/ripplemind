// AI Assistant page — LLM-powered explanations and NL-to-proposal translation

'use client';

import { useState, useRef, useEffect } from 'react';
import { useAIExplain, useAITranslate, useExams, useRooms, useTimeSlots, useScenarios } from '@/lib/api';
import { PageHeader, SectionCard, LoadingState, ErrorState } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Sparkles, Send, FlaskConical, AlertCircle, CheckCircle2, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { useNav } from '@/lib/store';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  topic?: string;
  fallback?: boolean;
}

const SUGGESTED_QUESTIONS = [
  'Why was a conflict detected?',
  'Explain the current timetable quality',
  'What happens if I move the Database exam to Friday?',
  'Compare the available scheduling alternatives',
  'Which invigilator has the heaviest workload?',
];

export function AIAssistantPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: 'Hello! I\'m RippleMind\'s AI assistant. I can explain scheduling conflicts, summarize scenario impacts, compare alternatives, and translate natural-language requests into scheduling proposals. Note: I explain results — the CP solver determines feasibility, not me.' },
  ]);
  const [input, setInput] = useState('');
  const [selectedTopic, setSelectedTopic] = useState<'conflict' | 'scenario' | 'alternative' | 'comparison' | 'timetable' | 'general'>('general');
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('');
  const [translateResult, setTranslateResult] = useState<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const explainMut = useAIExplain();
  const translateMut = useAITranslate();
  const { data: scenarios } = useScenarios();
  const { navigate } = useNav();

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg = input.trim();
    setMessages((prev) => [...prev, { role: 'user', content: userMsg }]);
    setInput('');
    try {
      const res = await explainMut.mutateAsync({
        topic: selectedTopic,
        question: userMsg,
        scenarioId: selectedScenarioId || undefined,
      });
      setMessages((prev) => [...prev, { role: 'assistant', content: res.answer, topic: selectedTopic, fallback: res.fallbackUsed }]);
    } catch (err) {
      setMessages((prev) => [...prev, { role: 'assistant', content: `Error: ${(err as Error).message}` }]);
    }
  };

  const handleTranslate = async () => {
    if (!input.trim()) return;
    try {
      const res = await translateMut.mutateAsync({ query: input.trim() });
      setTranslateResult(res);
      if (res.ok && res.proposals.length > 0) {
        toast.success(`Translated to ${res.proposals.length} proposal(s)`);
      } else if (res.ok) {
        toast.info('No specific proposals extracted from your request');
      } else {
        toast.error('Translation failed');
      }
    } catch (err) { toast.error((err as Error).message); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title="AI Assistant" description="Ask questions about the timetable, get explanations for conflicts and scenarios, and translate natural-language requests into scheduling proposals. Powered by GLM-4.6 — feasibility is always determined by the CP solver, never the LLM."
        breadcrumbs={[{ label: 'Home' }, { label: 'Simulation' }, { label: 'AI Assistant' }]} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chat */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="border-warm shadow-warm">
            <CardContent className="p-0">
              <div ref={scrollRef} className="h-[400px] overflow-y-auto scrollbar-thin p-4 space-y-3">
                {messages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] rounded-2xl px-4 py-2 ${msg.role === 'user' ? 'bg-gradient-to-br from-[#FF6B35] to-[#D62828] text-white' : 'bg-cream border border-warm'}`}>
                      {msg.role === 'assistant' && (
                        <div className="flex items-center gap-1 mb-1">
                          <Sparkles className="h-3 w-3 text-[#FF6B35]" />
                          <span className="text-[10px] font-semibold uppercase text-warm-muted">AI Assistant</span>
                          {msg.fallback && <Badge variant="outline" className="text-[9px] ml-1">rule-based fallback</Badge>}
                        </div>
                      )}
                      <p className={`text-sm whitespace-pre-wrap ${msg.role === 'user' ? 'text-white' : 'text-foreground'}`}>{msg.content}</p>
                    </div>
                  </div>
                ))}
                {explainMut.isPending && (
                  <div className="flex justify-start">
                    <div className="bg-cream border border-warm rounded-2xl px-4 py-2">
                      <div className="flex items-center gap-1 text-warm-muted"><Sparkles className="h-3 w-3 animate-pulse" /><span className="text-xs">Thinking…</span></div>
                    </div>
                  </div>
                )}
              </div>
              <div className="border-t border-warm p-3 space-y-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs text-warm-muted">Topic:</span>
                  {(['general', 'conflict', 'scenario', 'alternative', 'comparison', 'timetable'] as const).map((t) => (
                    <button key={t} onClick={() => setSelectedTopic(t)} className={`text-xs px-2 py-1 rounded-full border ${selectedTopic === t ? 'bg-[#FF6B35] text-white border-[#FF6B35]' : 'border-warm text-warm-muted hover:bg-cream'}`}>{t}</button>
                  ))}
                </div>
                {selectedTopic === 'scenario' && (
                  <select value={selectedScenarioId} onChange={(e) => setSelectedScenarioId(e.target.value)} className="text-xs border border-warm rounded px-2 py-1 w-full">
                    <option value="">Select a scenario…</option>
                    {scenarios?.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                )}
                <div className="flex gap-2">
                  <Textarea value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask a question or describe a scheduling change…" rows={2} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }} />
                  <div className="flex flex-col gap-1">
                    <Button onClick={handleSend} disabled={explainMut.isPending || !input.trim()} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Send className="h-4 w-4" /></Button>
                    <Button onClick={handleTranslate} disabled={translateMut.isPending || !input.trim()} variant="outline" title="Translate to scheduling proposal"><FlaskConical className="h-4 w-4" /></Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Suggested questions */}
          <div className="flex flex-wrap gap-2">
            {SUGGESTED_QUESTIONS.map((q) => (
              <button key={q} onClick={() => setInput(q)} className="text-xs px-3 py-1.5 rounded-full border border-warm bg-cream hover:bg-cream-deep text-warm-muted">{q}</button>
            ))}
          </div>
        </div>

        {/* NL-to-proposal translation result */}
        <div className="space-y-4">
          <SectionCard title="Natural Language → Proposal" description="Click the flask icon to translate your request into a structured scheduling proposal.">
            {translateMut.isPending ? <LoadingState message="Translating…" rows={2} /> :
              translateResult ? (
                translateResult.ok && translateResult.proposals.length > 0 ? (
                  <div className="space-y-3">
                    <Alert className="border-green-200 bg-green-50">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-800 text-sm">{translateResult.proposals.length} proposal(s) extracted. Validate by running a simulation.</AlertDescription>
                    </Alert>
                    {translateResult.proposals.map((p: any, i: number) => (
                      <div key={i} className="rounded-lg border border-warm p-3 bg-cream/50">
                        <div className="flex items-center justify-between mb-1">
                          <Badge className="bg-[#FF6B35] text-white">{p.changeType}</Badge>
                          <span className="text-xs font-medium">{p.examName}</span>
                        </div>
                        <p className="text-xs text-warm-muted">{p.rawReasoning}</p>
                        <Button size="sm" variant="outline" className="mt-2 w-full" onClick={() => navigate('what-if-simulation', { examId: p.examId })}>
                          <ArrowRight className="h-3 w-3 mr-1" /> Test in Simulation
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <AlertCircle className="h-8 w-8 text-amber-500 mx-auto mb-2" />
                    <p className="text-sm text-warm-muted">{translateResult.ok ? 'No specific proposals could be extracted. Try being more specific about which exam, date, or room.' : 'Translation failed. ' + (translateResult.error ?? '')}</p>
                  </div>
                )
              ) : (
                <div className="text-center py-8 text-sm text-warm-muted">
                  <FlaskConical className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>Type a request like "Move the Database exam to Friday afternoon" and click the flask icon.</p>
                </div>
              )}
          </SectionCard>

          <Alert className="border-amber-200 bg-amber-50">
            <AlertCircle className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800 text-xs">
              <strong>Important:</strong> The LLM only translates requests and explains results. It never determines feasibility — that's always done by the CP solver. If the LLM is unavailable, a rule-based fallback is used.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    </div>
  );
}
