// Student Portal page — students select their group and see their personalized exam schedule
// with room allotment details, invigilators, and recent change notifications.
// When a student is logged in, their group is auto-selected.

'use client';

import { useState } from 'react';
import { useStudentGroups, useStudentPortal } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { PageHeader, LoadingState, ErrorState, EmptyState, SectionCard, StatCard } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  GraduationCap, MapPin, Clock, UserCheck, Building, Calendar,
  Printer, Bell, CheckCircle2, AlertCircle, FileText, RefreshCw,
} from 'lucide-react';
import { formatDate, formatTimeRange, formatDuration } from '@/lib/time';

export function StudentPortalPage() {
  const { data: groups, isLoading: groupsLoading } = useStudentGroups();
  const { session } = useAuth();
  // For students: auto-use their group. For admins: let them pick.
  const [adminSelectedGroupId, setAdminSelectedGroupId] = useState<string>('');
  // Effective group ID = student's group (if student) OR admin's selection
  const selectedGroupId = session?.role === 'student' ? (session.groupId ?? '') : adminSelectedGroupId;
  const { data: portal, isLoading, isError, refetch } = useStudentPortal(selectedGroupId || null);
  const [lastRefreshed, setLastRefreshed] = useState<Date>(new Date());

  const isStudent = session?.role === 'student';

  const handleRefresh = () => {
    refetch();
    setLastRefreshed(new Date());
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isStudent ? 'My Exam Schedule' : 'Student Portal'}
        description={isStudent
          ? `Welcome, ${session?.name}. Here is your personalized exam timetable with room allotment details and recent updates.`
          : 'Select a student group to view their personalized exam timetable with room allotment details and recent updates.'}
        breadcrumbs={isStudent
          ? [{ label: 'Home' }, { label: 'My Exams' }]
          : [{ label: 'Home' }, { label: 'Scheduling' }, { label: 'Student Portal' }]}
        actions={
          <div className="flex gap-2 no-print">
            <Button variant="outline" onClick={handleRefresh}><RefreshCw className="h-4 w-4 mr-2" /> Refresh</Button>
            <Button variant="outline" onClick={handlePrint} disabled={!portal?.schedule?.length}><Printer className="h-4 w-4 mr-2" /> Print</Button>
          </div>
        }
      />

      {/* Group selector — only shown to admins (students are auto-assigned) */}
      {!isStudent && (
        <Card className="border-warm shadow-warm no-print">
          <CardContent className="p-5">
            <div className="flex items-end gap-3 flex-wrap">
              <div className="flex-1 min-w-[240px]">
                <label className="text-sm font-medium mb-2 block">Select Student Group</label>
                <Select value={adminSelectedGroupId} onValueChange={setAdminSelectedGroupId}>
                  <SelectTrigger><SelectValue placeholder="Choose a group…" /></SelectTrigger>
                  <SelectContent>
                    {groups?.map((g) => (
                      <SelectItem key={g.id} value={g.id}>
                        {g.name} ({g.code}) — {g.studentCount} students
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
            </div>
            {portal && (
              <div className="text-xs text-warm-muted">
                Last updated: {lastRefreshed.toLocaleTimeString()}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      )}

      {groupsLoading ? <LoadingState message="Loading student groups…" /> :
       !selectedGroupId ? (
         <EmptyState
           title={isStudent ? 'No group assigned' : 'Select a student group'}
           description={isStudent
             ? 'Your student account is not linked to a group. Please contact the administrator.'
             : 'Choose a group from the dropdown above to view their personalized exam schedule.'}
           icon={<GraduationCap className="h-8 w-8 text-warm-muted" />}
         />
       ) : isLoading ? <LoadingState message="Loading your exam schedule…" /> :
         isError ? <ErrorState message="Failed to load your schedule" onRetry={() => refetch()} /> :
         !portal ? <ErrorState message="No data received" /> : (
           <div className="space-y-6">
             {/* Group info banner */}
             <Card className="border-warm shadow-warm bg-gradient-to-br from-[#FFF4ED] to-[#FFE5D0]">
               <CardContent className="p-5">
                 <div className="flex items-start gap-4 flex-wrap">
                   <div className="rounded-xl bg-gradient-to-br from-[#FF6B35] to-[#D62828] p-3 shadow-warm-md">
                     <GraduationCap className="h-8 w-8 text-white" />
                   </div>
                   <div className="flex-1 min-w-0">
                     <h2 className="text-xl font-bold text-foreground">{portal.group.name}</h2>
                     <div className="flex items-center gap-3 flex-wrap text-sm text-warm-muted mt-1">
                       <span className="font-mono">{portal.group.code}</span>
                       <span>·</span>
                       <span>{portal.group.studentCount} students</span>
                       {portal.group.program && <><span>·</span><span>{portal.group.program}</span></>}
                       {portal.group.year && <><span>·</span><span>Year {portal.group.year}</span></>}
                     </div>
                   </div>
                   <div className="flex gap-2 no-print">
                     {portal.changes.length > 0 && (
                       <Badge className="bg-[#FF6B35] text-white">
                         <Bell className="h-3 w-3 mr-1" /> {portal.changes.length} recent update{portal.changes.length > 1 ? 's' : ''}
                       </Badge>
                     )}
                   </div>
                 </div>
               </CardContent>
             </Card>

             {/* Stats */}
             <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
               <StatCard title="Total Exams" value={portal.stats.totalExams} icon={<FileText className="h-5 w-5" />} accent="orange" />
               <StatCard title="Scheduled" value={portal.stats.scheduledExams} icon={<CheckCircle2 className="h-5 w-5" />} accent="green" subtitle={`${portal.stats.pendingExams} pending`} />
               <StatCard title="Exam Days" value={portal.stats.uniqueDates} icon={<Calendar className="h-5 w-5" />} accent="blue" />
               <StatCard title="Rooms Used" value={portal.stats.uniqueRooms} icon={<Building className="h-5 w-5" />} accent="amber" />
             </div>

             {/* Schedule */}
             <SectionCard title="Your Exam Schedule" description="Your personalized examination timetable with room allotment details">
               {portal.schedule.length === 0 ? (
                 <EmptyState
                   title="No exams scheduled yet"
                   description="Your exams have not been scheduled yet. Please check back later or contact the administrator."
                   icon={<Calendar className="h-8 w-8 text-warm-muted" />}
                 />
               ) : (
                 <div className="space-y-3">
                   {portal.schedule.map((item: any, idx: number) => (
                     <div key={item.assignmentId} className="rounded-xl border border-warm bg-white p-4 hover:shadow-warm-md transition-shadow">
                       <div className="flex items-start gap-4 flex-wrap">
                         {/* Date badge */}
                         <div className="rounded-xl bg-gradient-to-br from-[#FF6B35] to-[#F77F00] text-white p-3 text-center min-w-[80px] shadow-warm">
                           <p className="text-[10px] uppercase font-semibold">{formatDate(item.date).split(' ')[0]}</p>
                           <p className="text-2xl font-bold leading-none">{formatDate(item.date).split(' ')[1].replace(',', '')}</p>
                           <p className="text-[10px] uppercase">{item.dayName}</p>
                         </div>

                         {/* Exam info */}
                         <div className="flex-1 min-w-[200px]">
                           <div className="flex items-center gap-2 mb-1 flex-wrap">
                             <h3 className="font-bold text-foreground">{item.examName}</h3>
                             <Badge variant="outline" className="text-xs font-mono">{item.subjectCode}</Badge>
                             <Badge variant="secondary" className="text-xs">{item.examType}</Badge>
                           </div>
                           <div className="flex items-center gap-3 flex-wrap text-sm text-warm-muted">
                             <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{formatTimeRange(item.startTime, item.endTime)}</span>
                             <span className="flex items-center gap-1"><FileText className="h-3.5 w-3.5" />{formatDuration(item.duration)}</span>
                             {item.slotLabel && <Badge variant="outline" className="text-xs">{item.slotLabel}</Badge>}
                           </div>
                         </div>

                         {/* Room allotment */}
                         <div className="min-w-[200px]">
                           {item.room ? (
                             <div className="rounded-lg bg-cream p-3 border border-warm">
                               <p className="text-[10px] uppercase font-semibold text-warm-muted mb-1">Room Allotment</p>
                               <p className="font-bold text-foreground">{item.room.name}</p>
                               <div className="text-xs text-warm-muted mt-1 space-y-0.5">
                                 <p className="font-mono">{item.room.code}</p>
                                 {item.room.location && <p className="flex items-center gap-1"><MapPin className="h-3 w-3" />{item.room.location}{item.room.building && `, ${item.room.building}`}{item.room.floor != null && ` · Floor ${item.room.floor}`}</p>}
                                 <p>Capacity: {item.room.capacity} seats</p>
                                 {item.room.features && item.room.features.length > 0 && (
                                   <p>Features: {item.room.features.join(', ')}</p>
                                 )}
                               </div>
                             </div>
                           ) : (
                             <div className="rounded-lg bg-red-50 p-3 border border-red-200">
                               <p className="text-sm text-red-700">Room not assigned</p>
                             </div>
                           )}
                         </div>

                         {/* Invigilators */}
                         <div className="min-w-[150px]">
                           <p className="text-[10px] uppercase font-semibold text-warm-muted mb-1">Invigilators</p>
                           {item.invigilators.length > 0 ? (
                             <div className="space-y-1">
                               {item.invigilators.map((inv: any) => (
                                 <div key={inv.id} className="flex items-center gap-1.5 text-xs">
                                   <UserCheck className="h-3 w-3 text-[#FF6B35]" />
                                   <span className="font-medium">{inv.name}</span>
                                   {inv.department && <span className="text-warm-muted">({inv.department})</span>}
                                 </div>
                               ))}
                             </div>
                           ) : (
                             <p className="text-xs text-warm-muted">Not assigned</p>
                           )}
                         </div>
                       </div>
                     </div>
                   ))}
                 </div>
               )}
             </SectionCard>

             {/* Pending exams */}
             {portal.pendingExams.length > 0 && (
               <SectionCard title="Pending Exams" description="Exams awaiting scheduling">
                 <div className="space-y-2">
                   {portal.pendingExams.map((exam: any) => (
                     <div key={exam.examId} className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                       <div className="flex items-center gap-2">
                         <AlertCircle className="h-4 w-4 text-amber-600" />
                         <span className="font-medium">{exam.examName}</span>
                         <Badge variant="outline" className="text-xs font-mono">{exam.subjectCode}</Badge>
                         <Badge variant="secondary" className="text-xs">{exam.examType}</Badge>
                       </div>
                       <span className="text-xs text-amber-700">Awaiting scheduling · {formatDuration(exam.duration)}</span>
                     </div>
                   ))}
                 </div>
               </SectionCard>
             )}

             {/* Recent changes */}
             {portal.changes.length > 0 && (
               <SectionCard title="Recent Timetable Updates" description="Recent changes affecting your exam schedule">
                 <div className="space-y-2">
                   {portal.changes.map((change: any) => (
                     <div key={change.id} className="flex items-start gap-3 p-3 rounded-lg bg-cream border border-warm">
                       <div className={`rounded-lg p-1.5 ${change.action.includes('applied') ? 'bg-green-100' : 'bg-blue-100'}`}>
                         <Bell className={`h-3.5 w-3.5 ${change.action.includes('applied') ? 'text-green-600' : 'text-blue-600'}`} />
                       </div>
                       <div className="flex-1">
                         <p className="text-sm font-medium">{change.summary}</p>
                         <p className="text-xs text-warm-muted mt-0.5">{change.relativeTime}</p>
                       </div>
                     </div>
                   ))}
                 </div>
               </SectionCard>
             )}

             {/* Print-only summary */}
             <div className="hidden print:block">
               <hr className="my-4" />
               <p className="text-xs text-warm-muted">Printed on {new Date().toLocaleString()}</p>
             </div>
           </div>
         )}
    </div>
  );
}
