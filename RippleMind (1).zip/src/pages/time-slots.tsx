// Time Slots Management page

'use client';

import { useState } from 'react';
import { useTimeSlots, useCreateTimeSlot, useUpdateTimeSlot, useDeleteTimeSlot } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, EmptyState } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Clock, Plus, Pencil, Trash2, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import type { TimeSlot } from '@/lib/types';
import { formatDate, dayName } from '@/lib/time';

export function TimeSlotsPage() {
  const { data: slots, isLoading, isError, refetch } = useTimeSlots();
  const createMut = useCreateTimeSlot();
  const updateMut = useUpdateTimeSlot();
  const deleteMut = useDeleteTimeSlot();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<TimeSlot | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const today = new Date().toISOString().slice(0, 10);
  const [form, setForm] = useState({ date: today, startTime: '09:00', endTime: '11:00', label: '', isAvailable: true });

  // Group by date
  const byDate = new Map<string, TimeSlot[]>();
  for (const s of slots ?? []) {
    if (!byDate.has(s.date)) byDate.set(s.date, []);
    byDate.get(s.date)!.push(s);
  }
  const sortedDates = Array.from(byDate.keys()).sort();

  const openCreate = () => { setEditing(null); setForm({ date: today, startTime: '09:00', endTime: '11:00', label: '', isAvailable: true }); setDialogOpen(true); };
  const openEdit = (s: TimeSlot) => { setEditing(s); setForm({ date: s.date, startTime: s.startTime, endTime: s.endTime, label: s.label ?? '', isAvailable: s.isAvailable }); setDialogOpen(true); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.date.match(/^\d{4}-\d{2}-\d{2}$/)) { toast.error('Date must be YYYY-MM-DD'); return; }
    if (form.startTime >= form.endTime) { toast.error('Start must be before end'); return; }
    try {
      const payload = { ...form, label: form.label || undefined };
      if (editing) { await updateMut.mutateAsync({ id: editing.id, data: payload }); toast.success('Time slot updated'); }
      else { await createMut.mutateAsync(payload); toast.success('Time slot created'); }
      setDialogOpen(false);
    } catch (err) { toast.error((err as Error).message); }
  };
  const handleDelete = async () => { if (!deleteId) return; try { await deleteMut.mutateAsync(deleteId); toast.success('Deleted'); setDeleteId(null); } catch (err) { toast.error((err as Error).message); } };

  return (
    <div className="space-y-6">
      <PageHeader title="Time Slots" description="Define available examination time windows. Each slot has a date, start time, and end time."
        breadcrumbs={[{ label: 'Home' }, { label: 'Resources' }, { label: 'Time Slots' }]}
        actions={<Button onClick={openCreate} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Plus className="h-4 w-4 mr-1" /> Add Slot</Button>} />

      {isLoading ? <LoadingState message="Loading time slots…" /> :
       isError ? <ErrorState message="Failed to load" onRetry={() => refetch()} /> :
       (slots?.length ?? 0) === 0 ? (
         <EmptyState title="No time slots" description="Create your first time slot." icon={<Clock className="h-8 w-8 text-warm-muted" />}
           action={<Button onClick={openCreate} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Plus className="h-4 w-4 mr-1" /> Add Slot</Button>} />
       ) : (
         <div className="space-y-4">
           {sortedDates.map((date) => (
             <Card key={date} className="border-warm shadow-warm">
               <CardContent className="p-4">
                 <div className="flex items-center gap-2 mb-3">
                   <Calendar className="h-4 w-4 text-[#FF6B35]" />
                   <h3 className="font-bold text-foreground">{formatDate(date)}</h3>
                   <Badge variant="outline" className="text-xs">{dayName(date)}</Badge>
                   <Badge variant="outline" className="text-xs ml-auto">{byDate.get(date)!.length} slot(s)</Badge>
                 </div>
                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                   {byDate.get(date)!.map((s) => (
                     <div key={s.id} className={`rounded-lg border p-3 flex items-center justify-between ${s.isAvailable ? 'border-warm bg-cream' : 'border-gray-200 bg-gray-50 opacity-60'}`}>
                       <div className="flex items-center gap-3">
                         <div className="rounded-lg bg-gradient-to-br from-[#FF6B35] to-[#F77F00] text-white p-2 text-center min-w-[70px]">
                           <p className="text-xs font-bold">{s.startTime}</p>
                           <p className="text-[10px]">to</p>
                           <p className="text-xs font-bold">{s.endTime}</p>
                         </div>
                         <div>
                           {s.label && <p className="text-sm font-medium">{s.label}</p>}
                           <p className="text-xs text-warm-muted">{s.isAvailable ? 'Available' : 'Unavailable'}</p>
                         </div>
                       </div>
                       <div className="flex gap-1">
                         <Button variant="ghost" size="icon" onClick={() => openEdit(s)}><Pencil className="h-3.5 w-3.5" /></Button>
                         <Button variant="ghost" size="icon" onClick={() => setDeleteId(s.id)}><Trash2 className="h-3.5 w-3.5 text-red-600" /></Button>
                       </div>
                     </div>
                   ))}
                 </div>
               </CardContent>
             </Card>
           ))}
         </div>
       )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editing ? 'Edit Time Slot' : 'Add Time Slot'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2"><Label>Date *</Label><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} required /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Start Time *</Label><Input type="time" value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} required /></div>
              <div className="space-y-2"><Label>End Time *</Label><Input type="time" value={form.endTime} onChange={(e) => setForm({ ...form, endTime: e.target.value })} required /></div>
            </div>
            <div className="space-y-2"><Label>Label</Label><Input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="e.g. Morning Session" /></div>
            <div className="flex items-center gap-2"><Switch checked={form.isAvailable} onCheckedChange={(v) => setForm({ ...form, isAvailable: v })} /><Label>Available for scheduling</Label></div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-[#FF6B35] hover:bg-[#E85D04] text-white" disabled={createMut.isPending || updateMut.isPending}>{editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete this time slot?</AlertDialogTitle><AlertDialogDescription>Assignments using this slot must be removed first.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
