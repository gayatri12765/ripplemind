// Analytics & Reports page — LIGHTWEIGHT version (CSS charts, no Recharts)
'use client';

import { useAnalytics, useExams, useRooms, useInvigilators, useAssignments } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, SectionCard, StatCard } from '@/components/shared';
import { SimpleStat, CSSHBarChart, CSSPieChart, CSSProgressBar } from '@/components/css-charts';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download, Gauge, TrendingUp, Users, DoorOpen, Calendar, FileText, Activity } from 'lucide-react';
import { toast } from 'sonner';
import { formatDate, dayName } from '@/lib/time';

const CHART_COLORS = ['#FF6B35', '#D62828', '#F77F00', '#FCBF49', '#8C2F0C', '#2D6A4F'];

export function AnalyticsPage() {
  const { data: analytics, isLoading, isError, refetch } = useAnalytics();
  const { data: exams } = useExams();
  const { data: rooms } = useRooms();
  const { data: invs } = useInvigilators();
  const { data: assignments } = useAssignments();

  if (isLoading) return <LoadingState message="Computing analytics…" rows={4} />;
  if (isError || !analytics) return <ErrorState message="Failed to load analytics" onRetry={() => refetch()} />;

  const handleExportExcel = () => {
    if (!assignments?.length) { toast.error('No assignments to export'); return; }
    const rows = [['Date', 'Day', 'Start', 'End', 'Subject Code', 'Exam Name', 'Student Group', 'Enrollment', 'Room', 'Capacity', 'Invigilators']];
    for (const a of assignments) {
      const exam = exams?.find((e) => e.id === a.examId);
      const room = rooms?.find((r) => r.id === a.roomId);
      const invNames = a.invigilatorIds.map((id) => invs?.find((i) => i.id === id)?.name ?? id).join('; ');
      rows.push([a.date, dayName(a.date), a.timeSlot?.startTime ?? '', a.timeSlot?.endTime ?? '', exam?.subjectCode ?? '', exam?.name ?? '', exam?.studentGroup?.name ?? '', String(exam?.enrollmentCount ?? 0), room?.name ?? '', String(room?.capacity ?? 0), invNames]);
    }
    const csv = rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'ripplemind-analytics.csv'; a.click();
    URL.revokeObjectURL(url);
    toast.success('Analytics exported as CSV');
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Analytics & Reports"
        description="Room utilization, invigilator workload, daily distribution, conflict analysis, and schedule quality scoring."
        breadcrumbs={[{ label: 'Home' }, { label: 'Overview' }, { label: 'Analytics' }]}
        actions={<Button variant="outline" onClick={handleExportExcel}><Download className="h-4 w-4 mr-2" /> CSV</Button>} />

      {/* Quality score */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <SimpleStat label="Schedule Quality" value={`${analytics.scheduleQualityScore}/100`} subtitle={`Feasibility ${analytics.qualityBreakdown.feasibility}`} color={analytics.scheduleQualityScore >= 75 ? '#2D6A4F' : analytics.scheduleQualityScore >= 50 ? '#F77F00' : '#D62828'} icon={<Gauge className="h-4 w-4" />} />
        <SimpleStat label="Total Exams" value={analytics.totalExams} subtitle={`${analytics.scheduledExams} scheduled`} color="#FF6B35" icon={<Calendar className="h-4 w-4" />} />
        <SimpleStat label="Seat Utilization" value={`${analytics.seatUtilizationRate ?? 0}%`} subtitle={`${analytics.capacityWaste} wasted seats`} color="#F77F00" icon={<TrendingUp className="h-4 w-4" />} />
        <SimpleStat label="Conflicts" value={analytics.totalConflicts} subtitle={analytics.totalConflicts === 0 ? 'all clear' : 'needs attention'} color={analytics.totalConflicts === 0 ? '#2D6A4F' : '#D62828'} icon={<Activity className="h-4 w-4" />} />
      </div>

      {/* Room utilization + Invigilator workload */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SectionCard title="Room Utilization" description="Assignment count per room">
          <CSSHBarChart
            data={analytics.roomUtilization.slice(0, 8).map((r: any) => ({ label: r.roomName, value: r.assignments, color: '#FF6B35' }))}
            height={250}
          />
        </SectionCard>

        <SectionCard title="Invigilator Workload" description="Assignments vs max workload">
          <CSSHBarChart
            data={analytics.invigilatorWorkload.map((i: any) => ({ label: i.name.split(' ').slice(-1)[0], value: i.assignments, color: i.utilization > 100 ? '#D62828' : '#2D6A4F' }))}
            height={250}
          />
        </SectionCard>
      </div>

      {/* Daily distribution + conflicts by kind */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SectionCard title="Daily Exam Distribution" description="Exams per day">
          <div className="space-y-2">
            {analytics.dailyExams.map((d: any) => (
              <CSSProgressBar key={d.date} label={`${formatDate(d.date).slice(0, 6)} (${dayName(d.date).slice(0, 3)})`} value={d.count} max={Math.max(...analytics.dailyExams.map((x: any) => x.count), 1)} color="#FF6B35" />
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Conflicts by Type" description="Breakdown of conflict categories">
          {analytics.conflictsByKind.length > 0 ? (
            <CSSPieChart
              data={analytics.conflictsByKind.map((c: any, i: number) => ({ name: c.kind.replace(/_/g, ' '), value: c.count, color: CHART_COLORS[i % CHART_COLORS.length] }))}
              size={160}
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-[200px]">
              <Gauge className="h-10 w-10 text-green-500 mb-2" />
              <p className="font-semibold text-green-700">No conflicts detected</p>
              <p className="text-sm text-warm-muted">The schedule is clean.</p>
            </div>
          )}
        </SectionCard>
      </div>

      {/* Student-group workload */}
      {analytics.groupWorkload && analytics.groupWorkload.length > 0 && (
        <SectionCard title="Student-Group Workload Indicators" description="Per-group exam load and scheduling status">
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[700px]">
              <thead className="bg-cream-deep">
                <tr>
                  <th className="text-left p-2">Group</th>
                  <th className="text-center p-2">Students</th>
                  <th className="text-center p-2">Total</th>
                  <th className="text-center p-2">Scheduled</th>
                  <th className="text-center p-2">Unscheduled</th>
                  <th className="text-center p-2">Days</th>
                  <th className="text-center p-2">Max/Day</th>
                  <th className="text-center p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {analytics.groupWorkload.map((g: any) => (
                  <tr key={g.groupId} className="border-t border-warm">
                    <td className="p-2"><div className="font-medium">{g.groupName}</div><div className="text-xs text-warm-muted font-mono">{g.groupCode}</div></td>
                    <td className="p-2 text-center">{g.studentCount}</td>
                    <td className="p-2 text-center font-medium">{g.totalExams}</td>
                    <td className="p-2 text-center text-green-600 font-medium">{g.scheduledExams}</td>
                    <td className="p-2 text-center">{g.unscheduledExams > 0 ? <Badge variant="destructive" className="text-xs">{g.unscheduledExams}</Badge> : <span className="text-green-600">0</span>}</td>
                    <td className="p-2 text-center">{g.examDays}</td>
                    <td className="p-2 text-center"><Badge variant="outline" className={g.maxExamsPerDay >= 3 ? 'border-red-300 text-red-700' : g.maxExamsPerDay === 2 ? 'border-amber-300 text-amber-700' : 'border-green-300 text-green-700'}>{g.maxExamsPerDay}</Badge></td>
                    <td className="p-2 text-center"><Badge className={g.workloadStatus === 'overloaded' ? 'bg-red-100 text-red-800 text-xs' : g.workloadStatus === 'balanced' ? 'bg-amber-100 text-amber-800 text-xs' : 'bg-green-100 text-green-800 text-xs'}>{g.workloadStatus}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      )}

      {/* Seat utilization */}
      {analytics.seatUtilization && analytics.seatUtilization.length > 0 && (
        <SectionCard title="Seat Utilization" description={`Overall rate: ${analytics.seatUtilizationRate ?? 0}%`}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[600px]">
              <thead className="bg-cream-deep">
                <tr>
                  <th className="text-left p-2">Exam</th>
                  <th className="text-left p-2">Room</th>
                  <th className="text-center p-2">Enrolled</th>
                  <th className="text-center p-2">Capacity</th>
                  <th className="text-center p-2">Utilization</th>
                  <th className="text-center p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {analytics.seatUtilization.slice(0, 10).map((s: any, i: number) => (
                  <tr key={i} className="border-t border-warm">
                    <td className="p-2"><div className="font-medium">{s.examName}</div><div className="text-xs text-warm-muted font-mono">{s.subjectCode}</div></td>
                    <td className="p-2">{s.roomName}</td>
                    <td className="p-2 text-center">{s.enrolled}</td>
                    <td className="p-2 text-center">{s.capacity}</td>
                    <td className="p-2"><CSSProgressBar value={s.utilization} color={s.utilization >= 90 ? '#D62828' : s.utilization >= 70 ? '#FF6B35' : '#F77F00'} /></td>
                    <td className="p-2 text-center"><Badge className={s.status === 'full' ? 'bg-red-100 text-red-800 text-xs' : s.status === 'good' ? 'bg-green-100 text-green-800 text-xs' : 'bg-amber-100 text-amber-800 text-xs'}>{s.status}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      )}

      {/* Quality breakdown */}
      <SectionCard title="Schedule Quality Breakdown">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {([
            ['Feasibility', analytics.qualityBreakdown.feasibility, '#2D6A4F'],
            ['Utilization', analytics.qualityBreakdown.utilization, '#FF6B35'],
            ['Load Balance', analytics.qualityBreakdown.loadBalance, '#3C91E6'],
            ['Capacity Efficiency', analytics.qualityBreakdown.wasteScore, '#F77F00'],
          ] as const).map(([label, value, color]) => (
            <div key={label} className="rounded-lg border border-warm p-4 text-center">
              <p className="text-xs text-warm-muted">{label}</p>
              <p className="text-3xl font-bold" style={{ color }}>{value}</p>
              <div className="mt-2"><CSSProgressBar value={value} color={color} /></div>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
