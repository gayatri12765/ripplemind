// Login page — role-based authentication (Admin or Student)

'use client';

import { useState, useEffect } from 'react';
import { useAuth, type UserRole } from '@/lib/auth';
import { useStudentGroups } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Waves, Shield, GraduationCap, Lock, User, Users, ArrowRight, Info } from 'lucide-react';

export function LoginPage() {
  const { login } = useAuth();
  const { data: groups, isLoading: groupsLoading } = useStudentGroups();

  // Admin form state
  const [adminEmail, setAdminEmail] = useState('admin@ripplemind.edu');
  const [adminPassword, setAdminPassword] = useState('admin123');

  // Student form state
  const [studentGroupId, setStudentGroupId] = useState('');
  const [studentName, setStudentName] = useState('');

  const [error, setError] = useState('');

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!adminEmail.trim() || !adminPassword.trim()) {
      setError('Email and password are required');
      return;
    }
    // Demo authentication — in production this would call a real auth API
    if (adminPassword.length < 4) {
      setError('Password must be at least 4 characters');
      return;
    }
    login({
      role: 'admin',
      name: adminEmail.split('@')[0] || 'Administrator',
      loginAt: Date.now(),
    });
  };

  const handleStudentLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!studentGroupId) {
      setError('Please select your student group');
      return;
    }
    if (!studentName.trim()) {
      setError('Please enter your name');
      return;
    }
    const group = groups?.find((g) => g.id === studentGroupId);
    login({
      role: 'student',
      name: studentName.trim(),
      groupId: studentGroupId,
      groupName: group?.name,
      loginAt: Date.now(),
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-[#FFF8F2] via-[#FFE5D0] to-[#FFF4ED]">
      {/* Decorative background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 h-96 w-96 rounded-full bg-[#FF6B35]/10 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 h-96 w-96 rounded-full bg-[#D62828]/10 blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF6B35] to-[#D62828] shadow-warm-lg mb-4">
            <Waves className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-foreground">RippleMind</h1>
          <p className="text-sm text-warm-muted mt-1">AI-Driven Examination Timetable</p>
        </div>

        <Card className="border-warm shadow-warm-lg">
          <CardHeader className="pb-4">
            <CardTitle className="text-center text-xl">Sign In</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="admin" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="admin" className="flex items-center gap-2">
                  <Shield className="h-4 w-4" /> Administrator
                </TabsTrigger>
                <TabsTrigger value="student" className="flex items-center gap-2">
                  <GraduationCap className="h-4 w-4" /> Student
                </TabsTrigger>
              </TabsList>

              {/* Admin login */}
              <TabsContent value="admin">
                <form onSubmit={handleAdminLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="admin-email">Email</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-warm-muted" />
                      <Input
                        id="admin-email"
                        type="email"
                        value={adminEmail}
                        onChange={(e) => setAdminEmail(e.target.value)}
                        placeholder="admin@ripplemind.edu"
                        className="pl-9"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admin-password">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-warm-muted" />
                      <Input
                        id="admin-password"
                        type="password"
                        value={adminPassword}
                        onChange={(e) => setAdminPassword(e.target.value)}
                        placeholder="••••••••"
                        className="pl-9"
                        required
                      />
                    </div>
                  </div>

                  <Alert className="border-[#FF6B35]/30 bg-orange-50">
                    <Info className="h-4 w-4 text-[#FF6B35]" />
                    <AlertDescription className="text-xs text-orange-800">
                      <strong>Demo credentials:</strong> Any email + password (min 4 chars).
                      Admins get full access to all scheduling features.
                    </AlertDescription>
                  </Alert>

                  {error && (
                    <Alert className="border-red-200 bg-red-50">
                      <AlertDescription className="text-red-800 text-sm">{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button type="submit" className="w-full bg-gradient-to-r from-[#FF6B35] to-[#D62828] text-white hover:opacity-90">
                    Sign in as Administrator <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </form>
              </TabsContent>

              {/* Student login */}
              <TabsContent value="student">
                <form onSubmit={handleStudentLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="student-name">Your Name</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-warm-muted" />
                      <Input
                        id="student-name"
                        type="text"
                        value={studentName}
                        onChange={(e) => setStudentName(e.target.value)}
                        placeholder="e.g. Priya Sharma"
                        className="pl-9"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="student-group">Your Student Group</Label>
                    <div className="relative">
                      <Users className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-warm-muted pointer-events-none" />
                      <Select value={studentGroupId} onValueChange={setStudentGroupId}>
                        <SelectTrigger className="pl-9">
                          <SelectValue placeholder={groupsLoading ? 'Loading groups…' : 'Select your group'} />
                        </SelectTrigger>
                        <SelectContent>
                          {groups?.map((g) => (
                            <SelectItem key={g.id} value={g.id}>
                              {g.name} ({g.code}) — {g.studentCount} students
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Alert className="border-[#FF6B35]/30 bg-orange-50">
                    <Info className="h-4 w-4 text-[#FF6B35]" />
                    <AlertDescription className="text-xs text-orange-800">
                      Students can view their personalized exam timetable, room allotment details,
                      and receive notifications when the schedule changes.
                    </AlertDescription>
                  </Alert>

                  {error && (
                    <Alert className="border-red-200 bg-red-50">
                      <AlertDescription className="text-red-800 text-sm">{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button type="submit" className="w-full bg-gradient-to-r from-[#FF6B35] to-[#D62828] text-white hover:opacity-90" disabled={groupsLoading}>
                    Sign in as Student <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <p className="text-center text-xs text-warm-muted mt-6">
          RippleMind v2.0 · Examination Timetable Simulation & Optimization
        </p>
      </div>
    </div>
  );
}
