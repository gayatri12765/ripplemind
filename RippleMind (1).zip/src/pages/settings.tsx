// Settings page — theme, demo data, audit log, system info

'use client';

import { useSeedData, useResetData, useAuditLog, useSettings, useUpdateSettings } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, SectionCard, EmptyState } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Database, Trash2, Download, Save, History, Info, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import { useState } from 'react';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export function SettingsPage() {
  const seedMut = useSeedData();
  const resetMut = useResetData();
  const { data: auditLogs, isLoading: auditLoading } = useAuditLog(50);
  const { data: settings } = useSettings();
  const updateSettings = useUpdateSettings();
  const [resetOpen, setResetOpen] = useState(false);
  const [solverTime, setSolverTime] = useState(settings?.SOLVER_TIME_LIMIT_MS ?? '8000');

  const handleSeed = async () => {
    try { await seedMut.mutateAsync(); toast.success('Demo data loaded successfully'); }
    catch (err) { toast.error((err as Error).message); }
  };
  const handleReset = async () => {
    try { await resetMut.mutateAsync(); toast.success('All data cleared'); setResetOpen(false); }
    catch (err) { toast.error((err as Error).message); }
  };
  const handleSaveSettings = async () => {
    try { await updateSettings.mutateAsync({ SOLVER_TIME_LIMIT_MS: solverTime }); toast.success('Settings saved'); }
    catch (err) { toast.error((err as Error).message); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" description="Manage application data, solver configuration, and view the audit log."
        breadcrumbs={[{ label: 'Home' }, { label: 'System' }, { label: 'Settings' }]} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SectionCard title="Demo Data" description="Load or clear sample data for testing.">
          <div className="space-y-4">
            <Alert className="border-[#FF6B35]/30 bg-orange-50">
              <Info className="h-4 w-4 text-[#FF6B35]" />
              <AlertDescription className="text-orange-800">
                Loading demo data will clear all existing data and replace it with a rich sample dataset (8 student groups, 10 exams, 12 rooms, 15 time slots, 6 invigilators).
              </AlertDescription>
            </Alert>
            <div className="flex gap-2">
              <Button onClick={handleSeed} disabled={seedMut.isPending} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white">
                <Database className="h-4 w-4 mr-2" /> {seedMut.isPending ? 'Loading…' : 'Load Demo Data'}
              </Button>
              <Button variant="outline" onClick={() => setResetOpen(true)} disabled={resetMut.isPending} className="text-red-600 hover:text-red-700">
                <Trash2 className="h-4 w-4 mr-2" /> Clear All Data
              </Button>
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Solver Configuration" description="Default settings for the CP solver.">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Default Time Limit (ms)</Label>
              <Input type="number" value={solverTime} onChange={(e) => setSolverTime(e.target.value)} min={1000} max={30000} />
              <p className="text-xs text-warm-muted">How long the solver searches for an optimal solution before returning the best found.</p>
            </div>
            <Button onClick={handleSaveSettings} disabled={updateSettings.isPending} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white">
              <Save className="h-4 w-4 mr-2" /> Save Settings
            </Button>
          </div>
        </SectionCard>
      </div>

      <SectionCard title="System Information" description="Architecture and adaptation notes">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="space-y-2">
            <h4 className="font-semibold flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-green-600" /> Technology Stack</h4>
            <ul className="space-y-1 text-warm-muted">
              <li>• Frontend: React 19 + TypeScript + Tailwind CSS 4</li>
              <li>• Framework: Next.js 16 (App Router)</li>
              <li>• Database: Prisma ORM (SQLite dev / PostgreSQL prod)</li>
              <li>• Solver: Real CP solver in TypeScript (backtracking + MRV)</li>
              <li>• Charts: Recharts</li>
              <li>• Graph visualization: React Flow</li>
              <li>• AI: z-ai-web-dev-sdk (GLM-4.6)</li>
            </ul>
          </div>
          <div className="space-y-2">
            <h4 className="font-semibold flex items-center gap-2"><Info className="h-4 w-4 text-[#FF6B35]" /> Architecture Adaptation</h4>
            <p className="text-warm-muted">
              The spec called for Python/FastAPI + OR-Tools CP-SAT. Since this environment runs Next.js (no Python runtime), the backend was adapted to Next.js API routes (REST preserved) and a real CP solver was implemented in TypeScript.
              The solver uses backtracking search with MRV ordering, hard-constraint enforcement, and multi-objective optimization. It honestly reports infeasibility vs timeout. This is not a stub — it actually solves.
            </p>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Audit Log" description="Recent system actions and scenario approvals">
        {auditLoading ? <LoadingState message="Loading audit log…" rows={3} /> :
         !auditLogs || auditLogs.length === 0 ? <EmptyState title="No audit entries" description="Actions will appear here." icon={<History className="h-8 w-8 text-warm-muted" />} /> : (
           <div className="space-y-2 max-h-96 overflow-y-auto scrollbar-thin">
             {auditLogs.map((log: any) => (
               <div key={log.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-cream-deep">
                 <div className={`rounded-lg p-1.5 ${log.category === 'scenario' ? 'bg-blue-100' : log.category === 'schedule' ? 'bg-orange-100' : log.category === 'system' ? 'bg-purple-100' : 'bg-gray-100'}`}>
                   <History className={`h-3.5 w-3.5 ${log.category === 'scenario' ? 'text-blue-600' : log.category === 'schedule' ? 'text-orange-600' : log.category === 'system' ? 'text-purple-600' : 'text-gray-600'}`} />
                 </div>
                 <div className="flex-1 min-w-0">
                   <p className="text-sm font-medium">{log.summary}</p>
                   <div className="flex items-center gap-2 text-xs text-warm-muted">
                     <Badge variant="outline" className="text-[10px]">{log.action}</Badge>
                     <span>{formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })}</span>
                   </div>
                 </div>
               </div>
             ))}
           </div>
         )}
      </SectionCard>

      <AlertDialog open={resetOpen} onOpenChange={setResetOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear all data?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete all exams, rooms, time slots, invigilators, assignments, scenarios, and audit logs. This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleReset} className="bg-red-600 hover:bg-red-700">Clear Everything</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
