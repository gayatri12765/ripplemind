// Student Groups Management page

'use client';

import { useState } from 'react';
import { useStudentGroups, useCreateStudentGroup, useUpdateStudentGroup, useDeleteStudentGroup } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, EmptyState } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Users, Plus, Pencil, Trash2, Search } from 'lucide-react';
import { toast } from 'sonner';
import type { StudentGroup } from '@/lib/types';

export function StudentGroupsPage() {
  const { data: groups, isLoading, isError, refetch } = useStudentGroups();
  const createMut = useCreateStudentGroup();
  const updateMut = useUpdateStudentGroup();
  const deleteMut = useDeleteStudentGroup();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<(StudentGroup & { examCount?: number }) | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ name: '', code: '', studentCount: 0, program: '', year: 3 });

  const filtered = groups?.filter((g) =>
    g.name.toLowerCase().includes(search.toLowerCase()) || g.code.toLowerCase().includes(search.toLowerCase())
  ) ?? [];

  const openCreate = () => {
    setEditing(null);
    setForm({ name: '', code: '', studentCount: 0, program: '', year: 3 });
    setDialogOpen(true);
  };
  const openEdit = (g: StudentGroup & { examCount?: number }) => {
    setEditing(g);
    setForm({ name: g.name, code: g.code, studentCount: g.studentCount, program: g.program ?? '', year: g.year ?? 3 });
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.code.trim()) { toast.error('Name and code are required'); return; }
    if (form.studentCount <= 0) { toast.error('Student count must be positive'); return; }
    try {
      const payload = { ...form, program: form.program || undefined, year: form.year || undefined };
      if (editing) {
        await updateMut.mutateAsync({ id: editing.id, data: payload });
        toast.success('Student group updated');
      } else {
        await createMut.mutateAsync(payload);
        toast.success('Student group created');
      }
      setDialogOpen(false);
    } catch (err) { toast.error((err as Error).message); }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try { await deleteMut.mutateAsync(deleteId); toast.success('Deleted'); setDeleteId(null); }
    catch (err) { toast.error((err as Error).message); }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Student Groups"
        description="Manage student cohorts. Each exam is linked to exactly one student group."
        breadcrumbs={[{ label: 'Home' }, { label: 'Resources' }, { label: 'Student Groups' }]}
        actions={<Button onClick={openCreate} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Plus className="h-4 w-4 mr-1" /> Add Group</Button>}
      />

      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-warm-muted" />
          <Input placeholder="Search groups…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
      </div>

      {isLoading ? <LoadingState message="Loading student groups…" /> :
       isError ? <ErrorState message="Failed to load" onRetry={() => refetch()} /> :
       filtered.length === 0 ? (
         <EmptyState title="No student groups" description="Create your first student group." icon={<Users className="h-8 w-8 text-warm-muted" />}
           action={!search && <Button onClick={openCreate} className="bg-[#FF6B35] hover:bg-[#E85D04] text-white"><Plus className="h-4 w-4 mr-1" /> Add Group</Button>} />
       ) : (
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
           {filtered.map((g) => (
             <Card key={g.id} className="border-warm shadow-warm hover:shadow-warm-md transition-shadow">
               <CardContent className="p-5">
                 <div className="flex items-start justify-between">
                   <div className="rounded-xl bg-gradient-to-br from-[#FF6B35] to-[#F77F00] p-2.5 shadow-warm">
                     <Users className="h-5 w-5 text-white" />
                   </div>
                   <div className="flex gap-1">
                     <Button variant="ghost" size="icon" onClick={() => openEdit(g)}><Pencil className="h-4 w-4" /></Button>
                     <Button variant="ghost" size="icon" onClick={() => setDeleteId(g.id)}><Trash2 className="h-4 w-4 text-red-600" /></Button>
                   </div>
                 </div>
                 <h3 className="font-bold text-foreground mt-3">{g.name}</h3>
                 <p className="text-xs font-mono text-warm-muted">{g.code}</p>
                 <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                   <div><span className="text-warm-muted">Students:</span> <span className="font-semibold">{g.studentCount}</span></div>
                   <div><span className="text-warm-muted">Exams:</span> <span className="font-semibold">{g.examCount ?? 0}</span></div>
                   {g.program && <div className="col-span-2"><span className="text-warm-muted">Program:</span> <span className="font-medium">{g.program}</span></div>}
                   {g.year && <div><span className="text-warm-muted">Year:</span> <span className="font-medium">{g.year}</span></div>}
                 </div>
               </CardContent>
             </Card>
           ))}
         </div>
       )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editing ? 'Edit Student Group' : 'Add Student Group'}</DialogTitle></DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Group Name *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            </div>
            <div className="space-y-2">
              <Label>Code *</Label>
              <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="e.g. CS-Y3" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Student Count *</Label>
                <Input type="number" min={1} value={form.studentCount} onChange={(e) => setForm({ ...form, studentCount: Number(e.target.value) })} required />
              </div>
              <div className="space-y-2">
                <Label>Year</Label>
                <Input type="number" min={1} max={6} value={form.year} onChange={(e) => setForm({ ...form, year: Number(e.target.value) })} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Program</Label>
              <Input value={form.program} onChange={(e) => setForm({ ...form, program: e.target.value })} placeholder="e.g. BSc Computer Science" />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-[#FF6B35] hover:bg-[#E85D04] text-white" disabled={createMut.isPending || updateMut.isPending}>{editing ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this student group?</AlertDialogTitle>
            <AlertDialogDescription>Exams referencing this group must be reassigned first.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
