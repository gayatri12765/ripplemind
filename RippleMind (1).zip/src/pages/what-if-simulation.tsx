// What-if Simulation page — propose a change, run the solver, see if it's feasible
// Now with interactive bar graphs visualizing the impact.

'use client';

import { useState } from 'react';
import { useExams, useRooms, useTimeSlots, useInvigilators, useCreateScenario, useApplyScenario } from '@/lib/api';
import { PageHeader, LoadingState, ErrorState, SectionCard, StatCard } from '@/components/shared';
import { WhatIfCharts } from '@/components/what-if-charts';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { FlaskConical, Play, CheckCircle2, XCircle, Clock, ArrowRight, GitCompare, Sparkles, Zap, Activity } from 'lucide-react';
import { toast } from 'sonner';
import { useNav } from '@/lib/store';
import { formatDate, formatTimeRange, formatDuration } from '@/lib/time';
import type { Scenario, SolverSolution } from '@/lib/types';

export function WhatIfSimulationPage() {
  const { data: exams, isLoading: examsLoading } = useExams();
  const { data: rooms } = useRooms();
  const { data: slots } = useTimeSlots();
  const { data: invs } = useInvigilators();
  const createMut = useCreateScenario();
  const applyMut = useApplyScenario();
  const { navigate, pageParams } = useNav();

  const [examId, setExamId] = useState(pageParams.examId ?? '');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [targetSlotId, setTargetSlotId] = useState('');
  const [targetRoomId, setTargetRoomId] = useState('');
  const [targetInvigilatorIds, setTargetInvigilatorIds] = useState<string[]>([]);
  const [generateAlts, setGenerateAlts] = useState(true);
  const [result, setResult] = useState<{ scenario: Scenario; solution: SolverSolution } | null>(null);

  const selectedExam = exams?.find((e) => e.id === examId);
  const currentAssignment = selectedExam?.assignment;

  const handleSimulate = async () => {
    if (!examId) { toast.error('Select an exam to modify'); return; }
    if (!name.trim()) { toast.error('Scenario name is required'); return; }
    if (!targetSlotId && !targetRoomId && !targetInvigilatorIds.length) { toast.error('Specify at least one change'); return; }
    try {
      const res = await createMut.mutateAsync({
        name: name.trim(),
        description: description.trim() || undefined,
        examId,
        change: {
          targetSlotId: targetSlotId || undefined,
          targetRoomId: targetRoomId || undefined,
          targetInvigilatorIds: targetInvigilatorIds.length ? targetInvigilatorIds : undefined,
        },
        generateAlternatives: generateAlts,
      });
      setResult(res);
      if (res.solution.feasible) toast.success('Simulation complete — change is feasible');
      else if (res.solution.provenInfeasible) toast.error('Simulation complete — change is infeasible');
      else toast.warning('Solver timed out');
    } catch (err) { toast.error((err as Error).message); }
  };

  const handleApply = async () => {
    if (!result?.scenario) return;
    try {
      await applyMut.mutateAsync({ id: result.scenario.id });
      toast.success('Scenario applied — timetable updated');
      navigate('timetable-viewer');
    } catch (err) { toast.error((err as Error).message); }
  };

  const toggleInvigilator = (id: string) => {
    setTargetInvigilatorIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  };

  if (examsLoading) return <LoadingState message="Loading exams…" />;

  return (
    <div className="space-y-6">
      <PageHeader title="What-if Simulation" description="Propose a change to an exam's schedule and test feasibility without modifying the published timetable. The solver runs in a separate scenario — nothing is published until you approve."
        breadcrumbs={[{ label: 'Home' }, { label: 'Simulation' }, { label: 'What-if' }]} />

      <SectionCard title="Step 1: Select Exam & Propose Change" description="Choose an exam and specify the changes you want to test.">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Scenario Name *</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Move Database exam to Friday" />
            </div>
            <div className="space-y-2">
              <Label>Exam to Modify *</Label>
              <Select value={examId} onValueChange={setExamId}>
                <SelectTrigger><SelectValue placeholder="Select exam" /></SelectTrigger>
                <SelectContent>
                  {exams?.map((e) => <SelectItem key={e.id} value={e.id}>{e.name} ({e.subjectCode})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedExam && (
            <Alert className="border-warm bg-cream">
              <AlertDescription>
                <div className="flex items-center gap-3 flex-wrap text-sm">
                  <span className="font-medium">Current assignment:</span>
                  {currentAssignment ? (
                    <>
                      <Badge variant="outline">{formatDate(currentAssignment.date)}</Badge>
                      <Badge variant="outline">{currentAssignment.timeSlot ? formatTimeRange(currentAssignment.timeSlot.startTime, currentAssignment.timeSlot.endTime) : '—'}</Badge>
                      <Badge variant="outline">{currentAssignment.room?.name ?? '—'}</Badge>
                      <span className="text-warm-muted">Enrollment: {selectedExam.enrollmentCount} · Duration: {formatDuration(selectedExam.duration)}</span>
                    </>
                  ) : (
                    <span className="text-warm-muted">This exam is not yet scheduled.</span>
                  )}
                </div>
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>New Time Slot</Label>
              <Select value={targetSlotId} onValueChange={setTargetSlotId}>
                <SelectTrigger><SelectValue placeholder="Keep current" /></SelectTrigger>
                <SelectContent>
                  {slots?.filter((s) => s.isAvailable).map((s) => (
                    <SelectItem key={s.id} value={s.id}>{formatDate(s.date)} {s.startTime}-{s.endTime}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>New Room</Label>
              <Select value={targetRoomId} onValueChange={setTargetRoomId}>
                <SelectTrigger><SelectValue placeholder="Keep current" /></SelectTrigger>
                <SelectContent>
                  {rooms?.filter((r) => r.isAvailable && r.capacity >= (selectedExam?.enrollmentCount ?? 0)).map((r) => (
                    <SelectItem key={r.id} value={r.id}>{r.name} (cap {r.capacity})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>New Invigilator(s)</Label>
              <div className="border border-warm rounded-lg p-2 max-h-24 overflow-y-auto scrollbar-thin space-y-1">
                {invs?.filter((i) => i.isAvailable).map((i) => (
                  <label key={i.id} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-cream-deep px-1 py-0.5 rounded">
                    <input type="checkbox" checked={targetInvigilatorIds.includes(i.id)} onChange={() => toggleInvigilator(i.id)} className="accent-[#FF6B35]" />
                    <span>{i.name}</span>
                    <span className="text-xs text-warm-muted">({i.department})</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Description (optional)</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} placeholder="Why are you making this change?" />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Switch checked={generateAlts} onCheckedChange={setGenerateAlts} />
              <Label className="cursor-pointer">Generate alternative solutions for comparison</Label>
            </div>
            <Button onClick={handleSimulate} disabled={createMut.isPending} className="bg-gradient-to-r from-[#FF6B35] to-[#D62828] text-white hover:opacity-90">
              {createMut.isPending ? <><Clock className="h-4 w-4 mr-2 animate-spin" /> Simulating…</> : <><FlaskConical className="h-4 w-4 mr-2" /> Run Simulation</>}
            </Button>
          </div>
        </div>
      </SectionCard>

      {result && (
        <SectionCard
          title="Step 2: Simulation Results"
          description={result.solution.feasible ? 'The proposed change is feasible. Review the impact below.' : result.solution.provenInfeasible ? 'The proposed change is infeasible.' : 'Solver timed out.'}
          actions={
            <div className="flex gap-2">
              {result.solution.feasible && (
                <Button onClick={handleApply} disabled={applyMut.isPending} className="bg-green-600 hover:bg-green-700 text-white">
                  <CheckCircle2 className="h-4 w-4 mr-2" /> Apply & Publish
                </Button>
              )}
              {result.scenario.alternatives.length > 1 && (
                <Button variant="outline" onClick={() => navigate('alternative-comparison', { scenarioId: result.scenario.id })}>
                  <GitCompare className="h-4 w-4 mr-2" /> Compare Alternatives
                </Button>
              )}
              <Button variant="outline" onClick={() => navigate('ripple-analysis', { scenarioId: result.scenario.id })}>
                <Sparkles className="h-4 w-4 mr-2" /> Ripple Analysis
              </Button>
            </div>
          }
        >
          <div className="space-y-4">
            {/* Animated stat cards with gradient backgrounds */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div className={`rounded-xl p-4 border-2 transition-all hover:scale-[1.02] ${result.solution.feasible ? 'border-green-300 bg-gradient-to-br from-green-50 to-green-100' : 'border-red-300 bg-gradient-to-br from-red-50 to-red-100'}`}>
                <p className="text-xs text-warm-muted uppercase tracking-wide">Feasibility</p>
                {result.solution.feasible ? (
                  <div className="flex items-center gap-2 mt-1">
                    <div className="rounded-lg bg-green-500 p-1.5 shadow-sm">
                      <CheckCircle2 className="h-4 w-4 text-white" />
                    </div>
                    <span className="text-xl font-bold text-green-700">Feasible</span>
                  </div>
                ) : result.solution.provenInfeasible ? (
                  <div className="flex items-center gap-2 mt-1">
                    <div className="rounded-lg bg-red-500 p-1.5 shadow-sm">
                      <XCircle className="h-4 w-4 text-white" />
                    </div>
                    <span className="text-xl font-bold text-red-700">Infeasible</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 mt-1">
                    <div className="rounded-lg bg-amber-500 p-1.5 shadow-sm">
                      <Clock className="h-4 w-4 text-white animate-pulse" />
                    </div>
                    <span className="text-xl font-bold text-amber-700">Timed out</span>
                  </div>
                )}
              </div>
              <div className="rounded-xl p-4 border-2 border-[#FF6B35]/30 bg-gradient-to-br from-[#FFF4ED] to-[#FFE5D0] transition-all hover:scale-[1.02]">
                <p className="text-xs text-warm-muted uppercase tracking-wide flex items-center gap-1"><Activity className="h-3 w-3" /> Exams Affected</p>
                <p className="text-3xl font-bold text-[#FF6B35] mt-1">{result.solution.metrics.changedExamsFromBaseline ?? 0}</p>
                <p className="text-[10px] text-warm-muted">of {result.solution.assignments.length} total</p>
              </div>
              <div className="rounded-xl p-4 border-2 border-amber-200 bg-gradient-to-br from-amber-50 to-amber-100 transition-all hover:scale-[1.02]">
                <p className="text-xs text-warm-muted uppercase tracking-wide">Conflicts</p>
                <p className={`text-3xl font-bold mt-1 ${result.solution.conflicts.length > 0 ? 'text-amber-600' : 'text-green-600'}`}>
                  {result.solution.conflicts.length}
                </p>
                <p className="text-[10px] text-warm-muted">{result.solution.conflicts.length === 0 ? 'none detected' : 'needs attention'}</p>
              </div>
              <div className="rounded-xl p-4 border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100 transition-all hover:scale-[1.02]">
                <p className="text-xs text-warm-muted uppercase tracking-wide flex items-center gap-1"><Zap className="h-3 w-3" /> Solver Time</p>
                <p className="text-3xl font-bold text-blue-600 mt-1">{result.solution.metrics.elapsedMs}<span className="text-base">ms</span></p>
                <p className="text-[10px] text-warm-muted">{result.solution.metrics.searchNodes.toLocaleString()} nodes</p>
              </div>
            </div>

            {result.solution.feasible && (
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  The change is feasible. <strong>{result.solution.metrics.changedExamsFromBaseline ?? 0}</strong> exam(s) need to move.
                  The original timetable is <strong>not modified</strong> until you click <strong>Apply & Publish</strong>.
                </AlertDescription>
              </Alert>
            )}

            {/* Interactive bar graphs — the main visual addition */}
            <WhatIfCharts
              original={result.scenario.originalState}
              proposed={result.solution.assignments}
              conflicts={result.solution.conflicts.length}
              feasible={result.solution.feasible}
              exams={exams ?? []}
              rooms={rooms ?? []}
              timeSlots={slots ?? []}
              invigilators={invs ?? []}
              changedExams={result.solution.metrics.changedExamsFromBaseline ?? 0}
              roomChanges={result.solution.metrics.roomChangesFromBaseline ?? 0}
            />

            {result.solution.conflicts.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold mb-2 text-red-700">Detected Conflicts ({result.solution.conflicts.length})</h4>
                <div className="space-y-1 max-h-48 overflow-y-auto scrollbar-thin">
                  {result.solution.conflicts.slice(0, 10).map((c) => (
                    <div key={c.id} className="text-sm p-2 rounded-lg bg-red-50 border border-red-100">
                      <Badge variant={c.severity === 'critical' ? 'destructive' : 'secondary'} className="text-xs mr-2">{c.severity}</Badge>
                      <span className="font-medium">{c.title}:</span> <span className="text-warm-muted">{c.description}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div>
              <h4 className="text-sm font-semibold mb-2">Proposed Assignments ({result.solution.assignments.length})</h4>
              <div className="rounded-lg border border-warm overflow-hidden max-h-64 overflow-y-auto scrollbar-thin">
                <table className="w-full text-sm">
                  <thead className="bg-cream-deep sticky top-0">
                    <tr><th className="text-left p-2">Exam</th><th className="text-left p-2">Date</th><th className="text-left p-2">Time</th><th className="text-left p-2">Room</th><th className="text-center p-2">Changed?</th></tr>
                  </thead>
                  <tbody>
                    {result.solution.assignments.map((a) => {
                      const exam = exams?.find((e) => e.id === a.examId);
                      const room = rooms?.find((r) => r.id === a.roomId);
                      const slot = slots?.find((s) => s.id === a.timeSlotId);
                      const orig = result.scenario.originalState.find((o) => o.examId === a.examId);
                      const changed = !orig || orig.roomId !== a.roomId || orig.timeSlotId !== a.timeSlotId;
                      return (
                        <tr key={a.examId} className={`border-t border-warm ${changed ? 'bg-orange-50/50' : ''}`}>
                          <td className="p-2 font-medium">{exam?.name ?? a.examId}</td>
                          <td className="p-2">{slot?.date ?? '—'}</td>
                          <td className="p-2 font-mono text-xs">{slot ? `${slot.startTime}-${slot.endTime}` : '—'}</td>
                          <td className="p-2">{room?.name ?? a.roomId}</td>
                          <td className="p-2 text-center">{changed ? <Badge className="bg-[#FF6B35] text-white text-xs">changed</Badge> : '—'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </SectionCard>
      )}
    </div>
  );
}
