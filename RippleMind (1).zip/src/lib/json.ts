// JSON helpers for SQLite — Prisma SQLite has no native arrays, so we store JSON strings.

export function parseJSON<T>(value: string | null | undefined, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

export function stringifyJSON(value: unknown): string {
  return JSON.stringify(value ?? []);
}

export function parseStringArray(value: string | null | undefined): string[] {
  return parseJSON<string[]>(value, []);
}

export function parseNumberArray(value: string | null | undefined): number[] {
  return parseJSON<number[]>(value, []);
}
