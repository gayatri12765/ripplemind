// Conflict detection engine — implements the 6 hard-constraint checks from the spec.
//
// 1. Two exams assigned to the same room at overlapping times.
// 2. Exams with overlapping times for the same student group.
// 3. Room capacity violations.
// 4. Invigilator double-booking.
// 5. Unavailable rooms, slots, or invigilators.
// 6. Invalid or incomplete exam assignments.

import {
  type AssignmentProposal,
  type Conflict,
  type ConflictSeverity,
  type Exam,
  type Invigilator,
  type Room,
  type StudentGroup,
  type TimeSlot,
} from './types';
import { parseStringArray, parseJSON } from './json';
import { slotsOverlapOnSameDate } from './time';

export interface ConflictContext {
  exams: Exam[];
  rooms: Room[];
  timeSlots: TimeSlot[];
  invigilators: Invigilator[];
  studentGroups: StudentGroup[];
}

export interface DetectConflictsInput {
  assignments: AssignmentProposal[];
  context: ConflictContext;
  // Optional override set of examIds to consider — used by the solver when only checking a subset.
  restrictToExamIds?: Set<string>;
}

function makeId(...parts: (string | number)[]): string {
  return parts.join(':');
}

function criticalConflict(
  kind: Conflict['kind'],
  title: string,
  description: string,
  ids: Partial<Record<'exams' | 'rooms' | 'slots' | 'invigilators' | 'groups', string[]>>,
  suggestedFix?: string
): Conflict {
  return {
    id: makeId(kind, ...Object.values(ids).flat()),
    kind,
    severity: 'critical' as ConflictSeverity,
    title,
    description,
    examIds: ids.exams ?? [],
    roomIds: ids.rooms ?? [],
    timeSlotIds: ids.slots ?? [],
    invigilatorIds: ids.invigilators ?? [],
    studentGroupIds: ids.groups ?? [],
    suggestedFix,
  };
}

function warningConflict(
  kind: Conflict['kind'],
  title: string,
  description: string,
  ids: Partial<Record<'exams' | 'rooms' | 'slots' | 'invigilators' | 'groups', string[]>>,
  suggestedFix?: string
): Conflict {
  return {
    id: makeId(kind, ...Object.values(ids).flat()),
    kind,
    severity: 'warning',
    title,
    description,
    examIds: ids.exams ?? [],
    roomIds: ids.rooms ?? [],
    timeSlotIds: ids.slots ?? [],
    invigilatorIds: ids.invigilators ?? [],
    studentGroupIds: ids.groups ?? [],
    suggestedFix,
  };
}

function infoConflict(
  kind: Conflict['kind'],
  title: string,
  description: string,
  ids: Partial<Record<'exams' | 'rooms' | 'slots' | 'invigilators' | 'groups', string[]>>,
  suggestedFix?: string
): Conflict {
  return {
    id: makeId(kind, ...Object.values(ids).flat()),
    kind,
    severity: 'info',
    title,
    description,
    examIds: ids.exams ?? [],
    roomIds: ids.rooms ?? [],
    timeSlotIds: ids.slots ?? [],
    invigilatorIds: ids.invigilators ?? [],
    studentGroupIds: ids.groups ?? [],
    suggestedFix,
  };
}

interface EnrichedAssignment extends AssignmentProposal {
  exam?: Exam;
  room?: Room;
  timeSlot?: TimeSlot;
  studentGroup?: StudentGroup;
}

function enrich(
  assignments: AssignmentProposal[],
  ctx: ConflictContext
): EnrichedAssignment[] {
  const examMap = new Map(ctx.exams.map((e) => [e.id, e]));
  const roomMap = new Map(ctx.rooms.map((r) => [r.id, r]));
  const slotMap = new Map(ctx.timeSlots.map((t) => [t.id, t]));
  const groupMap = new Map(ctx.studentGroups.map((g) => [g.id, g]));
  return assignments.map((a) => ({
    ...a,
    exam: examMap.get(a.examId),
    room: roomMap.get(a.roomId),
    timeSlot: slotMap.get(a.timeSlotId),
    studentGroup: examMap.get(a.examId)?.studentGroup ?? (examMap.get(a.examId) ? groupMap.get(examMap.get(a.examId)!.studentGroupId) : undefined),
  }));
}

export function detectConflicts(input: DetectConflictsInput): Conflict[] {
  const { assignments, context, restrictToExamIds } = input;
  const conflicts: Conflict[] = [];
  const enriched = enrich(assignments, context).filter(
    (a) => !restrictToExamIds || restrictToExamIds.has(a.examId)
  );

  // 6. Invalid or incomplete exam assignments — check first, because they short-circuit other checks
  for (const a of enriched) {
    if (!a.exam) {
      conflicts.push(
        criticalConflict(
          'incomplete_assignment',
          'Unknown exam referenced',
          `Assignment references exam ${a.examId} which does not exist.`,
          { exams: [a.examId] },
          'Remove or fix the orphaned assignment.'
        )
      );
      continue;
    }
    if (!a.room) {
      conflicts.push(
        criticalConflict(
          'incomplete_assignment',
          'Unknown room referenced',
          `Exam "${a.exam.name}" references room ${a.roomId} which does not exist.`,
          { exams: [a.examId], rooms: [a.roomId] },
          'Assign a valid room.'
        )
      );
      continue;
    }
    if (!a.timeSlot) {
      conflicts.push(
        criticalConflict(
          'incomplete_assignment',
          'Unknown time slot referenced',
          `Exam "${a.exam.name}" references time slot ${a.timeSlotId} which does not exist.`,
          { exams: [a.examId], slots: [a.timeSlotId] },
          'Assign a valid time slot.'
        )
      );
      continue;
    }
    if (!a.invigilatorIds || a.invigilatorIds.length === 0) {
      conflicts.push(
        warningConflict(
          'incomplete_assignment',
          'No invigilator assigned',
          `Exam "${a.exam.name}" has no invigilators assigned.`,
          { exams: [a.examId] },
          'Assign at least one invigilator.'
        )
      );
    }
  }

  // 5. Unavailable resources
  for (const a of enriched) {
    if (!a.exam || !a.room || !a.timeSlot) continue;
    if (!a.room.isAvailable) {
      conflicts.push(
        criticalConflict(
          'unavailable_resource',
          'Unavailable room used',
          `Room "${a.room.name}" is marked unavailable but is assigned to "${a.exam.name}".`,
          { exams: [a.examId], rooms: [a.roomId] },
          'Mark the room available or move the exam to another room.'
        )
      );
    }
    if (!a.timeSlot.isAvailable) {
      conflicts.push(
        criticalConflict(
          'unavailable_resource',
          'Unavailable time slot used',
          `Time slot ${a.timeSlot.date} ${a.timeSlot.startTime}–${a.timeSlot.endTime} is marked unavailable but is used by "${a.exam.name}".`,
          { exams: [a.examId], slots: [a.timeSlotId] },
          'Reopen the slot or move the exam.'
        )
      );
    }
    const invigilatorMap = new Map(context.invigilators.map((i) => [i.id, i]));
    for (const invId of a.invigilatorIds ?? []) {
      const inv = invigilatorMap.get(invId);
      if (!inv) {
        conflicts.push(
          criticalConflict(
            'incomplete_assignment',
            'Unknown invigilator',
            `Exam "${a.exam.name}" references invigilator ${invId} which does not exist.`,
            { exams: [a.examId], invigilators: [invId] },
            'Remove or fix the invigilator reference.'
          )
        );
        continue;
      }
      if (!inv.isAvailable) {
        conflicts.push(
          criticalConflict(
            'unavailable_resource',
            'Unavailable invigilator used',
            `Invigilator "${inv.name}" is marked unavailable but is assigned to "${a.exam.name}".`,
            { exams: [a.examId], invigilators: [invId] },
            'Mark the invigilator available or reassign.'
          )
        );
      }
      const availability = parseStringArray(inv.availability);
      if (availability.length > 0 && !availability.includes(a.timeSlotId)) {
        conflicts.push(
          warningConflict(
            'unavailable_resource',
            'Invigilator not available for slot',
            `Invigilator "${inv.name}" is not in the availability list for ${a.timeSlot.date} ${a.timeSlot.startTime}.`,
            { exams: [a.examId], invigilators: [invId], slots: [a.timeSlotId] },
            'Pick a slot the invigilator is available for.'
          )
        );
      }
    }
  }

  // 3. Room capacity violations
  for (const a of enriched) {
    if (!a.exam || !a.room) continue;
    if (a.exam.enrollmentCount > a.room.capacity) {
      conflicts.push(
        criticalConflict(
          'room_capacity_exceeded',
          'Room capacity exceeded',
          `"${a.exam.name}" has ${a.exam.enrollmentCount} students but room "${a.room.name}" fits ${a.room.capacity}.`,
          { exams: [a.examId], rooms: [a.roomId] },
          'Move the exam to a larger room.'
        )
      );
    }
  }

  // 1. Two exams in the same room at overlapping times
  for (let i = 0; i < enriched.length; i++) {
    for (let j = i + 1; j < enriched.length; j++) {
      const a = enriched[i];
      const b = enriched[j];
      if (!a.room || !b.room || !a.timeSlot || !b.timeSlot) continue;
      if (a.roomId !== b.roomId) continue;
      if (slotsOverlapOnSameDate(
        { date: a.timeSlot.date, start: parseTime(a.timeSlot.startTime), end: parseTime(a.timeSlot.endTime) },
        { date: b.timeSlot.date, start: parseTime(b.timeSlot.startTime), end: parseTime(b.timeSlot.endTime) }
      )) {
        conflicts.push(
          criticalConflict(
            'room_double_booking',
            'Room double-booked',
            `Room "${a.room.name}" is assigned to both "${a.exam?.name}" and "${b.exam?.name}" at overlapping times on ${a.timeSlot.date}.`,
            { exams: [a.examId, b.examId], rooms: [a.roomId], slots: [a.timeSlotId, b.timeSlotId] },
            'Move one of the exams to another room or time slot.'
          )
        );
      }
    }
  }

  // 2. Same student group with overlapping times
  for (let i = 0; i < enriched.length; i++) {
    for (let j = i + 1; j < enriched.length; j++) {
      const a = enriched[i];
      const b = enriched[j];
      if (!a.exam || !b.exam) continue;
      if (a.exam.studentGroupId !== b.exam.studentGroupId) continue;
      if (!a.timeSlot || !b.timeSlot) continue;
      if (slotsOverlapOnSameDate(
        { date: a.timeSlot.date, start: parseTime(a.timeSlot.startTime), end: parseTime(a.timeSlot.endTime) },
        { date: b.timeSlot.date, start: parseTime(b.timeSlot.startTime), end: parseTime(b.timeSlot.endTime) }
      )) {
        conflicts.push(
          criticalConflict(
            'student_group_overlap',
            'Student group conflict',
            `Student group "${a.studentGroup?.name ?? a.exam.studentGroupId}" has two overlapping exams: "${a.exam.name}" and "${b.exam.name}" on ${a.timeSlot.date}.`,
            { exams: [a.examId, b.examId], groups: [a.exam.studentGroupId], slots: [a.timeSlotId, b.timeSlotId] },
            'Move one of the exams to a different time.'
          )
        );
      }
    }
  }

  // 4. Invigilator double-booking
  const invigilatorToAssignments = new Map<string, EnrichedAssignment[]>();
  for (const a of enriched) {
    for (const invId of a.invigilatorIds ?? []) {
      if (!invigilatorToAssignments.has(invId)) invigilatorToAssignments.set(invId, []);
      invigilatorToAssignments.get(invId)!.push(a);
    }
  }
  for (const [invId, list] of invigilatorToAssignments.entries()) {
    const inv = context.invigilators.find((i) => i.id === invId);
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const a = list[i];
        const b = list[j];
        if (!a.timeSlot || !b.timeSlot) continue;
        if (slotsOverlapOnSameDate(
          { date: a.timeSlot.date, start: parseTime(a.timeSlot.startTime), end: parseTime(a.timeSlot.endTime) },
          { date: b.timeSlot.date, start: parseTime(b.timeSlot.startTime), end: parseTime(b.timeSlot.endTime) }
        )) {
          conflicts.push(
            criticalConflict(
              'invigilator_double_booking',
              'Invigilator double-booked',
              `Invigilator "${inv?.name ?? invId}" is assigned to both "${a.exam?.name}" and "${b.exam?.name}" at overlapping times on ${a.timeSlot.date}.`,
              { exams: [a.examId, b.examId], invigilators: [invId], slots: [a.timeSlotId, b.timeSlotId] },
              'Reassign one of the invigilator slots.'
            )
          );
        }
      }
    }
    // Workload check (per day count)
    if (inv) {
      const byDate = new Map<string, number>();
      for (const a of list) {
        if (!a.timeSlot) continue;
        byDate.set(a.timeSlot.date, (byDate.get(a.timeSlot.date) ?? 0) + 1);
      }
      for (const [date, count] of byDate.entries()) {
        if (count > inv.maxWorkload) {
          conflicts.push(
            warningConflict(
              'invigilator_double_booking',
              'Invigilator workload exceeded',
              `Invigilator "${inv.name}" has ${count} assignments on ${date}, exceeding max workload of ${inv.maxWorkload}.`,
              { invigilators: [invId] },
              'Redistribute invigilator assignments.'
            )
          );
        }
      }
    }
  }

  // 7. Fairness: back-to-back exams & excessive daily load per student group
  const groupAssignments = new Map<string, EnrichedAssignment[]>();
  for (const a of enriched) {
    if (!a.exam || !a.timeSlot) continue;
    if (!groupAssignments.has(a.exam.studentGroupId)) {
      groupAssignments.set(a.exam.studentGroupId, []);
    }
    groupAssignments.get(a.exam.studentGroupId)!.push(a);
  }
  for (const [groupId, list] of groupAssignments) {
    const group = context.studentGroups.find((g) => g.id === groupId);
    const byDate = new Map<string, EnrichedAssignment[]>();
    for (const a of list) {
      if (!a.timeSlot) continue;
      if (!byDate.has(a.timeSlot.date)) byDate.set(a.timeSlot.date, []);
      byDate.get(a.timeSlot.date)!.push(a);
    }
    for (const [date, dayExams] of byDate) {
      if (dayExams.length > 2) {
        // Excessive daily load
        conflicts.push(
          warningConflict(
            'student_group_overlap',
            'Excessive daily exam load',
            `Student group "${group?.name ?? groupId}" has ${dayExams.length} exams on ${date}. Consider spreading across days.`,
            { exams: dayExams.map((e) => e.examId), groups: [groupId], slots: dayExams.map((e) => e.timeSlotId!) },
            'Move some exams to other days.'
          )
        );
      }
      // Check for back-to-back (gap < 30 min)
      const sorted = [...dayExams].sort((a, b) =>
        parseTime(a.timeSlot!.startTime) - parseTime(b.timeSlot!.startTime)
      );
      for (let i = 0; i < sorted.length - 1; i++) {
        const a = sorted[i];
        const b = sorted[i + 1];
        if (!a.timeSlot || !b.timeSlot) continue;
        const aEnd = parseTime(a.timeSlot.endTime);
        const bStart = parseTime(b.timeSlot.startTime);
        const gap = bStart - aEnd;
        if (gap > 0 && gap < 30) {
          conflicts.push(
            warningConflict(
              'student_group_overlap',
              'Back-to-back exams',
              `Student group "${group?.name ?? groupId}" has "${a.exam?.name}" ending at ${a.timeSlot.endTime} and "${b.exam?.name}" starting at ${b.timeSlot.startTime} on ${date} (only ${gap}min gap).`,
              { exams: [a.examId, b.examId], groups: [groupId], slots: [a.timeSlotId, b.timeSlotId] },
              'Allow at least 30 minutes between exams for the same group.'
            )
          );
        }
      }
    }
  }

  // 8. Fairness: invigilator consecutive assignment fatigue
  const invByDate = new Map<string, Map<string, EnrichedAssignment[]>>(); // invId -> date -> list
  for (const a of enriched) {
    if (!a.timeSlot) continue;
    for (const invId of a.invigilatorIds ?? []) {
      if (!invByDate.has(invId)) invByDate.set(invId, new Map());
      const m = invByDate.get(invId)!;
      if (!m.has(a.timeSlot.date)) m.set(a.timeSlot.date, []);
      m.get(a.timeSlot.date)!.push(a);
    }
  }
  for (const [invId, byDate] of invByDate) {
    const inv = context.invigilators.find((i) => i.id === invId);
    for (const [date, list] of byDate) {
      if (list.length >= 3) {
        conflicts.push(
          warningConflict(
            'invigilator_double_booking',
            'Invigilator fatigue risk',
            `Invigilator "${inv?.name ?? invId}" has ${list.length} assignments on ${date}. Consider distributing the load.`,
            { invigilators: [invId] },
            'Reassign some exams to other invigilators.'
          )
        );
      }
    }
  }

  // Deduplicate by id (some checks may overlap)
  const seen = new Set<string>();
  const deduped: Conflict[] = [];
  for (const c of conflicts) {
    if (!seen.has(c.id)) {
      seen.add(c.id);
      deduped.push(c);
    }
  }
  return deduped;
}

function parseTime(t: string): number {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}

// True if the assignment set is feasible (no critical conflicts).
export function isFeasible(conflicts: Conflict[]): boolean {
  return !conflicts.some((c) => c.severity === 'critical');
}

// Severity counts for UI display
export function countBySeverity(conflicts: Conflict[]): Record<ConflictSeverity, number> {
  const counts: Record<ConflictSeverity, number> = { critical: 0, warning: 0, info: 0 };
  for (const c of conflicts) counts[c.severity]++;
  return counts;
}

// Parse a Prisma Exam row into the rich Exam shape (with arrays)
export function examFromRow(row: {
  preferredSlots: string;
  preferredRooms: string;
  [k: string]: unknown;
}): { preferredSlots: string[]; preferredRooms: string[] } {
  return {
    preferredSlots: parseStringArray(row.preferredSlots),
    preferredRooms: parseStringArray(row.preferredRooms),
  };
}

// Parse any JSON-encoded field safely
export function safeParse<T>(value: string | null | undefined, fallback: T): T {
  return parseJSON(value, fallback);
}
