// RippleMind — shared domain types
// These mirror the Prisma models but are safe to use on both client and server.

export type ExamType = 'final' | 'midterm' | 'quiz' | 'makeup';
export type ExamStatus = 'unscheduled' | 'scheduled';
export type ScenarioStatus = 'draft' | 'analyzed' | 'approved' | 'discarded';
export type ConflictSeverity = 'critical' | 'warning' | 'info';
export type ConflictKind =
  | 'room_double_booking'
  | 'student_group_overlap'
  | 'room_capacity_exceeded'
  | 'invigilator_double_booking'
  | 'unavailable_resource'
  | 'incomplete_assignment';

export interface StudentGroup {
  id: string;
  name: string;
  code: string;
  studentCount: number;
  program?: string | null;
  year?: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface Room {
  id: string;
  name: string;
  code: string;
  capacity: number;
  location?: string | null;
  building?: string | null;
  floor?: number | null;
  features: string[];
  isAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TimeSlot {
  id: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  label?: string | null;
  dayOfWeek?: number | null;
  isAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Invigilator {
  id: string;
  name: string;
  email?: string | null;
  department?: string | null;
  maxWorkload: number;
  availability: string[]; // slot ids
  isAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Exam {
  id: string;
  name: string;
  subjectCode: string;
  duration: number; // minutes
  studentGroupId: string;
  enrollmentCount: number;
  examType: ExamType;
  notes?: string | null;
  status: ExamStatus;
  preferredSlots: string[];
  preferredRooms: string[];
  createdAt: string;
  updatedAt: string;
  studentGroup?: StudentGroup;
  assignment?: ExamAssignment | null;
}

export interface ExamAssignment {
  id: string;
  examId: string;
  timeSlotId: string;
  roomId: string;
  date: string;
  invigilatorIds: string[];
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
  exam?: Exam;
  timeSlot?: TimeSlot;
  room?: Room;
}

export interface Conflict {
  id: string;
  kind: ConflictKind;
  severity: ConflictSeverity;
  title: string;
  description: string;
  examIds: string[];
  roomIds: string[];
  timeSlotIds: string[];
  invigilatorIds: string[];
  studentGroupIds: string[];
  suggestedFix?: string;
}

export interface SolverObjectiveWeights {
  minimizeChangedExams: number;
  minimizeRoomChanges: number;
  minimizeCapacityWaste: number;
  respectPreferredSlots: number;
  balanceInvigilatorWorkload: number;
}

export interface SolverConfig {
  timeLimitMs: number;
  maxAlternatives: number;
  objectiveWeights: SolverObjectiveWeights;
  // Optional baseline assignment (examId -> assignment) used for minimal-change optimization.
  baseline?: Record<string, AssignmentProposal>;
}

export interface AssignmentProposal {
  examId: string;
  timeSlotId: string;
  roomId: string;
  invigilatorIds: string[];
}

export interface SolverSolution {
  feasible: boolean;
  provenInfeasible: boolean;
  timedOut: boolean;
  assignments: AssignmentProposal[];
  unscheduled: { examId: string; reason: string }[];
  conflicts: Conflict[];
  metrics: {
    scheduledExams: number;
    totalExams: number;
    roomUtilization: number;
    avgInvigilatorLoad: number;
    maxInvigilatorLoad: number;
    capacityWaste: number;
    preferenceScore: number;
    changedExamsFromBaseline?: number;
    roomChangesFromBaseline?: number;
    searchNodes: number;
    elapsedMs: number;
    objectiveValue?: number;
  };
  alternatives?: SolverSolution[];
}

export interface Scenario {
  id: string;
  name: string;
  description?: string | null;
  status: ScenarioStatus;
  initiatorExamId?: string | null;
  changeSummary: ScenarioChangeSummary;
  originalState: AssignmentProposal[];
  proposedState: AssignmentProposal[];
  conflictReport: Conflict[];
  solverMetrics: SolverSolution['metrics'];
  isFeasible: boolean | null;
  alternatives: SolverSolution[];
  createdAt: string;
  updatedAt: string;
  appliedAt?: string | null;
}

export interface ScenarioChangeSummary {
  kind: 'move' | 'duration' | 'room' | 'invigilator' | 'mixed';
  examId: string;
  from?: Partial<AssignmentProposal>;
  to?: Partial<AssignmentProposal>;
  description: string;
}

export interface AuditLog {
  id: string;
  actorId?: string | null;
  actorName?: string | null;
  action: string;
  category: string;
  target?: string | null;
  summary: string;
  details: Record<string, unknown>;
  createdAt: string;
  scenarioId?: string | null;
}

export interface DashboardMetrics {
  totalExams: number;
  totalStudentGroups: number;
  availableRooms: number;
  availableInvigilators: number;
  scheduledExams: number;
  unscheduledExams: number;
  detectedConflicts: number;
  roomUtilization: number;
  avgInvigilatorLoad: number;
  upcomingExaminations: Array<{
    id: string;
    name: string;
    subjectCode: string;
    date: string;
    startTime: string;
    endTime: string;
    roomName: string;
    studentGroupName: string;
  }>;
  conflictsBySeverity: { severity: ConflictSeverity; count: number }[];
  examsByType: { type: string; count: number }[];
  roomUtilizationByRoom: { roomId: string; roomName: string; utilization: number; assignments: number }[];
}

export interface RippleNode {
  id: string;
  type: 'exam' | 'room' | 'timeslot' | 'invigilator' | 'studentgroup';
  label: string;
  sublabel?: string;
  changed?: boolean;
  affected?: boolean;
}

export interface RippleEdge {
  id: string;
  source: string;
  target: string;
  label: string;
  kind: 'uses' | 'conflicts' | 'moves' | 'affects';
}

export interface RippleGraph {
  nodes: RippleNode[];
  edges: RippleEdge[];
}
