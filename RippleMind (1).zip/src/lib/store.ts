// Navigation store — Zustand store for client-side view routing.
// Since only `/` is user-visible in this environment, we use state-based navigation.

import { create } from 'zustand';

export type PageKey =
  | 'dashboard'
  | 'exams'
  | 'student-groups'
  | 'rooms'
  | 'time-slots'
  | 'invigilators'
  | 'generate-timetable'
  | 'timetable-viewer'
  | 'conflict-reports'
  | 'student-portal'
  | 'emergency-simulation'
  | 'settings'
  | 'what-if-simulation'
  | 'ripple-analysis'
  | 'alternative-comparison'
  | 'ai-assistant'
  | 'scenario-history'
  | 'analytics';

interface NavState {
  currentPage: PageKey;
  pageParams: Record<string, string>;
  navigate: (page: PageKey, params?: Record<string, string>) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

export const useNav = create<NavState>((set) => ({
  currentPage: 'dashboard',
  pageParams: {},
  navigate: (page, params = {}) => set({ currentPage: page, pageParams: params }),
  sidebarOpen: false,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}));

export const PAGE_TITLES: Record<PageKey, string> = {
  'dashboard': 'Dashboard',
  'exams': 'Exams Management',
  'student-groups': 'Student Groups',
  'rooms': 'Rooms Management',
  'time-slots': 'Time Slots',
  'invigilators': 'Invigilators',
  'generate-timetable': 'Generate Timetable',
  'timetable-viewer': 'Timetable Viewer',
  'conflict-reports': 'Conflict Reports',
  'student-portal': 'Student Portal',
  'emergency-simulation': 'Emergency Simulation',
  'settings': 'Settings',
  'what-if-simulation': 'What-if Simulation',
  'ripple-analysis': 'Ripple-effect Analysis',
  'alternative-comparison': 'Alternative Comparison',
  'ai-assistant': 'AI Assistant',
  'scenario-history': 'Scenario History',
  'analytics': 'Analytics & Reports',
};

export const PAGE_GROUPS: { label: string; pages: { key: PageKey; label: string; icon: string }[] }[] = [
  {
    label: 'Overview',
    pages: [
      { key: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
      { key: 'analytics', label: 'Analytics', icon: 'BarChart3' },
    ],
  },
  {
    label: 'Resources',
    pages: [
      { key: 'exams', label: 'Exams', icon: 'FileText' },
      { key: 'student-groups', label: 'Student Groups', icon: 'Users' },
      { key: 'rooms', label: 'Rooms', icon: 'DoorOpen' },
      { key: 'time-slots', label: 'Time Slots', icon: 'Clock' },
      { key: 'invigilators', label: 'Invigilators', icon: 'UserCheck' },
    ],
  },
  {
    label: 'Scheduling',
    pages: [
      { key: 'generate-timetable', label: 'Generate Timetable', icon: 'Wand2' },
      { key: 'timetable-viewer', label: 'Timetable Viewer', icon: 'Calendar' },
      { key: 'conflict-reports', label: 'Conflict Reports', icon: 'AlertTriangle' },
      { key: 'emergency-simulation', label: 'Emergency Simulation', icon: 'Siren' },
      { key: 'student-portal', label: 'Student Portal', icon: 'GraduationCap' },
    ],
  },
  {
    label: 'Simulation',
    pages: [
      { key: 'what-if-simulation', label: 'What-if Simulation', icon: 'FlaskConical' },
      { key: 'ripple-analysis', label: 'Ripple Analysis', icon: 'Share2' },
      { key: 'alternative-comparison', label: 'Alternatives', icon: 'GitCompare' },
      { key: 'ai-assistant', label: 'AI Assistant', icon: 'Sparkles' },
      { key: 'scenario-history', label: 'Scenario History', icon: 'History' },
    ],
  },
  {
    label: 'System',
    pages: [
      { key: 'settings', label: 'Settings', icon: 'Settings' },
    ],
  },
];
