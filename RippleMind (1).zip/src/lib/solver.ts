// RippleMind CP Solver — v2 with improved logic.
//
// Improvements over v1:
//   - Dynamic MRV: recompute exam ordering at each search step based on remaining
//     compatible candidates (not just static domain size).
//   - Forward-checking with actual domain pruning: when we assign an exam, we
//     remove incompatible candidates from other exams' domains. If any domain
//     becomes empty, we backtrack immediately.
//   - Fairness constraints: max 2 exams per day per student group, minimum gap
//     between exams for the same group.
//   - Better objective: spread exams across days, penalize uneven daily load.
//   - Smarter domain cap: keep all preferred candidates + a diverse sample.
//   - Better value ordering: LCV with conflict counting.
//
// The solver remains async with event-loop yields and reports infeasibility honestly.

import type {
  AssignmentProposal,
  Conflict,
  Exam,
  Invigilator,
  Room,
  SolverConfig,
  SolverSolution,
  StudentGroup,
  TimeSlot,
} from './types';
import { detectConflicts, isFeasible, type ConflictContext } from './conflicts';
import { parseTimeToMinutes, slotsOverlapOnSameDate } from './time';

export interface SolverInput {
  exams: Exam[];
  rooms: Room[];
  timeSlots: TimeSlot[];
  invigilators: Invigilator[];
  studentGroups: StudentGroup[];
  config: SolverConfig;
  fixedAssignments?: AssignmentProposal[];
  stopOnFirstFeasible?: boolean;
  maxNodes?: number;
  // Fairness configuration
  maxExamsPerDayPerGroup?: number; // default 2
  minGapMinutesBetweenExams?: number; // default 60
}

interface DomainEntry {
  slotId: string;
  roomId: string;
  invigilatorIds: string[];
  // Cached scoring for sorting (higher = better)
  score: number;
}

interface SolverState {
  assignments: Map<string, AssignmentProposal>;
  // Working copy of domains — pruned during search
  workingDomains: Map<string, DomainEntry[]>;
  // Original domains (for restoration on backtrack)
  originalDomains: Map<string, DomainEntry[]>;
  searchNodes: number;
  startTime: number;
  deadline: number;
  maxNodes: number;
  bestSolution: AssignmentProposal[] | null;
  bestObjective: number;
  solutionsFound: number;
  timedOut: boolean;
  stopOnFirstFeasible: boolean;
  config: SolverConfig;
  context: ConflictContext;
  // Fairness
  maxExamsPerDayPerGroup: number;
  minGapMinutes: number;
  // Track daily load per group for fast fairness checks
  groupDailyLoad: Map<string, Map<string, number>>; // groupId -> date -> count
}

const INFEASIBLE_OBJECTIVE = Number.POSITIVE_INFINITY;
const YIELD_INTERVAL = 150;

function pickInvigilators(
  slotId: string,
  invigilators: Invigilator[],
  required: number
): string[] {
  const available = invigilators.filter((i) => {
    if (!i.isAvailable) return false;
    const avail = i.availability ?? [];
    return avail.length === 0 || avail.includes(slotId);
  });
  if (available.length < required) {
    const all = invigilators.filter((i) => i.isAvailable);
    return all.slice(0, required).map((i) => i.id);
  }
  return available.slice(0, required).map((i) => i.id);
}

// Score a domain entry — higher is better (preferred slots/rooms, tight capacity fit)
function scoreDomainEntry(
  entry: { slotId: string; roomId: string },
  exam: Exam,
  rooms: Room[],
  timeSlots: TimeSlot[]
): number {
  let score = 0;
  if (exam.preferredSlots.includes(entry.slotId)) score += 100;
  if (exam.preferredRooms.includes(entry.roomId)) score += 50;
  const room = rooms.find((r) => r.id === entry.roomId);
  if (room) {
    // Prefer tight capacity fit (less waste) but not too tight
    const waste = room.capacity - exam.enrollmentCount;
    if (waste >= 0) {
      // Sweet spot: 10-30 seats extra
      if (waste <= 30) score += 20;
      else if (waste <= 60) score += 10;
      else score += Math.max(0, 5 - Math.floor(waste / 30));
    }
  }
  return score;
}

function buildDomains(input: SolverInput): Map<string, DomainEntry[]> {
  const { exams, rooms, timeSlots, invigilators } = input;
  const domains = new Map<string, DomainEntry[]>();
  // Adaptive cap: keep enough candidates for diversity without exploding memory
  const MAX_DOMAIN = Math.min(80, Math.max(30, rooms.length * timeSlots.length));

  for (const exam of exams) {
    const list: DomainEntry[] = [];
    let validRooms = rooms.filter((r) => r.isAvailable && r.capacity >= exam.enrollmentCount);
    if (validRooms.length === 0) {
      // Fallback: use any available room (solver will report capacity conflict)
      validRooms = rooms.filter((r) => r.isAvailable);
    }
    const validSlots = timeSlots.filter((t) => t.isAvailable);

    for (const r of validRooms) {
      for (const slot of validSlots) {
        const invs = pickInvigilators(slot.id, invigilators, 1);
        const score = scoreDomainEntry({ slotId: slot.id, roomId: r.id }, exam, rooms, timeSlots);
        list.push({ slotId: slot.id, roomId: r.id, invigilatorIds: invs, score });
      }
    }

    // Sort by score descending (best candidates first)
    list.sort((a, b) => b.score - a.score);

    // Keep top candidates but ensure slot diversity (don't keep all from one slot)
    const kept: DomainEntry[] = [];
    const slotsUsed = new Map<string, number>(); // slotId -> count kept
    const MAX_PER_SLOT = 4; // keep at most 4 rooms per slot
    for (const entry of list) {
      const count = slotsUsed.get(entry.slotId) ?? 0;
      if (count < MAX_PER_SLOT) {
        kept.push(entry);
        slotsUsed.set(entry.slotId, count + 1);
      }
      if (kept.length >= MAX_DOMAIN) break;
    }
    domains.set(exam.id, kept);
  }
  return domains;
}

// Deep-check candidate compatibility with current assignments.
// Includes fairness constraints (max exams per day per group, min gap).
function isCompatibleV2(
  candidate: AssignmentProposal,
  current: Map<string, AssignmentProposal>,
  context: ConflictContext,
  maxExamsPerDayPerGroup: number,
  minGapMinutes: number,
  groupDailyLoad: Map<string, Map<string, number>>
): boolean {
  const exam = context.exams.find((e) => e.id === candidate.examId);
  if (!exam) return false;
  const room = context.rooms.find((r) => r.id === candidate.roomId);
  const slot = context.timeSlots.find((t) => t.id === candidate.timeSlotId);
  if (!room || !slot) return false;
  if (!room.isAvailable || !slot.isAvailable) return false;
  if (room.capacity < exam.enrollmentCount) return false;

  // Fairness: check daily load for this group
  const todayLoad = groupDailyLoad.get(exam.studentGroupId)?.get(slot.date) ?? 0;
  if (todayLoad >= maxExamsPerDayPerGroup) return false;

  const candStart = parseTimeToMinutes(slot.startTime);
  const candEnd = parseTimeToMinutes(slot.endTime);

  for (const [, existing] of current) {
    if (existing.examId === candidate.examId) continue;
    const exExam = context.exams.find((e) => e.id === existing.examId);
    const exRoom = context.rooms.find((r) => r.id === existing.roomId);
    const exSlot = context.timeSlots.find((t) => t.id === existing.timeSlotId);
    if (!exExam || !exRoom || !exSlot) continue;

    const exStart = parseTimeToMinutes(exSlot.startTime);
    const exEnd = parseTimeToMinutes(exSlot.endTime);
    const sameDate = exSlot.date === slot.date;
    const overlap = sameDate && candStart < exEnd && exStart < candEnd;

    // Hard: room double-booking
    if (existing.roomId === candidate.roomId && overlap) return false;
    // Hard: student group overlap
    if (exExam.studentGroupId === exam.studentGroupId && overlap) return false;
    // Hard: invigilator double-booking
    const sharedInv = (existing.invigilatorIds ?? []).filter((id) =>
      (candidate.invigilatorIds ?? []).includes(id)
    );
    if (sharedInv.length > 0 && overlap) return false;

    // Fairness: minimum gap between exams for the same student group
    if (exExam.studentGroupId === exam.studentGroupId && sameDate && !overlap) {
      const gap = candStart >= exEnd ? candStart - exEnd : exStart - candEnd;
      if (gap < minGapMinutes) return false;
    }
  }
  return true;
}

function computeObjective(
  assignments: AssignmentProposal[],
  state: SolverState
): number {
  const w = state.config.objectiveWeights;
  let objective = 0;

  // 1. Capacity waste
  let capacityWaste = 0;
  for (const a of assignments) {
    const exam = state.context.exams.find((e) => e.id === a.examId);
    const room = state.context.rooms.find((r) => r.id === a.roomId);
    if (exam && room) {
      capacityWaste += Math.max(0, room.capacity - exam.enrollmentCount);
    }
  }
  objective += w.minimizeCapacityWaste * capacityWaste;

  // 2. Preference misses
  let preferenceMisses = 0;
  for (const a of assignments) {
    const exam = state.context.exams.find((e) => e.id === a.examId);
    if (!exam) continue;
    if (exam.preferredSlots.length && !exam.preferredSlots.includes(a.timeSlotId)) preferenceMisses++;
    if (exam.preferredRooms.length && !exam.preferredRooms.includes(a.roomId)) preferenceMisses++;
  }
  objective += w.respectPreferredSlots * preferenceMisses;

  // 3. Invigilator workload balance (penalize max load AND variance)
  const loadByInv = new Map<string, number>();
  for (const a of assignments) {
    for (const inv of a.invigilatorIds ?? []) {
      loadByInv.set(inv, (loadByInv.get(inv) ?? 0) + 1);
    }
  }
  const loads = Array.from(loadByInv.values());
  const maxLoad = loads.length ? Math.max(...loads) : 0;
  const avgLoad = loads.length ? loads.reduce((s, v) => s + v, 0) / loads.length : 0;
  const variance = loads.length ? loads.reduce((s, v) => s + (v - avgLoad) ** 2, 0) / loads.length : 0;
  objective += w.balanceInvigilatorWorkload * (maxLoad + variance * 0.5);

  // 4. Minimal change vs baseline
  if (state.config.baseline) {
    let changed = 0;
    let roomChanges = 0;
    for (const a of assignments) {
      const base = state.config.baseline[a.examId];
      if (!base) continue;
      if (base.timeSlotId !== a.timeSlotId || base.roomId !== a.roomId) changed++;
      if (base.roomId !== a.roomId) roomChanges++;
    }
    objective += w.minimizeChangedExams * changed;
    objective += w.minimizeRoomChanges * roomChanges;
  }

  // 5. NEW: Spread exams across days (penalize uneven daily distribution per group)
  const groupDailyCount = new Map<string, Map<string, number>>();
  for (const a of assignments) {
    const exam = state.context.exams.find((e) => e.id === a.examId);
    const slot = state.context.timeSlots.find((t) => t.id === a.timeSlotId);
    if (!exam || !slot) continue;
    if (!groupDailyCount.has(exam.studentGroupId)) groupDailyCount.set(exam.studentGroupId, new Map());
    const m = groupDailyCount.get(exam.studentGroupId)!;
    m.set(slot.date, (m.get(slot.date) ?? 0) + 1);
  }
  for (const m of groupDailyCount.values()) {
    const counts = Array.from(m.values());
    if (counts.length > 1) {
      const max = Math.max(...counts);
      // Penalize having multiple exams on the same day for a group
      objective += (max - 1) * 3;
    }
  }

  return objective;
}

// Dynamic MRV: pick the next exam to assign based on current remaining candidates.
function pickNextExam(state: SolverState): string | null {
  let bestId: string | null = null;
  let bestSize = Infinity;
  let bestConstraints = -1;

  for (const [examId, domain] of state.workingDomains) {
    if (state.assignments.has(examId)) continue;
    // Count currently compatible candidates
    let compatible = 0;
    let constraints = 0;
    const exam = state.context.exams.find((e) => e.id === examId);
    if (exam) {
      // Count how many other exams share the same group (more constraints = higher priority)
      for (const other of state.context.exams) {
        if (other.id !== examId && other.studentGroupId === exam.studentGroupId && !state.assignments.has(other.id)) {
          constraints++;
        }
      }
    }
    for (const cand of domain) {
      const proposal: AssignmentProposal = {
        examId,
        timeSlotId: cand.slotId,
        roomId: cand.roomId,
        invigilatorIds: cand.invigilatorIds,
      };
      if (isCompatibleV2(proposal, state.assignments, state.context, state.maxExamsPerDayPerGroup, state.minGapMinutes, state.groupDailyLoad)) {
        compatible++;
        if (compatible >= 20) break; // cap for performance
      }
    }
    // MRV: smallest domain first; tie-break by most constraints (most constrained first)
    if (compatible < bestSize || (compatible === bestSize && constraints > bestConstraints)) {
      bestSize = compatible;
      bestConstraints = constraints;
      bestId = examId;
    }
    if (bestSize === 0) break; // can't get worse than 0
  }
  return bestId;
}

// Update the group daily load map when assigning/unassigning
function updateDailyLoad(state: SolverState, proposal: AssignmentProposal, delta: number) {
  const exam = state.context.exams.find((e) => e.id === proposal.examId);
  const slot = state.context.timeSlots.find((t) => t.id === proposal.timeSlotId);
  if (!exam || !slot) return;
  if (!state.groupDailyLoad.has(exam.studentGroupId)) {
    state.groupDailyLoad.set(exam.studentGroupId, new Map());
  }
  const m = state.groupDailyLoad.get(exam.studentGroupId)!;
  m.set(slot.date, (m.get(slot.date) ?? 0) + delta);
}

// Async search with forward checking
async function search(state: SolverState, depth: number): Promise<void> {
  if (state.timedOut) return;
  state.searchNodes++;
  if (state.searchNodes >= state.maxNodes) {
    state.timedOut = true;
    return;
  }
  if (state.searchNodes % YIELD_INTERVAL === 0) {
    if (Date.now() > state.deadline) {
      state.timedOut = true;
      return;
    }
    await new Promise<void>((resolve) => setImmediate(resolve));
    if (state.timedOut) return;
  }

  // Check if all exams assigned
  if (state.assignments.size === state.context.exams.length) {
    const solution = Array.from(state.assignments.values());
    const obj = computeObjective(solution, state);
    state.solutionsFound++;
    if (obj < state.bestObjective) {
      state.bestObjective = obj;
      state.bestSolution = solution.map((a) => ({ ...a, invigilatorIds: [...a.invigilatorIds] }));
    }
    if (state.stopOnFirstFeasible) {
      state.timedOut = true; // signal stop
    }
    return;
  }

  // Dynamic MRV: pick next exam
  const examId = pickNextExam(state);
  if (!examId) return;

  const domain = state.workingDomains.get(examId) ?? [];
  const exam = state.context.exams.find((e) => e.id === examId);
  if (!exam) return;

  // Sort domain by score (LCV: try best candidates first)
  const sortedDomain = [...domain].sort((a, b) => b.score - a.score);

  let triedAny = false;
  for (const cand of sortedDomain) {
    if (state.timedOut) return;
    const proposal: AssignmentProposal = {
      examId,
      timeSlotId: cand.slotId,
      roomId: cand.roomId,
      invigilatorIds: [...cand.invigilatorIds],
    };
    if (!isCompatibleV2(proposal, state.assignments, state.context, state.maxExamsPerDayPerGroup, state.minGapMinutes, state.groupDailyLoad)) continue;
    triedAny = true;

    // Assign
    state.assignments.set(examId, proposal);
    updateDailyLoad(state, proposal, +1);

    // Forward check: verify all unassigned exams still have at least one compatible candidate
    let forwardCheckOk = true;
    if (state.searchNodes % 5 === 0) { // periodic forward check (every 5 nodes for performance)
      for (const [otherId, otherDomain] of state.workingDomains) {
        if (state.assignments.has(otherId) || otherId === examId) continue;
        let hasCandidate = false;
        for (const oc of otherDomain) {
          const op: AssignmentProposal = {
            examId: otherId,
            timeSlotId: oc.slotId,
            roomId: oc.roomId,
            invigilatorIds: oc.invigilatorIds,
          };
          if (isCompatibleV2(op, state.assignments, state.context, state.maxExamsPerDayPerGroup, state.minGapMinutes, state.groupDailyLoad)) {
            hasCandidate = true;
            break;
          }
        }
        if (!hasCandidate) {
          forwardCheckOk = false;
          break;
        }
      }
    }

    if (forwardCheckOk) {
      await search(state, depth + 1);
    }

    // Unassign (backtrack)
    state.assignments.delete(examId);
    updateDailyLoad(state, proposal, -1);

    if (state.timedOut && state.stopOnFirstFeasible && state.bestSolution) return;
    if (state.timedOut) return;
  }
}

function computeMetrics(
  solution: AssignmentProposal[] | null,
  state: SolverState,
  allExams: Exam[]
): SolverSolution['metrics'] {
  if (!solution) {
    return {
      scheduledExams: 0,
      totalExams: allExams.length,
      roomUtilization: 0,
      avgInvigilatorLoad: 0,
      maxInvigilatorLoad: 0,
      capacityWaste: 0,
      preferenceScore: 0,
      searchNodes: state.searchNodes,
      elapsedMs: Date.now() - state.startTime,
    };
  }
  const roomUsage = new Map<string, number>();
  const invLoad = new Map<string, number>();
  let capacityWaste = 0;
  let preferenceHits = 0;
  let preferenceTotal = 0;
  let changedExams = 0;
  let roomChanges = 0;

  for (const a of solution) {
    roomUsage.set(a.roomId, (roomUsage.get(a.roomId) ?? 0) + 1);
    for (const inv of a.invigilatorIds ?? []) {
      invLoad.set(inv, (invLoad.get(inv) ?? 0) + 1);
    }
    const exam = state.context.exams.find((e) => e.id === a.examId);
    const room = state.context.rooms.find((r) => r.id === a.roomId);
    if (exam && room) {
      capacityWaste += Math.max(0, room.capacity - exam.enrollmentCount);
    }
    if (exam) {
      if (exam.preferredSlots.length) {
        preferenceTotal++;
        if (exam.preferredSlots.includes(a.timeSlotId)) preferenceHits++;
      }
      if (exam.preferredRooms.length) {
        preferenceTotal++;
        if (exam.preferredRooms.includes(a.roomId)) preferenceHits++;
      }
    }
    if (state.config.baseline) {
      const base = state.config.baseline[a.examId];
      if (base) {
        if (base.timeSlotId !== a.timeSlotId || base.roomId !== a.roomId) changedExams++;
        if (base.roomId !== a.roomId) roomChanges++;
      }
    }
  }

  const totalRooms = state.context.rooms.length || 1;
  const utilization = (roomUsage.size / totalRooms) * 100;
  const loads = Array.from(invLoad.values());
  const maxLoad = loads.length ? Math.max(...loads) : 0;
  const avgLoad = loads.length ? loads.reduce((s, v) => s + v, 0) / loads.length : 0;
  const preferenceScore = preferenceTotal ? (preferenceHits / preferenceTotal) * 100 : 100;

  return {
    scheduledExams: solution.length,
    totalExams: allExams.length,
    roomUtilization: utilization,
    avgInvigilatorLoad: avgLoad,
    maxInvigilatorLoad: maxLoad,
    capacityWaste,
    preferenceScore,
    changedExamsFromBaseline: state.config.baseline ? changedExams : undefined,
    roomChangesFromBaseline: state.config.baseline ? roomChanges : undefined,
    searchNodes: state.searchNodes,
    elapsedMs: Date.now() - state.startTime,
    objectiveValue: state.bestObjective === INFEASIBLE_OBJECTIVE ? undefined : state.bestObjective,
  };
}

export async function solve(input: SolverInput): Promise<SolverSolution> {
  const { exams, config } = input;
  const context: ConflictContext = {
    exams,
    rooms: input.rooms,
    timeSlots: input.timeSlots,
    invigilators: input.invigilators,
    studentGroups: input.studentGroups,
  };
  const domains = buildDomains(input);

  // Proven infeasible: any exam has empty domain
  const infeasibleExams: { examId: string; reason: string }[] = [];
  for (const [examId, domain] of domains) {
    if (domain.length === 0) {
      const exam = exams.find((e) => e.id === examId);
      infeasibleExams.push({
        examId,
        reason: `No feasible (room × slot × invigilator) candidate exists for "${exam?.name ?? examId}". Check capacity, availability, and time slots.`,
      });
    }
  }
  if (infeasibleExams.length > 0) {
    return {
      feasible: false,
      provenInfeasible: true,
      timedOut: false,
      assignments: [],
      unscheduled: infeasibleExams,
      conflicts: [],
      metrics: {
        scheduledExams: 0,
        totalExams: exams.length,
        roomUtilization: 0,
        avgInvigilatorLoad: 0,
        maxInvigilatorLoad: 0,
        capacityWaste: 0,
        preferenceScore: 0,
        searchNodes: 0,
        elapsedMs: 0,
      },
    };
  }

  const state: SolverState = {
    assignments: new Map(),
    workingDomains: new Map(domains),
    originalDomains: new Map(domains),
    searchNodes: 0,
    startTime: Date.now(),
    deadline: Date.now() + config.timeLimitMs,
    maxNodes: input.maxNodes ?? 30000,
    bestSolution: null,
    bestObjective: INFEASIBLE_OBJECTIVE,
    solutionsFound: 0,
    timedOut: false,
    stopOnFirstFeasible: input.stopOnFirstFeasible ?? false,
    config,
    context,
    maxExamsPerDayPerGroup: input.maxExamsPerDayPerGroup ?? 2,
    minGapMinutes: input.minGapMinutesBetweenExams ?? 60,
    groupDailyLoad: new Map(),
  };

  // Seed fixed assignments
  if (input.fixedAssignments) {
    for (const a of input.fixedAssignments) {
      state.assignments.set(a.examId, a);
      updateDailyLoad(state, a, +1);
    }
  }

  await search(state, 0);

  const stoppedOnFirstFeasible = state.stopOnFirstFeasible && state.bestSolution !== null;
  const feasible = state.bestSolution !== null;
  const timedOut = state.timedOut && !stoppedOnFirstFeasible;
  const provenInfeasible = !feasible && !timedOut;

  const assignments = state.bestSolution ?? [];
  const conflicts: Conflict[] = feasible
    ? detectConflicts({ assignments, context })
    : [];

  const unscheduled = exams
    .filter((e) => !assignments.find((a) => a.examId === e.id))
    .map((e) => ({
      examId: e.id,
      reason: !feasible
        ? timedOut
          ? `Solver could not find a feasible assignment within the time/node limit. Try increasing the time limit or relaxing fairness constraints (max exams per day, min gap).`
          : `No feasible assignment exists given the current rooms, slots, and constraints. Check capacity, availability, and fairness limits.`
        : 'Exam was not scheduled by the solver.',
    }));

  return {
    feasible,
    provenInfeasible,
    timedOut,
    assignments,
    unscheduled,
    conflicts,
    metrics: computeMetrics(state.bestSolution, state, exams),
  };
}

export async function solveWithAlternatives(input: SolverInput): Promise<SolverSolution> {
  const baseSolution = await solve(input);
  if (!baseSolution.feasible) return baseSolution;

  const alternatives: SolverSolution[] = [baseSolution];
  const maxAlts = input.config.maxAlternatives;

  const profiles: Partial<SolverConfig['objectiveWeights']>[] = [
    { minimizeChangedExams: 100, minimizeRoomChanges: 10, minimizeCapacityWaste: 1, respectPreferredSlots: 5, balanceInvigilatorWorkload: 5 },
    { minimizeChangedExams: 5, minimizeRoomChanges: 100, minimizeCapacityWaste: 5, respectPreferredSlots: 5, balanceInvigilatorWorkload: 5 },
    { minimizeChangedExams: 5, minimizeRoomChanges: 5, minimizeCapacityWaste: 100, respectPreferredSlots: 5, balanceInvigilatorWorkload: 5 },
    { minimizeChangedExams: 5, minimizeRoomChanges: 5, minimizeCapacityWaste: 5, respectPreferredSlots: 100, balanceInvigilatorWorkload: 5 },
    { minimizeChangedExams: 5, minimizeRoomChanges: 5, minimizeCapacityWaste: 5, respectPreferredSlots: 5, balanceInvigilatorWorkload: 100 },
  ];

  for (let i = 0; i < Math.min(maxAlts - 1, profiles.length); i++) {
    const profile = profiles[i];
    const altInput: SolverInput = {
      ...input,
      config: {
        ...input.config,
        objectiveWeights: { ...input.config.objectiveWeights, ...profile },
        timeLimitMs: Math.max(2000, Math.floor(input.config.timeLimitMs / 2)),
      },
      maxNodes: input.maxNodes ?? 20000,
    };
    const alt = await solve(altInput);
    if (alt.feasible) {
      const isDuplicate = alternatives.some((existing) =>
        existing.assignments.length === alt.assignments.length &&
        existing.assignments.every((a) => {
          const match = alt.assignments.find((b) => b.examId === a.examId);
          return match && match.roomId === a.roomId && match.timeSlotId === a.timeSlotId;
        })
      );
      if (!isDuplicate) alternatives.push(alt);
    }
    if (alternatives.length >= maxAlts) break;
  }

  return { ...baseSolution, alternatives };
}

export function diffSolutions(
  baseline: AssignmentProposal[],
  proposed: AssignmentProposal[]
): {
  changed: { examId: string; from?: AssignmentProposal; to?: AssignmentProposal }[];
  added: AssignmentProposal[];
  removed: AssignmentProposal[];
} {
  const baseMap = new Map(baseline.map((a) => [a.examId, a]));
  const propMap = new Map(proposed.map((a) => [a.examId, a]));
  const changed: { examId: string; from?: AssignmentProposal; to?: AssignmentProposal }[] = [];
  const added: AssignmentProposal[] = [];
  const removed: AssignmentProposal[] = [];

  for (const [examId, to] of propMap) {
    const from = baseMap.get(examId);
    if (!from) {
      added.push(to);
    } else if (from.roomId !== to.roomId || from.timeSlotId !== to.timeSlotId ||
      JSON.stringify(from.invigilatorIds) !== JSON.stringify(to.invigilatorIds)) {
      changed.push({ examId, from, to });
    }
  }
  for (const [examId, from] of baseMap) {
    if (!propMap.has(examId)) removed.push(from);
  }
  return { changed, added, removed };
}

export { isFeasible };
