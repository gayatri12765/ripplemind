// RippleMind AI Assistant — uses the in-house z-ai-web-dev-sdk (GLM-4.6).
// The LLM is used ONLY for explanation and natural-language-to-proposal translation.
// Feasibility is ALWAYS determined by the CP solver, never by the LLM.

import ZAI from 'z-ai-web-dev-sdk';
import type {
  AssignmentProposal,
  Conflict,
  Exam,
  ExamAssignment,
  Invigilator,
  Room,
  Scenario,
  SolverSolution,
  StudentGroup,
  TimeSlot,
} from './types';

export interface AIContext {
  exams: Exam[];
  rooms: Room[];
  timeSlots: TimeSlot[];
  invigilators: Invigilator[];
  studentGroups: StudentGroup[];
  assignments: (ExamAssignment | AssignmentProposal)[];
  conflicts?: Conflict[];
  scenario?: Scenario | null;
  solution?: SolverSolution | null;
}

export interface AIExplainRequest {
  topic: 'conflict' | 'scenario' | 'alternative' | 'comparison' | 'timetable' | 'general';
  question: string;
  context: AIContext;
}

export interface AIExplainResponse {
  answer: string;
  model: string;
  ok: boolean;
  error?: string;
  fallbackUsed?: boolean;
}

export interface NLProposalRequest {
  query: string;
  context: AIContext;
}

export interface NLProposalResponse {
  ok: boolean;
  proposals: Array<{
    examId: string;
    examName: string;
    changeType: 'move' | 'room' | 'invigilator' | 'duration';
    targetSlotId?: string;
    targetRoomId?: string;
    targetInvigilatorIds?: string[];
    targetDuration?: number;
    rawReasoning: string;
  }>;
  error?: string;
  fallbackUsed?: boolean;
}

let cachedClient: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getClient() {
  if (cachedClient) return cachedClient;
  try {
    cachedClient = await ZAI.create();
    return cachedClient;
  } catch (err) {
    throw new Error(`Failed to initialize ZAI client: ${(err as Error).message}`);
  }
}

export function isAIAvailable(): boolean {
  // The SDK uses /etc/.z-ai-config which is provisioned in this environment.
  // We can't synchronously check, but we expose this for UI status display.
  return true;
}

function summarizeContext(ctx: AIContext): string {
  const lines: string[] = [];
  lines.push(`# Timetable Context`);
  lines.push(`- ${ctx.exams.length} exams, ${ctx.rooms.length} rooms, ${ctx.timeSlots.length} time slots, ${ctx.invigilators.length} invigilators, ${ctx.studentGroups.length} student groups`);
  lines.push(`- ${ctx.assignments.length} currently-published assignments`);
  if (ctx.conflicts && ctx.conflicts.length > 0) {
    lines.push(`- ${ctx.conflicts.length} detected conflicts:`);
    for (const c of ctx.conflicts.slice(0, 10)) {
      lines.push(`  - [${c.severity}] ${c.title}: ${c.description}`);
    }
  }
  lines.push('');
  lines.push('## Exams');
  for (const e of ctx.exams.slice(0, 20)) {
    const sg = ctx.studentGroups.find((g) => g.id === e.studentGroupId);
    lines.push(`- ${e.subjectCode} | ${e.name} | group=${sg?.name ?? e.studentGroupId} | duration=${e.duration}m | enrollment=${e.enrollmentCount}`);
  }
  lines.push('');
  lines.push('## Rooms');
  for (const r of ctx.rooms.slice(0, 15)) {
    lines.push(`- ${r.code} | ${r.name} | capacity=${r.capacity} | available=${r.isAvailable}`);
  }
  lines.push('');
  lines.push('## Time Slots');
  for (const t of ctx.timeSlots.slice(0, 20)) {
    lines.push(`- ${t.date} ${t.startTime}-${t.endTime} (id=${t.id}) available=${t.isAvailable}`);
  }
  return lines.join('\n');
}

const SYSTEM_PROMPT = `You are RippleMind's scheduling assistant for college examination timetables.
Your job is to:
1. Explain scheduling conflicts and proposed changes in clear, concise English.
2. Compare feasible alternative schedules and help administrators choose.
3. Translate natural-language scheduling requests into structured proposals.

CRITICAL RULES:
- You do NOT decide feasibility. The CP solver does. Always base explanations on the
  provided solver results, conflict reports, and scenario data — never invent metrics.
- If asked "is this feasible?", say you cannot determine it and that the solver must be run.
- Keep answers focused and under 250 words unless the user asks for detail.
- Use bullet points for lists of affected exams or resources.
- When translating a natural-language request, return STRICT JSON only, no prose.`;

export async function explain(req: AIExplainRequest): Promise<AIExplainResponse> {
  const userPrompt = buildExplainPrompt(req);
  try {
    const client = await getClient();
    const completion = await client.chat.completions.create({
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: userPrompt },
      ],
      thinking: { type: 'disabled' },
      temperature: 0.3,
    });
    const answer = completion.choices[0]?.message?.content ?? '';
    return { answer, model: 'glm-4.6', ok: true };
  } catch (err) {
    // Fallback: deterministic rule-based explanation
    return {
      answer: buildFallbackExplanation(req),
      model: 'rule-based-fallback',
      ok: true,
      fallbackUsed: true,
      error: (err as Error).message,
    };
  }
}

function buildExplainPrompt(req: AIExplainRequest): string {
  const ctx = req.context;
  const parts: string[] = [];
  parts.push(summarizeContext(ctx));
  parts.push('');
  parts.push(`## Topic: ${req.topic}`);
  if (req.topic === 'conflict' && ctx.conflicts) {
    parts.push('Explain why the following conflicts occurred and what would resolve them:');
  } else if (req.topic === 'scenario' && ctx.scenario) {
    parts.push(`Scenario: ${ctx.scenario.name}`);
    parts.push(`Description: ${ctx.scenario.description ?? '(none)'}`);
    parts.push(`Feasible: ${ctx.scenario.isFeasible}`);
    parts.push(`Change summary: ${JSON.stringify(ctx.scenario.changeSummary)}`);
    parts.push('Explain the effects of this proposed change.');
  } else if (req.topic === 'alternative' && ctx.solution) {
    parts.push(`Solver found ${ctx.solution.alternatives?.length ?? 0} alternatives.`);
    parts.push('Explain why an alternative was recommended.');
  } else if (req.topic === 'comparison' && ctx.solution?.alternatives) {
    parts.push('Compare the alternatives on: changed exams, room changes, utilization, workload balance, preference satisfaction.');
  } else if (req.topic === 'timetable') {
    parts.push('Answer the question about the current timetable.');
  }
  parts.push('');
  parts.push(`User question: ${req.question}`);
  return parts.join('\n');
}

function buildFallbackExplanation(req: AIExplainRequest): string {
  const ctx = req.context;
  if (req.topic === 'conflict' && ctx.conflicts?.length) {
    const lines = [`Detected ${ctx.conflicts.length} conflict(s):`];
    for (const c of ctx.conflicts.slice(0, 5)) {
      lines.push(`• [${c.severity}] ${c.title} — ${c.description}`);
      if (c.suggestedFix) lines.push(`  Suggested fix: ${c.suggestedFix}`);
    }
    lines.push('', 'Note: LLM unavailable. Showing rule-based summary.');
    return lines.join('\n');
  }
  if (req.topic === 'scenario' && ctx.scenario) {
    const s = ctx.scenario;
    return [
      `Scenario "${s.name}": ${s.description ?? '(no description)'}`,
      `Feasibility: ${s.isFeasible === null ? 'not analyzed' : s.isFeasible ? 'feasible' : 'infeasible'}`,
      `Conflicts detected: ${s.conflictReport.length}`,
      `Proposed changes: ${s.proposedState.length} assignments`,
      '',
      'Note: LLM unavailable. Showing rule-based summary.',
    ].join('\n');
  }
  return 'LLM is currently unavailable. Showing rule-based fallback. Please retry later for a richer explanation.';
}

export async function translateNLToProposal(req: NLProposalRequest): Promise<NLProposalResponse> {
  const ctx = req.context;
  const examList = ctx.exams.map((e) => ({
    id: e.id,
    name: e.name,
    subjectCode: e.subjectCode,
    studentGroup: ctx.studentGroups.find((g) => g.id === e.studentGroupId)?.name,
  }));
  const slotList = ctx.timeSlots.map((t) => ({
    id: t.id,
    date: t.date,
    start: t.startTime,
    end: t.endTime,
    label: t.label,
  }));
  const roomList = ctx.rooms.map((r) => ({ id: r.id, name: r.name, code: r.code, capacity: r.capacity }));
  const invList = ctx.invigilators.map((i) => ({ id: i.id, name: i.name, department: i.department }));

  const prompt = `Translate the user's scheduling request into STRICT JSON.
Available exams: ${JSON.stringify(examList.slice(0, 30))}
Available time slots: ${JSON.stringify(slotList.slice(0, 30))}
Available rooms: ${JSON.stringify(roomList.slice(0, 15))}
Available invigilators: ${JSON.stringify(invList.slice(0, 15))}

User request: "${req.query}"

Return JSON of shape:
{
  "proposals": [
    { "examId": "<id>", "changeType": "move|room|invigilator|duration",
      "targetSlotId": "<id or omit>", "targetRoomId": "<id or omit>",
      "targetInvigilatorIds": ["<ids>"] or omit, "targetDuration": <number> or omit,
      "rawReasoning": "<one sentence why>" }
  ]
}
- Use ONLY ids from the lists above.
- If the request mentions a day like "Friday afternoon", pick the matching slot id.
- If the request mentions a room name, pick the matching room id.
- If no specific exam matches, return an empty proposals array.
- Do NOT include any prose. Only JSON.`;

  try {
    const client = await getClient();
    const completion = await client.chat.completions.create({
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: prompt },
      ],
      thinking: { type: 'disabled' },
      temperature: 0.1,
    });
    const raw = completion.choices[0]?.message?.content ?? '';
    const json = extractJSON(raw);
    const proposals = (json.proposals ?? []).map((p: Record<string, unknown>) => ({
      examId: String(p.examId ?? ''),
      examName: ctx.exams.find((e) => e.id === p.examId)?.name ?? 'Unknown',
      changeType: (p.changeType as 'move' | 'room' | 'invigilator' | 'duration') ?? 'move',
      targetSlotId: p.targetSlotId ? String(p.targetSlotId) : undefined,
      targetRoomId: p.targetRoomId ? String(p.targetRoomId) : undefined,
      targetInvigilatorIds: Array.isArray(p.targetInvigilatorIds)
        ? p.targetInvigilatorIds.map(String)
        : undefined,
      targetDuration: typeof p.targetDuration === 'number' ? p.targetDuration : undefined,
      rawReasoning: String(p.rawReasoning ?? ''),
    }));
    return { ok: true, proposals };
  } catch (err) {
    return {
      ok: false,
      proposals: [],
      error: (err as Error).message,
      fallbackUsed: true,
    };
  }
}

function extractJSON(text: string): { proposals?: unknown[] } {
  // Strip ```json fences if present
  const fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fenceMatch ? fenceMatch[1] : text;
  try {
    return JSON.parse(raw.trim());
  } catch {
    // Try to find first { ... } block
    const start = raw.indexOf('{');
    const end = raw.lastIndexOf('}');
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(raw.slice(start, end + 1));
      } catch {
        return {};
      }
    }
    return {};
  }
}
