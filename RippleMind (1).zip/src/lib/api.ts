// API client — TanStack Query hooks for all RippleMind endpoints.

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type {
  AssignmentProposal,
  Conflict,
  DashboardMetrics,
  Exam,
  ExamAssignment,
  Invigilator,
  Room,
  Scenario,
  SolverConfig,
  SolverSolution,
  StudentGroup,
  TimeSlot,
} from './types';

const API = '/api/ripplemind';

async function fetchJSON<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
  });
  if (!res.ok) {
    const text = await res.text();
    let msg = `Request failed (${res.status})`;
    try { const j = JSON.parse(text); msg = j.error ?? msg; } catch { /* ignore */ }
    throw new Error(msg);
  }
  return res.json();
}

// --- Dashboard ---
export function useDashboard() {
  return useQuery({
    queryKey: ['dashboard'],
    queryFn: () => fetchJSON<DashboardMetrics>(`${API}/dashboard`),
    refetchInterval: 120000,
    staleTime: 60000,
  });
}

// --- Exams ---
export function useExams() {
  return useQuery({
    queryKey: ['exams'],
    queryFn: () => fetchJSON<{ exams: Exam[] }>(`${API}/exams`).then((r) => r.exams),
  });
}

export function useCreateExam() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Partial<Exam>) => fetchJSON<{ exam: Exam }>(`${API}/exams`, { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['exams'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

export function useUpdateExam() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Exam> }) =>
      fetchJSON<{ exam: Exam }>(`${API}/exams/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['exams'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

export function useDeleteExam() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => fetchJSON(`${API}/exams/${id}`, { method: 'DELETE' }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['exams'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

// --- Student Groups ---
export function useStudentGroups() {
  return useQuery({
    queryKey: ['student-groups'],
    queryFn: () => fetchJSON<{ studentGroups: (StudentGroup & { examCount?: number })[] }>(`${API}/student-groups`).then((r) => r.studentGroups),
  });
}

export function useCreateStudentGroup() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Partial<StudentGroup>) => fetchJSON(`${API}/student-groups`, { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['student-groups'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

export function useUpdateStudentGroup() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<StudentGroup> }) =>
      fetchJSON(`${API}/student-groups/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['student-groups'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

export function useDeleteStudentGroup() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => fetchJSON(`${API}/student-groups/${id}`, { method: 'DELETE' }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['student-groups'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

// --- Rooms ---
export function useRooms() {
  return useQuery({
    queryKey: ['rooms'],
    queryFn: () => fetchJSON<{ rooms: Room[] }>(`${API}/rooms`).then((r) => r.rooms),
  });
}

export function useCreateRoom() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Partial<Room>) => fetchJSON(`${API}/rooms`, { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['rooms'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

export function useUpdateRoom() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Room> }) =>
      fetchJSON(`${API}/rooms/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['rooms'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

export function useDeleteRoom() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => fetchJSON(`${API}/rooms/${id}`, { method: 'DELETE' }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['rooms'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

// --- Time Slots ---
export function useTimeSlots() {
  return useQuery({
    queryKey: ['time-slots'],
    queryFn: () => fetchJSON<{ timeSlots: TimeSlot[] }>(`${API}/time-slots`).then((r) => r.timeSlots),
  });
}

export function useCreateTimeSlot() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Partial<TimeSlot>) => fetchJSON(`${API}/time-slots`, { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['time-slots'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

export function useUpdateTimeSlot() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<TimeSlot> }) =>
      fetchJSON(`${API}/time-slots/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['time-slots'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

export function useDeleteTimeSlot() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => fetchJSON(`${API}/time-slots/${id}`, { method: 'DELETE' }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['time-slots'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

// --- Invigilators ---
export function useInvigilators() {
  return useQuery({
    queryKey: ['invigilators'],
    queryFn: () => fetchJSON<{ invigilators: Invigilator[] }>(`${API}/invigilators`).then((r) => r.invigilators),
  });
}

export function useCreateInvigilator() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Partial<Invigilator>) => fetchJSON(`${API}/invigilators`, { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['invigilators'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

export function useUpdateInvigilator() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Invigilator> }) =>
      fetchJSON(`${API}/invigilators/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['invigilators'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

export function useDeleteInvigilator() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => fetchJSON(`${API}/invigilators/${id}`, { method: 'DELETE' }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['invigilators'] }); qc.invalidateQueries({ queryKey: ['dashboard'] }); },
  });
}

// --- Assignments (timetable) ---
export function useAssignments() {
  return useQuery({
    queryKey: ['assignments'],
    queryFn: () => fetchJSON<{ assignments: ExamAssignment[] }>(`${API}/assignments`).then((r) => r.assignments),
  });
}

// --- Conflicts ---
export function useConflicts() {
  return useQuery({
    queryKey: ['conflicts'],
    queryFn: () => fetchJSON<{ conflicts: Conflict[]; totalConflicts: number }>(`${API}/conflicts`),
  });
}

// --- Schedule ---
export function useGenerateSchedule() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { examIds?: string[]; generateAlternatives?: boolean; maxAlternatives?: number; timeLimitMs?: number; objectiveWeights?: Partial<SolverConfig['objectiveWeights']>; solverMode?: 'cp' | 'greedy' }) =>
      fetchJSON<{ solution: SolverSolution; solverUsed: string }>(`${API}/schedule/generate`, { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['dashboard'] }),
  });
}

export function useApplySchedule() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { assignments: AssignmentProposal[]; mode?: 'replace' | 'merge' }) =>
      fetchJSON(`${API}/schedule/apply`, { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['assignments'] });
      qc.invalidateQueries({ queryKey: ['dashboard'] });
      qc.invalidateQueries({ queryKey: ['conflicts'] });
    },
  });
}

// --- Scenarios ---
export function useScenarios() {
  return useQuery({
    queryKey: ['scenarios'],
    queryFn: () => fetchJSON<{ scenarios: Scenario[] }>(`${API}/scenarios`).then((r) => r.scenarios),
  });
}

export function useScenario(id: string | null) {
  return useQuery({
    queryKey: ['scenario', id],
    queryFn: () => fetchJSON<{ scenario: Scenario }>(`${API}/scenarios/${id}`).then((r) => r.scenario),
    enabled: !!id,
  });
}

export function useCreateScenario() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { name: string; description?: string; examId: string; change: { targetSlotId?: string; targetRoomId?: string; targetInvigilatorIds?: string[]; targetDuration?: number }; generateAlternatives?: boolean }) =>
      fetchJSON<{ scenario: Scenario; solution: SolverSolution }>(`${API}/scenarios`, { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['scenarios'] }),
  });
}

export function useApplyScenario() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, alternativeIndex }: { id: string; alternativeIndex?: number }) =>
      fetchJSON(`${API}/scenarios/${id}/apply`, { method: 'POST', body: JSON.stringify({ alternativeIndex }) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['scenarios'] });
      qc.invalidateQueries({ queryKey: ['assignments'] });
      qc.invalidateQueries({ queryKey: ['dashboard'] });
      qc.invalidateQueries({ queryKey: ['conflicts'] });
    },
  });
}

export function useDiscardScenario() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => fetchJSON(`${API}/scenarios/${id}/discard`, { method: 'POST' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['scenarios'] }),
  });
}

export function useDeleteScenario() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => fetchJSON(`${API}/scenarios/${id}`, { method: 'DELETE' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['scenarios'] }),
  });
}

export function useScenarioRipple(id: string | null) {
  return useQuery({
    queryKey: ['scenario-ripple', id],
    queryFn: () => fetchJSON<{ graph: import('./types').RippleGraph }>(`${API}/scenarios/${id}/ripple`),
    enabled: !!id,
  });
}

// --- AI ---
export function useAIExplain() {
  return useMutation({
    mutationFn: (data: { topic: 'conflict' | 'scenario' | 'alternative' | 'comparison' | 'timetable' | 'general'; question: string; scenarioId?: string }) =>
      fetchJSON<{ answer: string; ok: boolean; model: string; fallbackUsed?: boolean }>(`${API}/ai/explain`, { method: 'POST', body: JSON.stringify(data) }),
  });
}

export function useAITranslate() {
  return useMutation({
    mutationFn: (data: { query: string }) =>
      fetchJSON<{ ok: boolean; proposals: Array<{ examId: string; examName: string; changeType: string; targetSlotId?: string; targetRoomId?: string; targetInvigilatorIds?: string[]; targetDuration?: number; rawReasoning: string }> }>(`${API}/ai/translate`, { method: 'POST', body: JSON.stringify(data) }),
  });
}

// --- Analytics ---
export function useAnalytics() {
  return useQuery({
    queryKey: ['analytics'],
    queryFn: () => fetchJSON<any>(`${API}/analytics`),
  });
}

// --- Audit ---
export function useAuditLog(limit = 100) {
  return useQuery({
    queryKey: ['audit', limit],
    queryFn: () => fetchJSON<{ auditLogs: any[] }>(`${API}/audit?limit=${limit}`).then((r) => r.auditLogs),
  });
}

// --- Notifications ---
export function useNotifications(enabled: boolean = true) {
  return useQuery({
    queryKey: ['notifications'],
    queryFn: () => fetchJSON<{ notifications: any[] }>(`${API}/notifications`).then((r) => r.notifications),
    refetchInterval: 120000,
    staleTime: 60000,
    enabled,
  });
}

export function useMarkNotificationRead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => fetchJSON(`${API}/notifications/${id}/read`, { method: 'POST' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['notifications'] }),
  });
}

// --- Student Portal ---
export function useStudentPortal(groupId: string | null) {
  return useQuery({
    queryKey: ['student-portal', groupId],
    queryFn: () => fetchJSON<any>(`${API}/student-portal?groupId=${groupId}`),
    enabled: !!groupId,
    refetchInterval: 30000, // auto-refresh for live updates
  });
}

// --- Settings ---
export function useSettings() {
  return useQuery({
    queryKey: ['settings'],
    queryFn: () => fetchJSON<{ settings: Record<string, string> }>(`${API}/settings`).then((r) => r.settings),
  });
}

export function useUpdateSettings() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Record<string, string>) => fetchJSON(`${API}/settings`, { method: 'PUT', body: JSON.stringify(data) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['settings'] }),
  });
}

// --- Emergency Simulation ---
export function useEmergencyOutage() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { roomId: string; reason: string; timeLimitMs?: number }) =>
      fetchJSON<any>(`${API}/emergency/outage`, { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['dashboard'] }),
  });
}

// --- Seed / Reset ---
export function useSeedData() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => fetchJSON(`${API}/seed`, { method: 'POST' }),
    onSuccess: () => qc.invalidateQueries(),
  });
}

export function useResetData() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => fetchJSON(`${API}/reset`, { method: 'POST' }),
    onSuccess: () => qc.invalidateQueries(),
  });
}
