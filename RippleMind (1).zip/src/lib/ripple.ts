// Ripple-effect graph builder — produces nodes/edges for React Flow
// from the actual diff between baseline and proposed assignments.

import type {
  AssignmentProposal,
  Conflict,
  Exam,
  Invigilator,
  Room,
  RippleEdge,
  RippleGraph,
  RippleNode,
  StudentGroup,
  TimeSlot,
} from './types';

export interface RippleInput {
  baseline: AssignmentProposal[];
  proposed: AssignmentProposal[];
  conflicts: Conflict[];
  exams: Exam[];
  rooms: Room[];
  timeSlots: TimeSlot[];
  invigilators: Invigilator[];
  studentGroups: StudentGroup[];
}

export function buildRippleGraph(input: RippleInput): RippleGraph {
  const {
    baseline,
    proposed,
    conflicts,
    exams,
    rooms,
    timeSlots,
    invigilators,
    studentGroups,
  } = input;

  const nodes: RippleNode[] = [];
  const edges: RippleEdge[] = [];
  const nodeIds = new Set<string>();

  const examMap = new Map(exams.map((e) => [e.id, e]));
  const roomMap = new Map(rooms.map((r) => [r.id, r]));
  const slotMap = new Map(timeSlots.map((t) => [t.id, t]));
  const invMap = new Map(invigilators.map((i) => [i.id, i]));
  const groupMap = new Map(studentGroups.map((g) => [g.id, g]));

  const baseMap = new Map(baseline.map((a) => [a.examId, a]));
  const propMap = new Map(proposed.map((a) => [a.examId, a]));

  function addNode(node: RippleNode) {
    if (!nodeIds.has(node.id)) {
      nodeIds.add(node.id);
      nodes.push(node);
    }
  }

  function addEdge(edge: RippleEdge) {
    edges.push(edge);
  }

  // Identify directly-changed exam
  const changedExamIds = new Set<string>();
  for (const [examId, to] of propMap) {
    const from = baseMap.get(examId);
    if (!from) {
      changedExamIds.add(examId); // newly added
    } else if (from.roomId !== to.roomId || from.timeSlotId !== to.timeSlotId) {
      changedExamIds.add(examId);
    }
  }
  for (const [examId] of baseMap) {
    if (!propMap.has(examId)) changedExamIds.add(examId); // removed
  }

  // Identify affected exams via conflicts
  const affectedExamIds = new Set<string>();
  for (const c of conflicts) {
    for (const id of c.examIds) {
      if (!changedExamIds.has(id)) affectedExamIds.add(id);
    }
  }

  // Add exam nodes
  for (const examId of changedExamIds) {
    const exam = examMap.get(examId);
    addNode({
      id: `exam:${examId}`,
      type: 'exam',
      label: exam?.name ?? examId,
      sublabel: exam?.subjectCode,
      changed: true,
    });
  }
  for (const examId of affectedExamIds) {
    const exam = examMap.get(examId);
    addNode({
      id: `exam:${examId}`,
      type: 'exam',
      label: exam?.name ?? examId,
      sublabel: exam?.subjectCode,
      affected: true,
    });
  }

  // For each changed/affected exam, add its assigned room/slot/invigilator/group nodes
  const allRelevantExams = new Set([...changedExamIds, ...affectedExamIds]);
  for (const examId of allRelevantExams) {
    const exam = examMap.get(examId);
    if (!exam) continue;
    const from = baseMap.get(examId);
    const to = propMap.get(examId);

    // Student group node
    const group = groupMap.get(exam.studentGroupId);
    if (group) {
      addNode({
        id: `group:${group.id}`,
        type: 'studentgroup',
        label: group.name,
        sublabel: `${group.studentCount} students`,
      });
      addEdge({
        id: `edge:${examId}:group:${group.id}`,
        source: `exam:${examId}`,
        target: `group:${group.id}`,
        label: 'enrolled',
        kind: 'uses',
      });
    }

    // Original room
    if (from) {
      const fromRoom = roomMap.get(from.roomId);
      const fromSlot = slotMap.get(from.timeSlotId);
      if (fromRoom) {
        addNode({
          id: `room:${fromRoom.id}`,
          type: 'room',
          label: fromRoom.name,
          sublabel: `cap ${fromRoom.capacity}`,
          affected: to?.roomId !== fromRoom.id,
        });
        addEdge({
          id: `edge:${examId}:from-room:${fromRoom.id}`,
          source: `exam:${examId}`,
          target: `room:${fromRoom.id}`,
          label: to?.roomId !== fromRoom.id ? 'was in' : 'uses',
          kind: to?.roomId !== fromRoom.id ? 'moves' : 'uses',
        });
      }
      if (fromSlot) {
        addNode({
          id: `slot:${fromSlot.id}`,
          type: 'timeslot',
          label: fromSlot.date,
          sublabel: `${fromSlot.startTime}-${fromSlot.endTime}`,
          affected: to?.timeSlotId !== fromSlot.id,
        });
        addEdge({
          id: `edge:${examId}:from-slot:${fromSlot.id}`,
          source: `exam:${examId}`,
          target: `slot:${fromSlot.id}`,
          label: to?.timeSlotId !== fromSlot.id ? 'was at' : 'scheduled at',
          kind: to?.timeSlotId !== fromSlot.id ? 'moves' : 'uses',
        });
      }
      for (const invId of from.invigilatorIds ?? []) {
        const inv = invMap.get(invId);
        if (inv) {
          addNode({
            id: `inv:${inv.id}`,
            type: 'invigilator',
            label: inv.name,
            sublabel: inv.department,
            affected: !to?.invigilatorIds?.includes(invId),
          });
          addEdge({
            id: `edge:${examId}:from-inv:${inv.id}`,
            source: `exam:${examId}`,
            target: `inv:${inv.id}`,
            label: to?.invigilatorIds?.includes(invId) ? 'invigilates' : 'was invigilating',
            kind: to?.invigilatorIds?.includes(invId) ? 'uses' : 'moves',
          });
        }
      }
    }

    // New room/slot/invigilators (only if different)
    if (to && (!from || from.roomId !== to.roomId)) {
      const toRoom = roomMap.get(to.roomId);
      if (toRoom) {
        addNode({
          id: `room:${toRoom.id}`,
          type: 'room',
          label: toRoom.name,
          sublabel: `cap ${toRoom.capacity}`,
          changed: true,
        });
        addEdge({
          id: `edge:${examId}:to-room:${toRoom.id}`,
          source: `exam:${examId}`,
          target: `room:${toRoom.id}`,
          label: 'moves to',
          kind: 'moves',
        });
      }
    }
    if (to && (!from || from.timeSlotId !== to.timeSlotId)) {
      const toSlot = slotMap.get(to.timeSlotId);
      if (toSlot) {
        addNode({
          id: `slot:${toSlot.id}`,
          type: 'timeslot',
          label: toSlot.date,
          sublabel: `${toSlot.startTime}-${toSlot.endTime}`,
          changed: true,
        });
        addEdge({
          id: `edge:${examId}:to-slot:${toSlot.id}`,
          source: `exam:${examId}`,
          target: `slot:${toSlot.id}`,
          label: 'moves to',
          kind: 'moves',
        });
      }
    }
    if (to) {
      for (const invId of to.invigilatorIds ?? []) {
        if (from?.invigilatorIds?.includes(invId)) continue; // already added
        const inv = invMap.get(invId);
        if (inv) {
          addNode({
            id: `inv:${inv.id}`,
            type: 'invigilator',
            label: inv.name,
            sublabel: inv.department,
            changed: true,
          });
          addEdge({
            id: `edge:${examId}:to-inv:${inv.id}`,
            source: `exam:${examId}`,
            target: `inv:${inv.id}`,
            label: 'new invigilator',
            kind: 'moves',
          });
        }
      }
    }
  }

  // Add conflict-based edges between affected exams
  for (const c of conflicts) {
    for (let i = 0; i < c.examIds.length; i++) {
      for (let j = i + 1; j < c.examIds.length; j++) {
        const a = c.examIds[i];
        const b = c.examIds[j];
        if (!allRelevantExams.has(a) || !allRelevantExams.has(b)) continue;
        addEdge({
          id: `edge:conflict:${a}:${b}:${c.kind}`,
          source: `exam:${a}`,
          target: `exam:${b}`,
          label: c.title,
          kind: 'conflicts',
        });
      }
    }
  }

  return { nodes, edges };
}
