// Time utilities — overlap detection, formatting, and date arithmetic.

export function parseTimeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

export function minutesToTime(minutes: number): string {
  const h = Math.floor(minutes / 60) % 24;
  const m = minutes % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}

export interface TimeRange {
  start: number; // minutes from 00:00
  end: number;
}

export function rangesOverlap(a: TimeRange, b: TimeRange): boolean {
  return a.start < b.end && b.start < a.end;
}

export interface SlotWindow {
  date: string;
  start: number;
  end: number;
}

export function slotWindow(date: string, startTime: string, endTime: string): SlotWindow {
  return {
    date,
    start: parseTimeToMinutes(startTime),
    end: parseTimeToMinutes(endTime),
  };
}

export function slotsOverlapOnSameDate(a: SlotWindow, b: SlotWindow): boolean {
  if (a.date !== b.date) return false;
  return rangesOverlap(a, b);
}

// Format date for display
export function formatDate(isoDate: string): string {
  // isoDate is YYYY-MM-DD
  const [y, m, d] = isoDate.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function formatDateShort(isoDate: string): string {
  const [y, m, d] = isoDate.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });
}

export function dayName(isoDate: string): string {
  const [y, m, d] = isoDate.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.toLocaleDateString('en-US', { weekday: 'long' });
}

export function dayOfWeek(isoDate: string): number {
  const [y, m, d] = isoDate.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.getDay();
}

// Return a YYYY-MM-DD string for a Date in local time (avoids UTC off-by-one).
export function toISODate(date: Date): string {
  const y = date.getFullYear();
  const m = (date.getMonth() + 1).toString().padStart(2, '0');
  const d = date.getDate().toString().padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function addDays(isoDate: string, days: number): string {
  const [y, m, d] = isoDate.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  date.setDate(date.getDate() + days);
  return toISODate(date);
}

export function formatTimeRange(start: string, end: string): string {
  return `${start}–${end}`;
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes}m`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m === 0 ? `${h}h` : `${h}h ${m}m`;
}

// Generate N upcoming weekday dates starting from a base date.
export function generateWeekdayDates(startDate: string, count: number): string[] {
  const dates: string[] = [];
  let current = startDate;
  while (dates.length < count) {
    const dow = dayOfWeek(current);
    if (dow !== 0 && dow !== 6) {
      // Mon–Fri only
      dates.push(current);
    }
    current = addDays(current, 1);
  }
  return dates;
}
