// Auth store — manages the current session (admin or student role).
// Persists to localStorage so the session survives page refreshes.

import { create } from 'zustand';

export type UserRole = 'admin' | 'student';

export interface Session {
  role: UserRole;
  // For students: their student group ID
  groupId?: string;
  groupName?: string;
  // Display name
  name: string;
  // Login timestamp
  loginAt: number;
}

interface AuthState {
  session: Session | null;
  login: (session: Session) => void;
  logout: () => void;
  isAdmin: () => boolean;
  isStudent: () => boolean;
}

const STORAGE_KEY = 'ripplemind-session';

function loadSession(): Session | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Session) : null;
  } catch {
    return null;
  }
}

function saveSession(session: Session | null) {
  if (typeof window === 'undefined') return;
  if (session) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  } else {
    localStorage.removeItem(STORAGE_KEY);
  }
}

export const useAuth = create<AuthState>((set, get) => ({
  session: typeof window !== 'undefined' ? loadSession() : null,
  login: (session) => {
    saveSession(session);
    set({ session });
  },
  logout: () => {
    saveSession(null);
    set({ session: null });
  },
  isAdmin: () => get().session?.role === 'admin',
  isStudent: () => get().session?.role === 'student',
}));
