// Shared API helpers for RippleMind REST endpoints.

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { parseStringArray } from '@/lib/json';
import type {
  Exam,
  ExamAssignment,
  Invigilator,
  Room,
  StudentGroup,
  TimeSlot,
} from '@/lib/types';

export { db };

export function ok<T>(data: T, status = 200) {
  return NextResponse.json(data, { status });
}

export function fail(message: string, status = 400, details?: unknown) {
  return NextResponse.json({ error: message, details }, { status });
}

export async function readBody<T = unknown>(req: Request): Promise<T | null> {
  try {
    return (await req.json()) as T;
  } catch {
    return null;
  }
}

// Transform DB rows into rich domain objects (parse JSON arrays).
export function rowToStudentGroup(row: any): StudentGroup {
  return { ...row };
}

export function rowToRoom(row: any): Room {
  return {
    ...row,
    features: parseStringArray(row.features),
  };
}

export function rowToTimeSlot(row: any): TimeSlot {
  return { ...row };
}

export function rowToInvigilator(row: any): Invigilator {
  return {
    ...row,
    availability: parseStringArray(row.availability),
  };
}

export async function rowToExam(row: any): Promise<Exam> {
  const studentGroup = row.studentGroup
    ? rowToStudentGroup(row.studentGroup)
    : undefined;
  const assignment = row.assignment ? rowToAssignment(row.assignment) : null;
  return {
    ...row,
    preferredSlots: parseStringArray(row.preferredSlots),
    preferredRooms: parseStringArray(row.preferredRooms),
    studentGroup,
    assignment,
  };
}

export function rowToAssignment(row: any): ExamAssignment {
  return {
    ...row,
    invigilatorIds: parseStringArray(row.invigilatorIds),
    exam: row.exam ? { ...row.exam, preferredSlots: parseStringArray(row.exam.preferredSlots), preferredRooms: parseStringArray(row.exam.preferredRooms) } : undefined,
    timeSlot: row.timeSlot ? rowToTimeSlot(row.timeSlot) : undefined,
    room: row.room ? rowToRoom(row.room) : undefined,
  };
}

// Load all context data for the solver / conflict detection.
export async function loadContext() {
  const [exams, rooms, timeSlots, invigilators, studentGroups, assignments] = await Promise.all([
    db.exam.findMany({ include: { studentGroup: true, assignment: true } }),
    db.room.findMany(),
    db.timeSlot.findMany(),
    db.invigilator.findMany(),
    db.studentGroup.findMany(),
    db.examAssignment.findMany({
      include: { exam: { include: { studentGroup: true } }, room: true, timeSlot: true },
      where: { isPublished: true },
    }),
  ]);

  return {
    exams: await Promise.all(exams.map(rowToExam)),
    rooms: rooms.map(rowToRoom),
    timeSlots: timeSlots.map(rowToTimeSlot),
    invigilators: invigilators.map(rowToInvigilator),
    studentGroups: studentGroups.map(rowToStudentGroup),
    assignments: assignments.map(rowToAssignment),
  };
}

export async function writeAuditLog(params: {
  action: string;
  category: string;
  summary: string;
  target?: string;
  details?: Record<string, unknown>;
  scenarioId?: string;
}) {
  try {
    await db.auditLog.create({
      data: {
        action: params.action,
        category: params.category,
        summary: params.summary,
        target: params.target,
        details: JSON.stringify(params.details ?? {}),
        scenarioId: params.scenarioId,
      },
    });
  } catch (err) {
    console.error('Failed to write audit log:', err);
  }
}

export async function pushNotification(params: {
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
}) {
  try {
    await db.notification.create({ data: params });
  } catch (err) {
    console.error('Failed to push notification:', err);
  }
}

export function validatePositiveInt(value: unknown, field: string): number {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) {
    throw new Error(`${field} must be a positive integer`);
  }
  return n;
}

export function validateNonNegativeInt(value: unknown, field: string): number {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 0) {
    throw new Error(`${field} must be a non-negative integer`);
  }
  return n;
}
