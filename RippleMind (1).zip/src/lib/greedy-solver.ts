// Greedy fallback solver — fast first-fit with local search improvement.
// Used when OR-Tools CP-SAT is not available, or when a quick approximation is needed.
// Considers: room capacity, scheduling conflicts, exam duration, assignment stability.

import type {
  AssignmentProposal,
  Exam,
  Invigilator,
  Room,
  SolverConfig,
  SolverSolution,
  StudentGroup,
  TimeSlot,
} from './types';
import { detectConflicts, type ConflictContext } from './conflicts';
import { parseTimeToMinutes, slotsOverlapOnSameDate } from './time';

export interface GreedySolverInput {
  exams: Exam[];
  rooms: Room[];
  timeSlots: TimeSlot[];
  invigilators: Invigilator[];
  studentGroups: StudentGroup[];
  config: SolverConfig;
  fixedAssignments?: AssignmentProposal[];
  // Rooms to exclude (for emergency outage simulation)
  excludedRoomIds?: string[];
  // Max iterations for local search
  maxIterations?: number;
}

// Check if OR-Tools CP-SAT is available (Python subprocess).
// In this environment Python isn't installed, so this returns false.
// In production, set ORTOOLS_AVAILABLE=true after installing Google OR-Tools.
export function isORToolsAvailable(): boolean {
  return process.env.ORTOOLS_AVAILABLE === 'true';
}

// Greedy first-fit: assign exams one at a time to the first compatible slot+room.
export function solveGreedy(input: GreedySolverInput): SolverSolution {
  const { exams, rooms, timeSlots, invigilators, studentGroups, config, fixedAssignments, excludedRoomIds } = input;
  const startTime = Date.now();
  const context: ConflictContext = { exams, rooms, timeSlots, invigilators, studentGroups };
  const excluded = new Set(excludedRoomIds ?? []);

  // Filter out excluded rooms (emergency outage)
  const availableRooms = rooms.filter((r) => r.isAvailable && !excluded.has(r.id));
  const availableSlots = timeSlots.filter((t) => t.isAvailable);

  // Sort exams by enrollment (descending) — hardest to place first
  const sortedExams = [...exams].sort((a, b) => b.enrollmentCount - a.enrollmentCount);

  const assignments = new Map<string, AssignmentProposal>();
  const unscheduled: { examId: string; reason: string }[] = [];

  // Seed fixed assignments
  if (fixedAssignments) {
    for (const a of fixedAssignments) {
      assignments.set(a.examId, a);
    }
  }

  // First-fit assignment
  for (const exam of sortedExams) {
    if (assignments.has(exam.id)) continue; // already fixed
    let placed = false;

    // Sort rooms by capacity fit (tightest first)
    const candidateRooms = availableRooms
      .filter((r) => r.capacity >= exam.enrollmentCount)
      .sort((a, b) => a.capacity - b.capacity);

    if (candidateRooms.length === 0) {
      unscheduled.push({
        examId: exam.id,
        reason: `No available room has capacity ≥ ${exam.enrollmentCount} for "${exam.name}".`,
      });
      continue;
    }

    // Try each room + slot combination
    for (const room of candidateRooms) {
      if (placed) break;
      // Prefer preferred slots if any
      const sortedSlots = exam.preferredSlots.length
        ? [...availableSlots].sort((a, b) => {
            const aPref = exam.preferredSlots.includes(a.id) ? -1 : 1;
            const bPref = exam.preferredSlots.includes(b.id) ? -1 : 1;
            return aPref - bPref;
          })
        : availableSlots;

      for (const slot of sortedSlots) {
        if (placed) break;
        // Pick an available invigilator
        const invigilator = invigilators.find((i) => {
          if (!i.isAvailable) return false;
          const avail = i.availability ?? [];
          return avail.length === 0 || avail.includes(slot.id);
        });
        if (!invigilator) continue;

        const proposal: AssignmentProposal = {
          examId: exam.id,
          timeSlotId: slot.id,
          roomId: room.id,
          invigilatorIds: [invigilator.id],
        };

        if (isCompatibleGreedy(proposal, assignments, context)) {
          assignments.set(exam.id, proposal);
          placed = true;
        }
      }
    }

    if (!placed) {
      unscheduled.push({
        examId: exam.id,
        reason: `No compatible (room × slot × invigilator) found for "${exam.name}" given current constraints.`,
      });
    }
  }

  // Local search improvement: try to improve the solution by swapping assignments
  // to reduce capacity waste. Limited iterations for memory safety.
  const iterations = input.maxIterations ?? 20;
  let improved = true;
  let iter = 0;
  while (improved && iter < iterations) {
    improved = false;
    iter++;

    // Only try to improve a subset of exams per iteration (memory safety)
    const examIds = Array.from(assignments.keys()).slice(0, 10);
    for (const examId of examIds) {
      const current = assignments.get(examId);
      if (!current) continue;
      const exam = exams.find((e) => e.id === examId);
      if (!exam) continue;
      const currentRoom = rooms.find((r) => r.id === current.roomId);
      if (!currentRoom) continue;

      // Try to find a better room (tighter fit)
      const betterRooms = availableRooms
        .filter((r) => r.capacity >= exam.enrollmentCount && r.capacity < currentRoom.capacity)
        .sort((a, b) => b.capacity - a.capacity);

      for (const betterRoom of betterRooms.slice(0, 3)) { // limit candidates
        const proposal: AssignmentProposal = {
          examId,
          timeSlotId: current.timeSlotId,
          roomId: betterRoom.id,
          invigilatorIds: current.invigilatorIds,
        };
        assignments.delete(examId);
        if (isCompatibleGreedy(proposal, assignments, context)) {
          assignments.set(examId, proposal);
          improved = true;
          break;
        } else {
          assignments.set(examId, current);
        }
      }
    }
  }

  const solutionAssignments = Array.from(assignments.values());
  const conflicts = detectConflicts({ assignments: solutionAssignments, context });

  // Compute metrics
  const roomUsage = new Set(solutionAssignments.map((a) => a.roomId));
  const invLoad = new Map<string, number>();
  let capacityWaste = 0;
  for (const a of solutionAssignments) {
    const exam = exams.find((e) => e.id === a.examId);
    const room = rooms.find((r) => r.id === a.roomId);
    if (exam && room) capacityWaste += Math.max(0, room.capacity - exam.enrollmentCount);
    for (const inv of a.invigilatorIds) invLoad.set(inv, (invLoad.get(inv) ?? 0) + 1);
  }
  const loads = Array.from(invLoad.values());
  const maxLoad = loads.length ? Math.max(...loads) : 0;
  const avgLoad = loads.length ? loads.reduce((s, v) => s + v, 0) / loads.length : 0;

  let preferenceHits = 0, preferenceTotal = 0;
  for (const a of solutionAssignments) {
    const exam = exams.find((e) => e.id === a.examId);
    if (!exam) continue;
    if (exam.preferredSlots.length) { preferenceTotal++; if (exam.preferredSlots.includes(a.timeSlotId)) preferenceHits++; }
    if (exam.preferredRooms.length) { preferenceTotal++; if (exam.preferredRooms.includes(a.roomId)) preferenceHits++; }
  }

  let changedExams = 0, roomChanges = 0;
  if (config.baseline) {
    for (const a of solutionAssignments) {
      const base = config.baseline[a.examId];
      if (base) {
        if (base.timeSlotId !== a.timeSlotId || base.roomId !== a.roomId) changedExams++;
        if (base.roomId !== a.roomId) roomChanges++;
      }
    }
  }

  const feasible = solutionAssignments.length > 0 && !conflicts.some((c) => c.severity === 'critical');

  return {
    feasible,
    provenInfeasible: solutionAssignments.length === 0,
    timedOut: false,
    assignments: solutionAssignments,
    unscheduled,
    conflicts,
    metrics: {
      scheduledExams: solutionAssignments.length,
      totalExams: exams.length,
      roomUtilization: rooms.length ? (roomUsage.size / rooms.length) * 100 : 0,
      avgInvigilatorLoad: avgLoad,
      maxInvigilatorLoad: maxLoad,
      capacityWaste,
      preferenceScore: preferenceTotal ? (preferenceHits / preferenceTotal) * 100 : 100,
      changedExamsFromBaseline: config.baseline ? changedExams : undefined,
      roomChangesFromBaseline: config.baseline ? roomChanges : undefined,
      searchNodes: iter,
      elapsedMs: Date.now() - startTime,
    },
  };
}

function isCompatibleGreedy(
  candidate: AssignmentProposal,
  current: Map<string, AssignmentProposal>,
  context: ConflictContext
): boolean {
  const exam = context.exams.find((e) => e.id === candidate.examId);
  if (!exam) return false;
  const room = context.rooms.find((r) => r.id === candidate.roomId);
  const slot = context.timeSlots.find((t) => t.id === candidate.timeSlotId);
  if (!room || !slot) return false;
  if (!room.isAvailable || !slot.isAvailable) return false;
  if (room.capacity < exam.enrollmentCount) return false;

  const candRange = { date: slot.date, start: parseTimeToMinutes(slot.startTime), end: parseTimeToMinutes(slot.endTime) };
  for (const [, existing] of current) {
    if (existing.examId === candidate.examId) continue;
    const exExam = context.exams.find((e) => e.id === existing.examId);
    const exSlot = context.timeSlots.find((t) => t.id === existing.timeSlotId);
    if (!exExam || !exSlot) continue;
    const exRange = { date: exSlot.date, start: parseTimeToMinutes(exSlot.startTime), end: parseTimeToMinutes(exSlot.endTime) };
    const overlap = slotsOverlapOnSameDate(candRange, exRange);
    if (existing.roomId === candidate.roomId && overlap) return false;
    if (exExam.studentGroupId === exam.studentGroupId && overlap) return false;
    const sharedInv = (existing.invigilatorIds ?? []).filter((id) => (candidate.invigilatorIds ?? []).includes(id));
    if (sharedInv.length > 0 && overlap) return false;
  }
  return true;
}
