// Quick debug script — run solver with the current DB data.
import { db } from '../src/lib/db';
import { loadContext } from '../src/lib/api-helpers';
import { solve } from '../src/lib/solver';

async function main() {
  const ctx = await loadContext();
  console.log('exams:', ctx.exams.length);
  console.log('rooms:', ctx.rooms.length);
  console.log('timeSlots:', ctx.timeSlots.length);
  console.log('invigilators:', ctx.invigilators.length);

  const maxCap = Math.max(...ctx.rooms.map(r => r.capacity));
  for (const e of ctx.exams) {
    const fittingRooms = ctx.rooms.filter(r => r.capacity >= e.enrollmentCount).length;
    console.log(`  ${e.subjectCode} enrollment=${e.enrollmentCount} fittingRooms=${fittingRooms}`);
  }
  console.log('max room capacity:', maxCap);

  const solution = solve({
    exams: ctx.exams,
    rooms: ctx.rooms,
    timeSlots: ctx.timeSlots,
    invigilators: ctx.invigilators,
    studentGroups: ctx.studentGroups,
    config: {
      timeLimitMs: 5000,
      maxAlternatives: 1,
      objectiveWeights: {
        minimizeChangedExams: 10,
        minimizeRoomChanges: 8,
        minimizeCapacityWaste: 1,
        respectPreferredSlots: 5,
        balanceInvigilatorWorkload: 4,
      },
    },
  });
  console.log('feasible:', solution.feasible);
  console.log('provenInfeasible:', solution.provenInfeasible);
  console.log('timedOut:', solution.timedOut);
  console.log('assignments:', solution.assignments.length);
  console.log('unscheduled:', solution.unscheduled.length);
  console.log('searchNodes:', solution.metrics.searchNodes);
  console.log('elapsedMs:', solution.metrics.elapsedMs);
  if (solution.unscheduled.length) {
    console.log('first unscheduled reason:', solution.unscheduled[0].reason);
  }
  await db.$disconnect();
}

main().catch(e => { console.error(e); process.exit(1); });
