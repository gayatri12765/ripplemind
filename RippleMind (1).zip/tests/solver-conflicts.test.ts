// Tests for the CP solver and conflict detection engine.
// Run with: bun test

import { describe, expect, test } from 'bun:test';
import { solve } from '../src/lib/solver';
import { detectConflicts } from '../src/lib/conflicts';
import type { Exam, Invigilator, Room, StudentGroup, TimeSlot, AssignmentProposal } from '../src/lib/types';

// --- Test fixtures ---

function makeStudentGroup(id: string, name: string, count: number): StudentGroup {
  return { id, name, code: name.toUpperCase().replace(/\s/g, '-'), studentCount: count, createdAt: '', updatedAt: '' };
}

function makeRoom(id: string, name: string, capacity: number, available = true): Room {
  return { id, name, code: name, capacity, location: null, building: null, floor: null, features: [], isAvailable: available, createdAt: '', updatedAt: '' };
}

function makeTimeSlot(id: string, date: string, start: string, end: string, available = true): TimeSlot {
  return { id, date, startTime: start, endTime: end, label: null, dayOfWeek: 1, isAvailable: available, createdAt: '', updatedAt: '' };
}

function makeInvigilator(id: string, name: string, max = 3): Invigilator {
  return { id, name, email: null, department: null, maxWorkload: max, availability: [], isAvailable: true, createdAt: '', updatedAt: '' };
}

function makeExam(id: string, name: string, code: string, duration: number, groupId: string, enrollment: number): Exam {
  return {
    id, name, subjectCode: code, duration, studentGroupId: groupId, enrollmentCount: enrollment,
    examType: 'final', notes: null, status: 'unscheduled', preferredSlots: [], preferredRooms: [],
    createdAt: '', updatedAt: '',
  };
}

const baseGroups = [
  makeStudentGroup('g1', 'CS-Y3', 120),
  makeStudentGroup('g2', 'EE-Y2', 85),
];

const baseRooms = [
  makeRoom('r1', 'Auditorium A', 200),
  makeRoom('r2', 'Hall 101', 120),
  makeRoom('r3', 'Room 301', 60),
];

const baseSlots = [
  makeTimeSlot('s1', '2026-01-05', '09:00', '11:00'),
  makeTimeSlot('s2', '2026-01-05', '12:00', '14:00'),
  makeTimeSlot('s3', '2026-01-06', '09:00', '11:00'),
];

const baseInvs = [
  makeInvigilator('i1', 'Dr. Rao'),
  makeInvigilator('i2', 'Prof. Shah'),
];

// --- Solver tests ---

describe('CP Solver', () => {
  test('finds a feasible schedule for a simple problem', async () => {
    const exams = [
      makeExam('e1', 'Data Structures', 'CS301', 180, 'g1', 120),
      makeExam('e2', 'Circuit Theory', 'EE201', 180, 'g2', 85),
    ];
    const solution = await solve({
      exams,
      rooms: baseRooms,
      timeSlots: baseSlots,
      invigilators: baseInvs,
      studentGroups: baseGroups,
      config: {
        timeLimitMs: 5000,
        maxAlternatives: 1,
        objectiveWeights: {
          minimizeChangedExams: 10, minimizeRoomChanges: 8, minimizeCapacityWaste: 1,
          respectPreferredSlots: 5, balanceInvigilatorWorkload: 4,
        },
      },
      stopOnFirstFeasible: true,
    });
    expect(solution.feasible).toBe(true);
    expect(solution.assignments.length).toBe(2);
    expect(solution.conflicts.length).toBe(0);
    expect(solution.provenInfeasible).toBe(false);
  });

  test('reports proven infeasible when no room has enough capacity', async () => {
    const exams = [makeExam('e1', 'Big Exam', 'BIG101', 180, 'g1', 500)]; // 500 students
    const solution = await solve({
      exams,
      rooms: baseRooms, // max capacity 200
      timeSlots: baseSlots,
      invigilators: baseInvs,
      studentGroups: baseGroups,
      config: {
        timeLimitMs: 5000,
        maxAlternatives: 1,
        objectiveWeights: {
          minimizeChangedExams: 10, minimizeRoomChanges: 8, minimizeCapacityWaste: 1,
          respectPreferredSlots: 5, balanceInvigilatorWorkload: 4,
        },
      },
    });
    // The solver falls back to insufficient-capacity rooms, but isCompatible rejects them.
    // This should either be infeasible or have capacity conflicts.
    expect(solution.feasible).toBe(false);
    expect(solution.provenInfeasible).toBe(true);
  });

  test('respects room capacity in the solution', async () => {
    const exams = [
      makeExam('e1', 'Data Structures', 'CS301', 180, 'g1', 120),
      makeExam('e2', 'Small Quiz', 'CS302', 60, 'g1', 40),
    ];
    const solution = await solve({
      exams,
      rooms: baseRooms,
      timeSlots: baseSlots,
      invigilators: baseInvs,
      studentGroups: baseGroups,
      config: {
        timeLimitMs: 5000,
        maxAlternatives: 1,
        objectiveWeights: {
          minimizeChangedExams: 10, minimizeRoomChanges: 8, minimizeCapacityWaste: 1,
          respectPreferredSlots: 5, balanceInvigilatorWorkload: 4,
        },
      },
      stopOnFirstFeasible: true,
    });
    expect(solution.feasible).toBe(true);
    for (const a of solution.assignments) {
      const exam = exams.find((e) => e.id === a.examId);
      const room = baseRooms.find((r) => r.id === a.roomId);
      expect(room).toBeDefined();
      expect(room!.capacity).toBeGreaterThanOrEqual(exam!.enrollmentCount);
    }
  });

  test('never assigns two exams to the same room at overlapping times', async () => {
    const exams = [
      makeExam('e1', 'Exam 1', 'EX1', 120, 'g1', 50),
      makeExam('e2', 'Exam 2', 'EX2', 120, 'g2', 50),
      makeExam('e3', 'Exam 3', 'EX3', 120, 'g1', 50),
    ];
    const solution = await solve({
      exams,
      rooms: baseRooms,
      timeSlots: baseSlots,
      invigilators: baseInvs,
      studentGroups: baseGroups,
      config: {
        timeLimitMs: 5000,
        maxAlternatives: 1,
        objectiveWeights: {
          minimizeChangedExams: 10, minimizeRoomChanges: 8, minimizeCapacityWaste: 1,
          respectPreferredSlots: 5, balanceInvigilatorWorkload: 4,
        },
      },
      stopOnFirstFeasible: true,
    });
    expect(solution.feasible).toBe(true);
    expect(solution.conflicts.filter((c) => c.kind === 'room_double_booking')).toHaveLength(0);
  });

  test('never assigns overlapping exams to the same student group', async () => {
    const exams = [
      makeExam('e1', 'Exam 1', 'EX1', 120, 'g1', 50),
      makeExam('e2', 'Exam 2', 'EX2', 120, 'g1', 50), // same group
      makeExam('e3', 'Exam 3', 'EX3', 120, 'g2', 50),
    ];
    const solution = await solve({
      exams,
      rooms: baseRooms,
      timeSlots: baseSlots,
      invigilators: baseInvs,
      studentGroups: baseGroups,
      config: {
        timeLimitMs: 5000,
        maxAlternatives: 1,
        objectiveWeights: {
          minimizeChangedExams: 10, minimizeRoomChanges: 8, minimizeCapacityWaste: 1,
          respectPreferredSlots: 5, balanceInvigilatorWorkload: 4,
        },
      },
      stopOnFirstFeasible: true,
    });
    expect(solution.feasible).toBe(true);
    expect(solution.conflicts.filter((c) => c.kind === 'student_group_overlap')).toHaveLength(0);
  });

  test('respects max exams per day per group (fairness)', async () => {
    // 3 exams for the same group, but only 3 slots on the same day (s1, s2 same day, s3 different day)
    // With maxExamsPerDayPerGroup=2, the solver should spread across days
    const slots = [
      makeTimeSlot('s1', '2026-01-05', '09:00', '11:00'),
      makeTimeSlot('s2', '2026-01-05', '12:00', '14:00'),
      makeTimeSlot('s3', '2026-01-05', '15:00', '17:00'),
      makeTimeSlot('s4', '2026-01-06', '09:00', '11:00'),
      makeTimeSlot('s5', '2026-01-06', '12:00', '14:00'),
    ];
    const exams = [
      makeExam('e1', 'Exam 1', 'EX1', 120, 'g1', 50),
      makeExam('e2', 'Exam 2', 'EX2', 120, 'g1', 50),
      makeExam('e3', 'Exam 3', 'EX3', 120, 'g1', 50),
    ];
    const solution = await solve({
      exams,
      rooms: baseRooms,
      timeSlots: slots,
      invigilators: baseInvs,
      studentGroups: baseGroups,
      config: {
        timeLimitMs: 5000,
        maxAlternatives: 1,
        objectiveWeights: {
          minimizeChangedExams: 10, minimizeRoomChanges: 8, minimizeCapacityWaste: 1,
          respectPreferredSlots: 5, balanceInvigilatorWorkload: 4,
        },
      },
      stopOnFirstFeasible: true,
      maxExamsPerDayPerGroup: 2, // max 2 per day
    });
    expect(solution.feasible).toBe(true);
    // Count exams per day for g1
    const byDate = new Map<string, number>();
    for (const a of solution.assignments) {
      const slot = slots.find((s) => s.id === a.timeSlotId);
      if (slot) byDate.set(slot.date, (byDate.get(slot.date) ?? 0) + 1);
    }
    for (const count of byDate.values()) {
      expect(count).toBeLessThanOrEqual(2);
    }
  });

  test('respects minimum gap between exams for same group (fairness)', async () => {
    // Two exams for the same group on the same day; slots are back-to-back (11:00-12:00 gap = 0)
    // With minGap=60, the solver should not put them in adjacent slots
    const slots = [
      makeTimeSlot('s1', '2026-01-05', '09:00', '11:00'),
      makeTimeSlot('s2', '2026-01-05', '11:00', '13:00'), // 0 min gap with s1
      makeTimeSlot('s3', '2026-01-05', '14:00', '16:00'), // 60 min gap with s2
    ];
    const exams = [
      makeExam('e1', 'Exam 1', 'EX1', 120, 'g1', 50),
      makeExam('e2', 'Exam 2', 'EX2', 120, 'g1', 50),
    ];
    const solution = await solve({
      exams,
      rooms: baseRooms,
      timeSlots: slots,
      invigilators: baseInvs,
      studentGroups: baseGroups,
      config: {
        timeLimitMs: 5000,
        maxAlternatives: 1,
        objectiveWeights: {
          minimizeChangedExams: 10, minimizeRoomChanges: 8, minimizeCapacityWaste: 1,
          respectPreferredSlots: 5, balanceInvigilatorWorkload: 4,
        },
      },
      stopOnFirstFeasible: true,
      minGapMinutesBetweenExams: 60, // 1 hour gap required
    });
    expect(solution.feasible).toBe(true);
    // Verify the two exams are NOT in s1+s2 (0 gap)
    const a1 = solution.assignments.find((a) => a.examId === 'e1');
    const a2 = solution.assignments.find((a) => a.examId === 'e2');
    if (a1 && a2) {
      const forbiddenCombo = (a1.timeSlotId === 's1' && a2.timeSlotId === 's2') ||
                             (a1.timeSlotId === 's2' && a2.timeSlotId === 's1');
      expect(forbiddenCombo).toBe(false);
    }
  });
});

// --- Conflict detection tests ---

describe('Conflict Detection', () => {
  const ctx = {
    exams: [
      { ...makeExam('e1', 'Exam 1', 'EX1', 120, 'g1', 50), studentGroup: baseGroups[0] },
      { ...makeExam('e2', 'Exam 2', 'EX2', 120, 'g1', 50), studentGroup: baseGroups[0] },
      { ...makeExam('e3', 'Exam 3', 'EX3', 120, 'g2', 50), studentGroup: baseGroups[1] },
    ],
    rooms: baseRooms,
    timeSlots: baseSlots,
    invigilators: baseInvs,
    studentGroups: baseGroups,
  };

  test('detects room double-booking', () => {
    const assignments: AssignmentProposal[] = [
      { examId: 'e1', timeSlotId: 's1', roomId: 'r1', invigilatorIds: ['i1'] },
      { examId: 'e2', timeSlotId: 's1', roomId: 'r1', invigilatorIds: ['i2'] }, // same room, same slot
    ];
    const conflicts = detectConflicts({ assignments, context: ctx });
    expect(conflicts.some((c) => c.kind === 'room_double_booking')).toBe(true);
  });

  test('detects student group overlap', () => {
    const assignments: AssignmentProposal[] = [
      { examId: 'e1', timeSlotId: 's1', roomId: 'r1', invigilatorIds: ['i1'] },
      { examId: 'e2', timeSlotId: 's1', roomId: 'r2', invigilatorIds: ['i2'] }, // same group, same time
    ];
    const conflicts = detectConflicts({ assignments, context: ctx });
    expect(conflicts.some((c) => c.kind === 'student_group_overlap')).toBe(true);
  });

  test('detects room capacity violation', () => {
    const assignments: AssignmentProposal[] = [
      { examId: 'e1', timeSlotId: 's1', roomId: 'r3', invigilatorIds: ['i1'] }, // r3 cap=60, but exam enrollment=50... need a bigger exam
    ];
    // Use an exam with enrollment > 60
    const bigExam = { ...makeExam('e1', 'Big', 'BIG', 120, 'g1', 100), studentGroup: baseGroups[0] };
    const conflicts = detectConflicts({
      assignments,
      context: { ...ctx, exams: [bigExam] },
    });
    expect(conflicts.some((c) => c.kind === 'room_capacity_exceeded')).toBe(true);
  });

  test('detects invigilator double-booking', () => {
    const assignments: AssignmentProposal[] = [
      { examId: 'e1', timeSlotId: 's1', roomId: 'r1', invigilatorIds: ['i1'] },
      { examId: 'e3', timeSlotId: 's1', roomId: 'r2', invigilatorIds: ['i1'] }, // same invigilator, same time
    ];
    const conflicts = detectConflicts({ assignments, context: ctx });
    expect(conflicts.some((c) => c.kind === 'invigilator_double_booking')).toBe(true);
  });

  test('detects unavailable room usage', () => {
    const unavailableRoom = { ...baseRooms[0], isAvailable: false };
    const assignments: AssignmentProposal[] = [
      { examId: 'e1', timeSlotId: 's1', roomId: 'r1', invigilatorIds: ['i1'] },
    ];
    const conflicts = detectConflicts({
      assignments,
      context: { ...ctx, rooms: [unavailableRoom] },
    });
    expect(conflicts.some((c) => c.kind === 'unavailable_resource')).toBe(true);
  });

  test('detects incomplete assignment (no invigilator)', () => {
    const assignments: AssignmentProposal[] = [
      { examId: 'e1', timeSlotId: 's1', roomId: 'r1', invigilatorIds: [] },
    ];
    const conflicts = detectConflicts({ assignments, context: ctx });
    expect(conflicts.some((c) => c.kind === 'incomplete_assignment')).toBe(true);
  });

  test('returns no conflicts for a clean schedule', () => {
    const assignments: AssignmentProposal[] = [
      { examId: 'e1', timeSlotId: 's1', roomId: 'r1', invigilatorIds: ['i1'] },
      { examId: 'e2', timeSlotId: 's2', roomId: 'r2', invigilatorIds: ['i2'] }, // different slot, different room
      { examId: 'e3', timeSlotId: 's1', roomId: 'r2', invigilatorIds: ['i2'] }, // different group, different room
    ];
    const conflicts = detectConflicts({ assignments, context: ctx });
    expect(conflicts.filter((c) => c.severity === 'critical')).toHaveLength(0);
  });

  test('classifies severity correctly', () => {
    const assignments: AssignmentProposal[] = [
      { examId: 'e1', timeSlotId: 's1', roomId: 'r1', invigilatorIds: ['i1'] },
      { examId: 'e2', timeSlotId: 's1', roomId: 'r1', invigilatorIds: ['i2'] }, // critical: room double-booked
    ];
    const conflicts = detectConflicts({ assignments, context: ctx });
    const roomConflict = conflicts.find((c) => c.kind === 'room_double_booking');
    expect(roomConflict).toBeDefined();
    expect(roomConflict!.severity).toBe('critical');
  });
});
