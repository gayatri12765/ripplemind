
import os
import time
import json
import hmac
import base64
import hashlib
from uuid import uuid4

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, text


# --------------------------------------------------
# Configuration
# --------------------------------------------------

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

DATABASE_URL = os.getenv("DATABASE_URL")
AUTH_SECRET = os.getenv("RIPPLEMIND_TOKEN_SECRET", "")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "")

if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is missing from backend/.env")

if len(AUTH_SECRET) < 32:
    raise RuntimeError(
        "Set RIPPLEMIND_TOKEN_SECRET to a random secret of at least 32 characters."
    )

engine = create_engine(DATABASE_URL, pool_pre_ping=True)

app = FastAPI(
    title="RippleMind API",
    description="Rule-based exam timetable scheduling",
    version="1.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "http://localhost:5175",
        "http://127.0.0.1:5175",
        "http://localhost:5176",
        "http://127.0.0.1:5176",
        "http://localhost:5177",
        "http://127.0.0.1:5177",
        "http://localhost:5178",
        "http://127.0.0.1:5178",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------------------------------------------------
# Authentication helpers
# --------------------------------------------------

def hash_password(password):
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode(), salt, 310000
    )
    return base64.b64encode(salt + digest).decode()


def verify_password(password, stored):
    try:
        raw = base64.b64decode(stored)
        salt, expected = raw[:16], raw[16:]
        actual = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), salt, 310000
        )
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def make_token(subject, role):
    payload = {
        "sub": subject,
        "role": role,
        "exp": int(time.time()) + 43200,
    }
    body = base64.urlsafe_b64encode(
        json.dumps(payload).encode()
    ).decode().rstrip("=")
    signature = hmac.new(
        AUTH_SECRET.encode(), body.encode(), hashlib.sha256
    ).hexdigest()
    return f"{body}.{signature}"


def read_token(authorization):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Bearer token required.")

    token = authorization[7:].strip()

    try:
        body, signature = token.split(".", 1)
        expected = hmac.new(
            AUTH_SECRET.encode(), body.encode(), hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(signature, expected):
            raise ValueError("Invalid signature")

        payload = json.loads(
            base64.urlsafe_b64decode(body + "=" * (-len(body) % 4))
        )

        if payload.get("exp", 0) < time.time():
            raise HTTPException(401, "Token expired.")

        return payload
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(401, "Invalid token.")


def require_role(authorization, role):
    user = read_token(authorization)
    if user.get("role") != role:
        raise HTTPException(403, f"{role.capitalize()} access required.")
    return user


# --------------------------------------------------
# Database initialization
# --------------------------------------------------

@app.on_event("startup")
def setup_auth_tables():
    with engine.begin() as connection:
        connection.execute(text("""
            CREATE TABLE IF NOT EXISTS admin_accounts (
                username VARCHAR(100) PRIMARY KEY,
                password_hash TEXT NOT NULL
            )
        """))

        connection.execute(text("""
            CREATE TABLE IF NOT EXISTS students (
                student_id VARCHAR(100) PRIMARY KEY,
                full_name VARCHAR(200) NOT NULL,
                student_group VARCHAR(100) NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """))
        if ADMIN_PASSWORD:
            password_hash = hash_password(ADMIN_PASSWORD)

            connection.execute(
                text("""
                    INSERT INTO admin_accounts (username, password_hash)
                    VALUES (:u, :p)
                    ON CONFLICT (username)
                    DO UPDATE SET password_hash = EXCLUDED.password_hash
                """),
                {
                    "u": ADMIN_USERNAME,
                    "p": password_hash,
                },
            )
# --------------------------------------------------
# Request models
# --------------------------------------------------

class LoginInput(BaseModel):
    role: str
    identifier: str
    password: str


class StudentCreateInput(BaseModel):
    student_id: str = Field(min_length=1, max_length=100)
    full_name: str = Field(min_length=2, max_length=200)
    student_group: str = Field(min_length=1, max_length=100)
    password: str = Field(min_length=8, max_length=128)


class ExamInput(BaseModel):
    course_code: str = Field(min_length=1, max_length=40)
    course_name: str = Field(min_length=2, max_length=200)
    students: int = Field(gt=0, le=1000)
    group: str = Field(min_length=1, max_length=100)
    duration: int = Field(default=180, ge=30, le=360)
    priority: str = "Medium"


class ScenarioInput(BaseModel):
    available_slots: int = Field(default=6, ge=1, le=100)
    duration_buffer: int = Field(default=0, ge=0, le=120)
    prefer_larger_rooms: bool = True


class SimulationInput(ScenarioInput):
    outage_room_id: str | None = None
    outage_slot_id: str | None = None


class ApplySimulationInput(BaseModel):
    assignments: list[dict]


# --------------------------------------------------
# Database helpers
# --------------------------------------------------

def load_exams_from_db():
    with engine.connect() as connection:
        rows = connection.execute(text("""
            SELECT id, course_code, course_name, students,
                   student_group, duration, priority
            FROM exams ORDER BY course_code
        """)).mappings().all()

    return [{
        "id": r["id"],
        "course_code": r["course_code"],
        "course_name": r["course_name"],
        "students": r["students"],
        "group": r["student_group"],
        "duration": r["duration"],
        "priority": r["priority"],
    } for r in rows]


def load_rooms_from_db():
    with engine.connect() as connection:
        rows = connection.execute(text("""
            SELECT id, name, capacity, building FROM rooms ORDER BY id
        """)).mappings().all()
    return [dict(r) for r in rows]


def load_slots_from_db():
    with engine.connect() as connection:
        rows = connection.execute(text("""
            SELECT id, label, day FROM time_slots ORDER BY id
        """)).mappings().all()
    return [dict(r) for r in rows]


def load_schedule_from_db():
    with engine.connect() as connection:
        rows = connection.execute(text("""
            SELECT a.exam_id, e.course_code, e.course_name, e.students,
                   e.student_group AS "group", e.duration, e.priority,
                   a.room_id, r.name AS room_name, r.capacity AS room_capacity,
                   r.building, a.slot_id, s.label AS slot_label, s.day
            FROM assignments a
            JOIN exams e ON e.id = a.exam_id
            JOIN rooms r ON r.id = a.room_id
            JOIN time_slots s ON s.id = a.slot_id
            ORDER BY s.day, s.label, e.course_code
        """)).mappings().all()
    return [dict(r) for r in rows]


def save_schedule(assignments):
    with engine.begin() as connection:
        connection.execute(text("DELETE FROM assignments"))
        for item in assignments:
            connection.execute(text("""
                INSERT INTO assignments (exam_id, room_id, slot_id)
                VALUES (:exam_id, :room_id, :slot_id)
            """), {
                "exam_id": item["exam_id"],
                "room_id": item["room_id"],
                "slot_id": item["slot_id"],
            })


# --------------------------------------------------
# Rule-based timetable optimizer
# --------------------------------------------------

def build_schedule(exams, rooms, slots, prefer_larger=True, buffer=0):
    assignments, unassigned = [], []
    room_busy, group_busy = set(), set()
    rank = {"High": 0, "Medium": 1, "Low": 2}

    ordered = sorted(
        exams,
        key=lambda e: (
            rank.get(e.get("priority", "Medium"), 1),
            -int(e["students"]),
            -int(e["duration"]),
        ),
    )

    for exam in ordered:
        group = str(exam.get("group", "")).strip().casefold()
        students = int(exam["students"])
        duration = int(exam["duration"]) + buffer
        compatible_slots = []

        for slot in slots:
            try:
                parts = str(slot["label"]).replace("–", "-").split("-")
                start, end = [p.strip() for p in parts]
                start_min = int(start[:2]) * 60 + int(start[3:5])
                end_min = int(end[:2]) * 60 + int(end[3:5])
                slot_duration = end_min - start_min
            except (ValueError, IndexError):
                slot_duration = duration

            if slot_duration >= duration:
                compatible_slots.append(slot)

        placed = False

        for slot in compatible_slots:
            sid = slot["id"]
            if (group, sid) in group_busy:
                continue

            candidates = [
                room for room in rooms
                if int(room["capacity"]) >= students
                and (room["id"], sid) not in room_busy
            ]
            candidates.sort(
                key=lambda r: int(r["capacity"]),
                reverse=not prefer_larger,
            )

            if not candidates:
                continue

            room = candidates[0]
            assignments.append({
                "exam_id": exam["id"],
                "course_code": exam["course_code"],
                "course_name": exam["course_name"],
                "students": students,
                "group": exam.get("group", ""),
                "duration": int(exam["duration"]),
                "priority": exam.get("priority", "Medium"),
                "room_id": room["id"],
                "room_name": room["name"],
                "room_capacity": int(room["capacity"]),
                "building": room.get("building"),
                "slot_id": sid,
                "slot_label": slot["label"],
                "day": slot["day"],
            })
            room_busy.add((room["id"], sid))
            group_busy.add((group, sid))
            placed = True
            break

        if not placed:
            unassigned.append({
                "exam_id": exam["id"],
                "course_code": exam["course_code"],
                "course_name": exam["course_name"],
                "reason": "No compatible room and time slot for this exam.",
            })

    return assignments, unassigned


def calculate_metrics(assignments, exams, rooms, slots, unassigned):
    total_capacity = sum(int(r["capacity"]) for r in rooms)
    seat_usage = sum(int(a["students"]) for a in assignments)
    room_slots = max(1, len(rooms) * len(slots))

    return {
        "scheduled": len(assignments),
        "total": len(exams),
        "unassigned": len(unassigned),
        "conflicts_before": 0,
        "conflicts_after": 0,
        "room_utilization": round(len(assignments) / room_slots * 100),
        "seat_utilization": round(
            seat_usage / max(1, total_capacity * len(slots)) * 100
        ),
        "slots_used": len({a["slot_id"] for a in assignments}),
    }


# --------------------------------------------------
# Authentication endpoints
# --------------------------------------------------

@app.post("/api/auth/login")
def login(data: LoginInput):
    if data.role == "admin":
        with engine.connect() as connection:
            row = connection.execute(text("""
                SELECT username, password_hash
                FROM admin_accounts WHERE username=:u
            """), {"u": data.identifier}).mappings().first()

        if not row or not verify_password(data.password, row["password_hash"]):
            raise HTTPException(401, "Invalid username or password.")

        subject = row["username"]

    elif data.role == "student":
        with engine.connect() as connection:
            row = connection.execute(text("""
                SELECT student_id, password_hash
                FROM students WHERE student_id=:s
            """), {"s": data.identifier}).mappings().first()

        if not row or not verify_password(data.password, row["password_hash"]):
            raise HTTPException(401, "Invalid student ID or password.")

        subject = row["student_id"]

    else:
        raise HTTPException(400, "Role must be admin or student.")

    return {
        "access_token": make_token(subject, data.role),
        "token_type": "bearer",
        "user": {"id": subject, "role": data.role},
    }


@app.get("/api/auth/me")
def who_am_i(authorization: str | None = Header(default=None)):
    user = read_token(authorization)
    return {"id": user["sub"], "role": user["role"]}


@app.post("/api/students")
def create_student(
    data: StudentCreateInput,
    authorization: str | None = Header(default=None),
):
    require_role(authorization, "admin")

    student_id = data.student_id.strip()
    with engine.begin() as connection:
        exists = connection.execute(text("""
            SELECT student_id FROM students WHERE student_id=:s
        """), {"s": student_id}).first()

        if exists:
            raise HTTPException(409, "Student ID already exists.")

        connection.execute(text("""
            INSERT INTO students
            (student_id, full_name, student_group, password_hash)
            VALUES (:s, :n, :g, :p)
        """), {
            "s": student_id,
            "n": data.full_name.strip(),
            "g": data.student_group.strip(),
            "p": hash_password(data.password),
        })

    return {"created": True, "student_id": student_id}


@app.get("/api/students")
def list_students(authorization: str | None = Header(default=None)):
    require_role(authorization, "admin")
    with engine.connect() as connection:
        rows = connection.execute(text("""
            SELECT student_id, full_name, student_group, created_at
            FROM students ORDER BY student_id
        """)).mappings().all()
    return [dict(r) for r in rows]


@app.get("/api/student/schedule")
def student_schedule(authorization: str | None = Header(default=None)):
    user = require_role(authorization, "student")

    with engine.connect() as connection:
        student = connection.execute(text("""
            SELECT student_id, full_name, student_group
            FROM students WHERE student_id=:s
        """), {"s": user["sub"]}).mappings().first()

    if not student:
        raise HTTPException(404, "Student account not found.")

    group = student["student_group"].strip().casefold()
    schedule = load_schedule_from_db()
    personal_schedule = [
        item for item in schedule
        if str(item.get("group", "")).strip().casefold() == group
        or str(item.get("group", "")).strip().casefold() == "all-eng"
    ]

    return {
        "student": {
            "student_id": student["student_id"],
            "full_name": student["full_name"],
            "student_group": student["student_group"],
        },
        "schedule": personal_schedule,
    }


# --------------------------------------------------
# Existing RippleMind API endpoints
# --------------------------------------------------

@app.get("/")
def home():
    return {"name": "RippleMind API", "status": "running", "docs": "/docs"}


@app.get("/api/health")
def health():
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        return {"status": "healthy", "database": "connected"}
    except Exception as exc:
        raise HTTPException(503, detail=f"Database connection failed: {exc}")


@app.get("/api/overview")
def overview():
    exams = load_exams_from_db()
    rooms = load_rooms_from_db()
    slots = load_slots_from_db()
    schedule = load_schedule_from_db()
    return {
        "total_exams": len(exams),
        "scheduled_exams": len(schedule),
        "unscheduled_exams": max(0, len(exams) - len(schedule)),
        "rooms": len(rooms),
        "slots": len(slots),
        "conflicts": 0,
        "room_utilization": round(
            len(schedule) / max(1, len(rooms) * len(slots)) * 100
        ),
    }


@app.get("/api/exams")
def get_exams():
    try:
        return load_exams_from_db()
    except Exception as exc:
        raise HTTPException(500, detail=str(exc))


@app.post("/api/exams")
def add_exam(
    payload: ExamInput,
    authorization: str | None = Header(default=None),
):
    require_role(authorization, "admin")
    exam_id = "E" + uuid4().hex[:8].upper()

    try:
        with engine.begin() as connection:
            exists = connection.execute(text("""
                SELECT id FROM exams
                WHERE LOWER(course_code)=LOWER(:c)
            """), {"c": payload.course_code.strip()}).first()

            if exists:
                raise HTTPException(409, "Course code already exists.")

            connection.execute(text("""
                INSERT INTO exams
                (id, course_code, course_name, students,
                 student_group, duration, priority)
                VALUES (:id, :c, :n, :s, :g, :d, :p)
            """), {
                "id": exam_id,
                "c": payload.course_code.strip().upper(),
                "n": payload.course_name.strip(),
                "s": payload.students,
                "g": payload.group.strip(),
                "d": payload.duration,
                "p": payload.priority,
            })

        return {
            "id": exam_id,
            "course_code": payload.course_code.strip().upper(),
            "course_name": payload.course_name.strip(),
            "students": payload.students,
            "group": payload.group.strip(),
            "duration": payload.duration,
            "priority": payload.priority,
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, detail=str(exc))


@app.delete("/api/exams/{exam_id}")
def delete_exam(
    exam_id: str,
    authorization: str | None = Header(default=None),
):
    require_role(authorization, "admin")
    try:
        with engine.begin() as connection:
            exists = connection.execute(text(
                "SELECT id FROM exams WHERE id=:id"
            ), {"id": exam_id}).first()

            if not exists:
                raise HTTPException(404, "Exam not found.")

            connection.execute(text(
                "DELETE FROM assignments WHERE exam_id=:id"
            ), {"id": exam_id})
            connection.execute(text(
                "DELETE FROM exams WHERE id=:id"
            ), {"id": exam_id})

        return {"deleted": exam_id}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, detail=str(exc))


@app.get("/api/rooms")
def get_rooms():
    try:
        return load_rooms_from_db()
    except Exception as exc:
        raise HTTPException(500, detail=str(exc))


@app.get("/api/slots")
def get_slots():
    try:
        return load_slots_from_db()
    except Exception as exc:
        raise HTTPException(500, detail=str(exc))


@app.get("/api/schedule")
def get_schedule():
    try:
        return {"schedule": load_schedule_from_db(), "unassigned": []}
    except Exception as exc:
        raise HTTPException(500, detail=str(exc))


@app.post("/api/optimize")
def optimize(
    payload: ScenarioInput,
    authorization: str | None = Header(default=None),
):
    require_role(authorization, "admin")

    try:
        exams = load_exams_from_db()
        rooms = load_rooms_from_db()
        all_slots = load_slots_from_db()

        if not exams:
            raise HTTPException(400, "No exams found in the database.")
        if not rooms:
            raise HTTPException(400, "No rooms found in the database.")
        if not all_slots:
            raise HTTPException(400, "No time slots found in the database.")

        slots = all_slots[:payload.available_slots]
        assignments, unassigned = build_schedule(
            exams, rooms, slots,
            payload.prefer_larger_rooms, payload.duration_buffer
        )
        save_schedule(assignments)

        metrics = calculate_metrics(
            assignments, exams, rooms, slots, unassigned
        )
        return {
            "schedule": assignments,
            "unassigned": unassigned,
            "conflicts": [],
            "metrics": metrics,
            "explanations": [
                f"Processed {len(exams)} exams using a rule-based scheduler.",
                "Room capacity must be sufficient for each exam.",
                "Exams in the same student group cannot share a time slot.",
                f"{len(assignments)} scheduled; {len(unassigned)} unassigned.",
            ],
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, detail=str(exc))


# --------------------------------------------------
# Validation, what-if simulation, and scenario comparison
# --------------------------------------------------

def validate_assignments(assignments, exams, rooms, slots):
    """Return concrete hard-constraint violations for a proposed schedule."""
    exam_by_id = {str(e["id"]): e for e in exams}
    room_by_id = {str(r["id"]): r for r in rooms}
    slot_by_id = {str(s["id"]): s for s in slots}
    issues = []
    seen_rooms = set()
    seen_groups = set()
    seen_exams = set()

    for item in assignments:
        exam_id = str(item.get("exam_id", item.get("id", "")))
        room_id = str(item.get("room_id", ""))
        slot_id = str(item.get("slot_id", ""))
        exam = exam_by_id.get(exam_id)
        room = room_by_id.get(room_id)
        slot = slot_by_id.get(slot_id)

        if not exam:
            issues.append({"type": "unknown_exam", "exam_id": exam_id, "message": "Assignment references an unknown exam."})
            continue
        if exam_id in seen_exams:
            issues.append({"type": "duplicate_exam", "exam_id": exam_id, "message": f"{exam['course_code']} is assigned more than once."})
        seen_exams.add(exam_id)

        if not room:
            issues.append({"type": "unknown_room", "exam_id": exam_id, "message": "Assignment references an unknown room."})
            continue
        if not slot:
            issues.append({"type": "unknown_slot", "exam_id": exam_id, "message": "Assignment references an unknown time slot."})
            continue

        if int(room["capacity"]) < int(exam["students"]):
            issues.append({"type": "capacity", "exam_id": exam_id, "message": f"{exam['course_code']} needs {exam['students']} seats but {room['name']} has {room['capacity']}."})

        room_key = (room_id, slot_id)
        if room_key in seen_rooms:
            issues.append({"type": "room_collision", "exam_id": exam_id, "message": f"{room['name']} is already assigned in this slot."})
        seen_rooms.add(room_key)

        group = str(exam.get("group", exam.get("student_group", ""))).strip().casefold()
        group_key = (group, slot_id)
        if group and group_key in seen_groups:
            issues.append({"type": "group_collision", "exam_id": exam_id, "message": f"Another exam for group {group} is scheduled in this slot."})
        seen_groups.add(group_key)

        try:
            label = str(slot["label"]).replace("–", "-")
            start, end = [x.strip() for x in label.split("-", 1)]
            minutes = (int(end[:2]) * 60 + int(end[3:5])) - (int(start[:2]) * 60 + int(start[3:5]))
            if minutes < int(exam["duration"]):
                issues.append({"type": "duration", "exam_id": exam_id, "message": f"{exam['course_code']} duration exceeds the slot length."})
        except (ValueError, IndexError):
            # Unknown label format is reported as unverifiable rather than silently rejected.
            issues.append({"type": "duration_unverified", "exam_id": exam_id, "message": f"Could not verify duration for slot {slot['label']}."})

    return issues


def schedule_score(assignments, unassigned, issues, original):
    changed = 0
    old = {str(a.get("exam_id")): (str(a.get("room_id")), str(a.get("slot_id"))) for a in original}
    for a in assignments:
        eid = str(a.get("exam_id"))
        if eid in old and old[eid] != (str(a.get("room_id")), str(a.get("slot_id"))):
            changed += 1
    return {
        "scheduled": len(assignments),
        "unassigned": len(unassigned),
        "hard_conflicts": len(issues),
        "changed_assignments": changed,
        "score": len(assignments) * 100 - len(unassigned) * 100 - len(issues) * 1000 - changed * 5,
    }


@app.get("/api/validate")
def validate_schedule(authorization: str | None = Header(default=None)):
    require_role(authorization, "admin")
    exams, rooms, slots = load_exams_from_db(), load_rooms_from_db(), load_slots_from_db()
    schedule = load_schedule_from_db()
    issues = validate_assignments(schedule, exams, rooms, slots)
    return {"valid": not issues, "conflict_count": len(issues), "conflicts": issues}


@app.post("/api/simulate")
def simulate(payload: SimulationInput, authorization: str | None = Header(default=None)):
    """Build a candidate schedule in memory only. This endpoint never writes assignments."""
    require_role(authorization, "admin")
    exams = load_exams_from_db()
    rooms = load_rooms_from_db()
    all_slots = load_slots_from_db()
    original = load_schedule_from_db()
    if not exams or not rooms or not all_slots:
        raise HTTPException(400, "Add exams, rooms, and time slots before simulating.")

    available_slots = all_slots[:payload.available_slots]
    usable_rooms = [r for r in rooms if str(r["id"]) != str(payload.outage_room_id)]
    usable_slots = [s for s in available_slots if str(s["id"]) != str(payload.outage_slot_id)]
    candidate, unassigned = build_schedule(
        exams, usable_rooms, usable_slots,
        payload.prefer_larger_rooms, payload.duration_buffer
    )
    issues = validate_assignments(candidate, exams, usable_rooms, usable_slots)
    before = validate_assignments(original, exams, rooms, all_slots)
    affected = []
    old_map = {str(a.get("exam_id")): a for a in original}
    new_map = {str(a.get("exam_id")): a for a in candidate}
    for exam in exams:
        eid = str(exam["id"])
        old, new = old_map.get(eid), new_map.get(eid)
        if old and (not new or str(old.get("room_id")) != str(new.get("room_id")) or str(old.get("slot_id")) != str(new.get("slot_id"))):
            affected.append({
                "exam_id": eid,
                "course_code": exam["course_code"],
                "previous_room": old.get("room_name"),
                "previous_slot": old.get("slot_label"),
                "new_room": new.get("room_name") if new else None,
                "new_slot": new.get("slot_label") if new else None,
                "status": "moved" if new else "unassigned",
            })
        elif not old and new:
            affected.append({"exam_id": eid, "course_code": exam["course_code"], "status": "newly_assigned", "new_room": new.get("room_name"), "new_slot": new.get("slot_label")})
    return {
        "saved": False,
        "message": "Simulation only: the live timetable has not been changed.",
        "schedule": candidate,
        "unassigned": unassigned,
        "conflicts": issues,
        "previous_conflicts": before,
        "affected": affected,
        "metrics": schedule_score(candidate, unassigned, issues, original),
        "explanations": [
            f"Candidate schedules {len(candidate)} of {len(exams)} exams.",
            f"{len(affected)} exam assignments would change.",
            f"{len(issues)} hard-constraint violations found in the candidate.",
            "The simulation is not saved until an administrator explicitly applies it."
        ],
    }


@app.post("/api/scenarios")
def compare_scenarios(payload: ScenarioInput, authorization: str | None = Header(default=None)):
    """Compare different scheduling strategies without saving any of them."""
    require_role(authorization, "admin")
    exams, rooms, all_slots = load_exams_from_db(), load_rooms_from_db(), load_slots_from_db()
    original = load_schedule_from_db()
    if not exams or not rooms or not all_slots:
        raise HTTPException(400, "Add exams, rooms, and time slots before comparing scenarios.")
    slots = all_slots[:payload.available_slots]
    candidates = []
    for name, prefer_larger, buffer in [
        ("Minimal room fit", False, payload.duration_buffer),
        ("Larger-room preference", True, payload.duration_buffer),
        ("Extra 15-minute buffer", payload.prefer_larger_rooms, min(120, payload.duration_buffer + 15)),
    ]:
        schedule, unassigned = build_schedule(exams, rooms, slots, prefer_larger, buffer)
        conflicts = validate_assignments(schedule, exams, rooms, slots)
        candidates.append({
            "name": name,
            "schedule": schedule,
            "unassigned": unassigned,
            "conflicts": conflicts,
            "metrics": schedule_score(schedule, unassigned, conflicts, original),
        })
    candidates.sort(key=lambda c: (c["metrics"]["hard_conflicts"], c["metrics"]["unassigned"], c["metrics"]["changed_assignments"]))
    return {"saved": False, "scenarios": candidates, "recommended": candidates[0]["name"]}


@app.post("/api/apply-simulation")
def apply_simulation(payload: ApplySimulationInput, authorization: str | None = Header(default=None)):
    """Persist only a conflict-free schedule after explicit administrator confirmation."""
    require_role(authorization, "admin")
    exams, rooms, slots = load_exams_from_db(), load_rooms_from_db(), load_slots_from_db()
    issues = validate_assignments(payload.assignments, exams, rooms, slots)
    if issues:
        raise HTTPException(422, detail={"message": "Schedule rejected: hard constraints failed.", "conflicts": issues})
    exam_ids = {str(e["id"]) for e in exams}
    submitted_ids = {str(a.get("exam_id", "")) for a in payload.assignments}
    if not submitted_ids.issubset(exam_ids):
        raise HTTPException(422, "Schedule contains unknown exams.")
    # Normalize the schedule rows expected by save_schedule.
    save_schedule([{"exam_id": a["exam_id"], "room_id": a["room_id"], "slot_id": a["slot_id"]} for a in payload.assignments])
    return {"saved": True, "assigned": len(payload.assignments), "message": "Validated timetable saved."}
