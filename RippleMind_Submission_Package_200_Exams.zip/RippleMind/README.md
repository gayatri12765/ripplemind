# RippleMind — Examination Scheduling Platform

RippleMind is a React/Vite frontend with a FastAPI backend and PostgreSQL storage. This package combines the current UI and backend updates, including CORS support for Vite ports 5173–5178, timetable optimization endpoints, simulation/scenario endpoints, and role-aware student/admin flows.

## Important status note

This package has **not** been verified end-to-end against your local PostgreSQL instance and browser. The frontend login was previously observed to remain in a loading state; if that persists, inspect the browser DevTools Network/Console and the FastAPI terminal. Do not present this as a fully tested deployment until login, database writes, scheduling, simulation, and student access have been verified.

## Requirements
- Python 3.11+ recommended
- Node.js 20+ and npm
- PostgreSQL 14+ with a database named `ripplemind`

## Setup (Windows PowerShell)

1. Create a PostgreSQL database named `ripplemind` in pgAdmin.
2. In this `backend` folder, copy `.env.example` to `.env` and set your actual PostgreSQL password, admin password, and a random token secret of at least 32 characters. URL-encode special characters in the database password.
3. Open a terminal in `backend` and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

4. Open a second terminal in `frontend` and run:

```powershell
npm install
npm run dev
```

5. Open the URL Vite prints (it may use `5173`, `5174`, etc. if a port is busy). CORS is configured for localhost and 127.0.0.1 on ports 5173–5178.
6. API docs: http://127.0.0.1:8000/docs

## Login
The backend admin account uses `ADMIN_USERNAME` and `ADMIN_PASSWORD` from `.env`. Use the credentials configured for your original environment. Do not assume a default password works unless the backend/database setup has actually created that account. Student accounts must exist in the database and use the backend's expected login payload.

## Safety
- Never commit `.env` or share screenshots containing secrets.
- Rotate any database password/token secret that was exposed in screenshots.
- Back up the project and database before changing schemas or replacing source files.


## Included sample dataset and feature inventory

The `data/` directory includes a synthetic evaluation dataset: 200 exams, 20 rooms, and 30 time slots. These are reproducible sample records, not an export of an existing local database. The seed script refuses to write into non-empty tables.

Implemented API/UI areas in this package include: administrator/student login flow; exam, room, and slot data views; timetable optimization; hard-constraint validation; unassigned-exam reporting; what-if simulation that previews without saving; affected-assignment/ripple reporting; minimal-change scoring; candidate scenario comparison; explicit validation before applying a candidate; student-group timetable view; CSV export; and responsive layout.

## Sample data (optional)

Back up your database first. For a clean test database, configure `backend/.env` and run from the project root:

```powershell
python data/seed_dataset.py
```

The script only inserts into empty `exams`, `rooms`, and `time_slots` tables. It does not overwrite existing data.
