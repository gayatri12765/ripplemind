# RippleMind sample scheduling dataset

This folder contains a **synthetic sample dataset** with 200 exam records, 20 rooms, and 30 time slots. It is intended for repeatable evaluation and demonstrations. It is not a copy of the records in your local PostgreSQL database.

Files:
- `exams_200.csv` — 200 sample exam/course rows
- `rooms_20.csv` — 20 room rows
- `time_slots_30.csv` — 30 time-slot rows
- `seed_dataset.py` — inserts the CSV rows into an empty existing RippleMind database

To seed safely, first back up your database. Configure `backend/.env`, install backend dependencies, then from the project root run `python data/seed_dataset.py`. The script refuses to run if `exams`, `rooms`, or `time_slots` already contain any records; it does not delete existing data. Use a separate empty database for the sample dataset.
