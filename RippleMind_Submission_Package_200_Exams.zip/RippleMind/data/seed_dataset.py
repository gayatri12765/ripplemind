"""Seed the sample 200-exam / 20-room / 30-slot dataset into an existing RippleMind database.

Safety: by default this script refuses to run if any of the three data tables already
contain rows. It never deletes existing data. Run from backend after setting backend/.env.
"""
import csv, os, sys
from pathlib import Path
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
load_dotenv(PROJECT / "backend" / ".env")
url = os.getenv("DATABASE_URL")
if not url:
    raise SystemExit("DATABASE_URL missing. Configure backend/.env first.")
engine = create_engine(url, pool_pre_ping=True)

def read_csv(name):
    with (HERE / name).open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

exams = read_csv("exams_200.csv")
rooms = read_csv("rooms_20.csv")
slots = read_csv("time_slots_30.csv")
with engine.begin() as conn:
    counts = {
        "exams": conn.execute(text("SELECT COUNT(*) FROM exams")).scalar_one(),
        "rooms": conn.execute(text("SELECT COUNT(*) FROM rooms")).scalar_one(),
        "time_slots": conn.execute(text("SELECT COUNT(*) FROM time_slots")).scalar_one(),
    }
    if any(counts.values()):
        raise SystemExit(f"Refusing to seed because tables already contain data: {counts}. Back up your DB and use an empty database for this sample dataset.")
    conn.execute(text("""INSERT INTO exams (id, course_code, course_name, students, student_group, duration, priority)
        VALUES (:id, :course_code, :course_name, :students, :student_group, :duration, :priority)"""), exams)
    conn.execute(text("""INSERT INTO rooms (id, name, capacity, building)
        VALUES (:id, :name, :capacity, :building)"""), rooms)
    conn.execute(text("""INSERT INTO time_slots (id, label, day)
        VALUES (:id, :label, :day)"""), slots)
print("Sample dataset inserted successfully: 200 exams, 20 rooms, 30 time slots.")
print("These are synthetic sample records, not a backup of any pre-existing local database.")
