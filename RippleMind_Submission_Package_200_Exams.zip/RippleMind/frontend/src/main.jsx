
import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Activity, CalendarDays, CheckCircle2, ChevronDown, CircleAlert,
  Clock3, GraduationCap, LayoutDashboard, Plus, RefreshCw, Search,
  Settings2, Sparkles, Trash2, Users, Building2, ArrowUpRight,
  Menu, X, Download
} from 'lucide-react';
import './styles.css';

const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000/api';

const fallbackExams = [
  { id: 'E101', course_code: 'CSE301', course_name: 'Design and Analysis of Algorithms', students: 105, group: 'CSE-A', duration: 180, priority: 'High' },
  { id: 'E102', course_code: 'CSE302', course_name: 'Database Management Systems', students: 78, group: 'CSE-A', duration: 180, priority: 'High' },
  { id: 'E103', course_code: 'CSE303', course_name: 'Computer Networks', students: 54, group: 'CSE-B', duration: 180, priority: 'Medium' },
  { id: 'E104', course_code: 'CSE304', course_name: 'Theory of Computation', students: 72, group: 'CSE-A', duration: 180, priority: 'Medium' },
  { id: 'E105', course_code: 'MAT201', course_name: 'Discrete Mathematics', students: 115, group: 'ALL-ENG', duration: 180, priority: 'High' },
  { id: 'E106', course_code: 'ECE210', course_name: 'Digital Systems', students: 36, group: 'ECE-A', duration: 120, priority: 'Low' },
  { id: 'E107', course_code: 'CSE305', course_name: 'Operating Systems', students: 58, group: 'CSE-B', duration: 180, priority: 'Medium' }
];

const fallbackRooms = [
  { id: 'R101', name: 'Block A · 101', capacity: 120 },
  { id: 'R102', name: 'Block A · 102', capacity: 80 },
  { id: 'R201', name: 'Block B · 201', capacity: 60 },
  { id: 'LAB1', name: 'Computer Lab 1', capacity: 40 }
];

const fallbackSlots = [
  { id: 'S1', label: '09:00 – 12:00', day: 'Monday' },
  { id: 'S2', label: '13:00 – 16:00', day: 'Monday' },
  { id: 'S3', label: '09:00 – 12:00', day: 'Tuesday' },
  { id: 'S4', label: '13:00 – 16:00', day: 'Tuesday' },
  { id: 'S5', label: '09:00 – 12:00', day: 'Wednesday' },
  { id: 'S6', label: '13:00 – 16:00', day: 'Wednesday' }
];


async function api(path, options = {}) {
  const token = localStorage.getItem('ripplemind_token');

  const res = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });

  if (!res.ok) {
    let data = {};
    try { data = await res.json(); } catch {}
    throw new Error(data.detail || `Request failed (${res.status})`);
  }

  return res.json();
}


function asArray(value) {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.items)) return value.items;
  if (Array.isArray(value?.data)) return value.data;
  return [];
}

function Login({ onLogin }) {
  const [role, setRole] = useState('admin');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch(`${API}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role, identifier, password }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail || 'Login failed');
      }

      localStorage.setItem('ripplemind_token', data.access_token);
      localStorage.setItem('ripplemind_user', JSON.stringify(data.user));
      onLogin(data.user);
    } catch (err) {
      setError(err instanceof TypeError ? 'Cannot reach the backend. Keep FastAPI running at http://127.0.0.1:8000 and check the browser URL.' : (err.message || 'Could not connect to RippleMind API'));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-screen">
      <form className="login-card" onSubmit={submit}>
        <div className="brand-mark"><Activity size={24} /></div>
        <h1>RippleMind</h1>
        <p>Sign in to your examination workspace</p>

        <label>Sign in as</label>
        <select value={role} onChange={e => setRole(e.target.value)}>
          <option value="admin">Administrator</option>
          <option value="student">Student</option>
        </select>

        <label>{role === 'admin' ? 'Username' : 'Student ID'}</label>
        <input
          required
          value={identifier}
          onChange={e => setIdentifier(e.target.value)}
          placeholder={role === 'admin' ? 'Admin username' : 'Your student ID'}
        />

        <label>Password</label>
        <input
          required
          type="password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          placeholder="Enter your password"
        />

        {error && <div className="alert">{error}</div>}

        <button className="btn primary" type="submit" disabled={loading}>
          {loading ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </div>
  );
}

function StudentDashboard({ user, onLogout }) {
  const [activePage, setActivePage] = useState('Overview');
  const [student, setStudent] = useState(null);
  const [schedule, setSchedule] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api('/student/schedule')
      .then(data => {
        setStudent(data.student);
        setSchedule(data.schedule || []);
      })
      .catch(err => setError(err.message || 'Unable to load timetable'))
      .finally(() => setLoading(false));
  }, []);

  const upcoming = schedule;

  function addTask(e) {
    e.preventDefault();
    if (!newTask.trim()) return;

    setTasks(old => [
      ...old,
      { id: Date.now(), title: newTask.trim(), done: false }
    ]);
    setNewTask('');
  }

  function toggleTask(id) {
    setTasks(old =>
      old.map(task =>
        task.id === id ? { ...task, done: !task.done } : task
      )
    );
  }

  return (
    <div className="student-screen">
      <aside className="student-sidebar">
        <div className="student-brand">
          <div className="brand-mark"><Activity size={22} /></div>
          <div><strong>RippleMind</strong><span>STUDENT PORTAL</span></div>
        </div>

        <nav className="student-nav">
          {[
            ['Overview', 'Overview'],
            ['My Timetable', 'My Timetable'],
            ['Exam Calendar', 'Exam Calendar'],
            ['Study Planner', 'Study Planner'],
            ['Notifications', 'Notifications'],
            ['My Profile', 'My Profile']
          ].map(([label, value]) => (
            <button
              key={value}
              className={activePage === value ? 'active' : ''}
              onClick={() => setActivePage(value)}
            >
              {label}
            </button>
          ))}
        </nav>

        <div className="student-sidebar-bottom">
          <div>
            <strong>{student?.full_name || user.id}</strong>
            <span>{student?.student_group || 'Student'}</span>
          </div>
          <button className="btn secondary" onClick={onLogout}>
            Sign out
          </button>
        </div>
      </aside>

      <main className="student-main">
        <header className="student-topbar">
          <span>Student Workspace / {activePage}</span>
          <span>{student?.student_id || user.id}</span>
        </header>

        <div className="student-content">
          {error && <div className="alert">{error}</div>}

          {activePage === 'Overview' && (
            <>
              <div className="eyebrow">YOUR ACADEMIC SPACE</div>
              <h1>
                Welcome, {student?.full_name || 'Student'}
              </h1>
              <p className="student-subtitle">
                Keep track of your exams and prepare with confidence.
              </p>

              <div className="student-cards">
                <div className="student-stat">
                  <span>Scheduled exams</span>
                  <strong>{schedule.length}</strong>
                </div>
                <div className="student-stat">
                  <span>Revision tasks</span>
                  <strong>{tasks.length}</strong>
                </div>
                <div className="student-stat">
                  <span>Tasks completed</span>
                  <strong>{tasks.filter(t => t.done).length}</strong>
                </div>
              </div>

              <section className="student-panel">
                <h2>Upcoming examinations</h2>
                {loading ? <p>Loading your timetable…</p> :
                  upcoming.length === 0 ? (
                    <p>No exams are assigned to your group yet.</p>
                  ) : upcoming.slice(0, 4).map(exam => (
                    <div className="student-exam" key={exam.exam_id}>
                      <div>
                        <strong>{exam.course_code} · {exam.course_name}</strong>
                        <span>{exam.day} · {exam.slot_label}</span>
                      </div>
                      <span>{exam.room_name}</span>
                    </div>
                  ))}
                <button className="btn secondary"
                  onClick={() => setActivePage('My Timetable')}>
                  View full timetable
                </button>
              </section>
            </>
          )}

          {activePage === 'My Timetable' && (
            <section className="student-panel">
              <h1>My Exam Timetable</h1>
              <p>Your assigned examinations and room details.</p>
              {loading ? <p>Loading…</p> :
                schedule.length === 0 ? <p>No scheduled exams found for your group.</p> :
                  <div className="student-table-wrap">
                    <table>
                      <thead><tr>
                        <th>Course</th><th>Day</th><th>Time</th>
                        <th>Room</th><th>Building</th>
                      </tr></thead>
                      <tbody>{schedule.map(exam => (
                        <tr key={`${exam.exam_id}-${exam.slot_id}`}>
                          <td>{exam.course_code} — {exam.course_name}</td>
                          <td>{exam.day}</td><td>{exam.slot_label}</td>
                          <td>{exam.room_name}</td><td>{exam.building || '—'}</td>
                        </tr>
                      ))}</tbody>
                    </table>
                  </div>}
            </section>
          )}

          {activePage === 'Exam Calendar' && (
            <section className="student-panel">
              <h1>Exam Calendar</h1>
              <p>Your scheduled exams grouped by day.</p>
              {schedule.length === 0 ? <p>No exams to display.</p> :
                [...new Set(schedule.map(exam => exam.day))].map(day => (
                  <div key={day} className="student-calendar-day">
                    <h3>{day}</h3>
                    {schedule.filter(exam => exam.day === day).map(exam => (
                      <div className="student-exam" key={exam.exam_id}>
                        <div><strong>{exam.course_code} — {exam.course_name}</strong>
                          <span>{exam.slot_label}</span></div>
                        <span>{exam.room_name}</span>
                      </div>
                    ))}
                  </div>
                ))}
            </section>
          )}

          {activePage === 'Study Planner' && (
            <section className="student-panel">
              <h1>Study Planner</h1>
              <p>Create revision tasks and track your progress.</p>
              <form className="student-task-form" onSubmit={addTask}>
                <input value={newTask}
                  onChange={e => setNewTask(e.target.value)}
                  placeholder="e.g. Revise database normalization"
                  required />
                <button className="btn primary" type="submit">Add task</button>
              </form>
              {tasks.length === 0 && <p>No study tasks yet. Add your first revision task.</p>}
              {tasks.map(task => (
                <label className="student-task" key={task.id}>
                  <input type="checkbox" checked={task.done}
                    onChange={() => toggleTask(task.id)} />
                  <span className={task.done ? 'done' : ''}>{task.title}</span>
                </label>
              ))}
            </section>
          )}

          {activePage === 'Notifications' && (
            <section className="student-panel">
              <h1>Notifications</h1>
              <p>Updates based on your current timetable.</p>
              {schedule.length === 0 ? <p>No exam updates available.</p> :
                schedule.map(exam => (
                  <div className="student-exam" key={exam.exam_id}>
                    <div><strong>{exam.course_code} scheduled</strong>
                      <span>{exam.day} · {exam.slot_label}</span></div>
                    <span>{exam.room_name}</span>
                  </div>
                ))}
            </section>
          )}

          {activePage === 'My Profile' && (
            <section className="student-panel">
              <h1>My Profile</h1>
              <div className="student-profile-row">
                <span>Full name</span><strong>{student?.full_name || '—'}</strong>
              </div>
              <div className="student-profile-row">
                <span>Student ID</span><strong>{student?.student_id || user.id}</strong>
              </div>
              <div className="student-profile-row">
                <span>Student group</span><strong>{student?.student_group || '—'}</strong>
              </div>
              <button className="btn secondary" onClick={onLogout}>Sign out</button>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}

function App() {
  const [user, setUser] = useState(() => {
  try {
    return JSON.parse(localStorage.getItem('ripplemind_user') || 'null');
  } catch {
    return null;
  }
});
  const [page, setPage] = useState('Overview');
  const [exams, setExams] = useState(fallbackExams);
  const [rooms, setRooms] = useState(fallbackRooms);
  const [slots, setSlots] = useState(fallbackSlots);
  const [schedule, setSchedule] = useState([]);
  const [unassigned, setUnassigned] = useState([]);
  const [metrics, setMetrics] = useState(null);
  const [explanations, setExplanations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [scenario, setScenario] = useState({
    available_slots: 6,
    duration_buffer: 0,
    prefer_larger_rooms: true
  });
  const [form, setForm] = useState({
    course_code: '',
    course_name: '',
    students: 60,
    group: 'CSE-A',
    duration: 180,
    priority: 'Medium'
  });

  // Load each endpoint independently so one failed request
  // does not prevent the other data from appearing.
  async function refresh() {
    const results = await Promise.allSettled([
      api('/exams'),
      api('/rooms'),
      api('/slots'),
      api('/schedule')
    ]);

    const errors = [];
    let successfulRequests = 0;

    if (results[0].status === 'fulfilled') {
      setExams(asArray(results[0].value));
      successfulRequests++;
    } else {
      errors.push(`Exams: ${results[0].reason?.message || 'Request failed'}`);
    }

    if (results[1].status === 'fulfilled') {
      setRooms(asArray(results[1].value));
      successfulRequests++;
    } else {
      errors.push(`Rooms: ${results[1].reason?.message || 'Request failed'}`);
    }

    if (results[2].status === 'fulfilled') {
      setSlots(asArray(results[2].value));
      successfulRequests++;
    } else {
      errors.push(`Slots: ${results[2].reason?.message || 'Request failed'}`);
    }

    if (results[3].status === 'fulfilled') {
      const data = results[3].value || {};
      setSchedule(Array.isArray(data) ? data : asArray(data.schedule));
      setUnassigned(asArray(data.unassigned));
      if (data.metrics) setMetrics(data.metrics);
      if (data.explanations) setExplanations(data.explanations);
      successfulRequests++;
    } else {
      errors.push(`Schedule: ${results[3].reason?.message || 'Request failed'}`);
    }

    setConnected(successfulRequests > 0);
    setError(errors.join(' | '));
  }

// Fetch data only after admin login
useEffect(() => {
  if (user?.role === 'admin') {
    refresh();
  }
}, [user]);

  async function optimize() {
    setLoading(true);
    setError('');

    try {
      const result = await api('/optimize', {
        method: 'POST',
        body: JSON.stringify(scenario)
      });

      setSchedule(result.schedule || []);
      setUnassigned(result.unassigned || []);
      setMetrics(result.metrics || null);
      setExplanations(result.explanations || []);
      setConnected(true);
      setPage('Timetable');
    } catch (e) {
      setError(
        e.message ||
        'Backend not reachable. Start FastAPI in the backend folder, then try again.'
      );
    } finally {
      setLoading(false);
    }
  }

  async function addExam(e) {
    e.preventDefault();
    setError('');

    try {
      const payload = {
        ...form,
        students: Number(form.students),
        duration: Number(form.duration)
      };

      const item = connected
        ? await api('/exams', {
            method: 'POST',
            body: JSON.stringify(payload)
          })
        : { ...payload, id: `E${Date.now()}` };

      if (!connected) {
        setError('Demo-only exam added locally. Start the backend to save changes and optimize.');
      }

      setExams(old => [...old, item]);
      setShowAdd(false);
      setForm({
        course_code: '',
        course_name: '',
        students: 60,
        group: 'CSE-A',
        duration: 180,
        priority: 'Medium'
      });
    } catch (e) {
      setError(e.message);
    }
  }

  async function removeExam(id) {
    try {
      if (connected) {
        await api(`/exams/${id}`, { method: 'DELETE' });
      }

      setExams(old => old.filter(exam => exam.id !== id));
      setSchedule(old => old.filter(item => item.exam_id !== id));
    } catch (e) {
      setError(e.message);
    }
  }

  function exportCsv() {
    const rows = [
      ['Course', 'Name', 'Students', 'Group', 'Day', 'Slot', 'Room'],
      ...schedule.map(item => [
        item.course_code,
        item.course_name,
        item.students,
        item.group,
        item.day,
        item.slot_label,
        item.room_name
      ])
    ];

    const csv = rows
      .map(row =>
        row.map(value =>
          `"${String(value ?? '').replaceAll('"', '""')}"`
        ).join(',')
      )
      .join('\n');

    const a = document.createElement('a');
    a.href = URL.createObjectURL(
      new Blob([csv], { type: 'text/csv' })
    );
    a.download = 'ripplemind-timetable.csv';
    a.click();
    URL.revokeObjectURL(a.href);
  }

  const navItems = [
    ['Overview', LayoutDashboard],
    ['Timetable', CalendarDays],
    ['Exam management', GraduationCap],
    ['Rooms & slots', Building2]
  ];

  const scheduled = metrics?.scheduled ?? schedule.length;
  const conflictCount = metrics?.conflicts_after ?? 0;

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();

    return exams.filter(exam =>
      `${exam.course_code} ${exam.course_name} ${exam.group ?? exam.student_group ?? ''}`
        .toLowerCase()
        .includes(query)
    );
  }, [exams, search]);
if (!user) {
  return <Login onLogin={(loggedInUser) => {
    localStorage.setItem('ripplemind_user', JSON.stringify(loggedInUser));
    setUser(loggedInUser);
  }} />;
}

if (user.role === 'student') {
  return (
    <StudentDashboard
      user={user}
      onLogout={() => {
        localStorage.removeItem('ripplemind_token');
        localStorage.removeItem('ripplemind_user');
        setUser(null);
      }}
    />
  );
}

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'open' : ''}`}>
        <div className="brand">
          <div className="brand-mark"><Activity size={21} /></div>
          <div>
            <strong>RippleMind</strong>
            <span>EXAM OPERATIONS</span>
          </div>
          <button className="mobile-close" onClick={() => setMobileNav(false)}>
            <X size={18} />
          </button>
        </div>

        <div className="workspace-label">WORKSPACE</div>

        <nav>
          {navItems.map(([label, Icon]) => (
            <button
              key={label}
              className={`nav-item ${page === label ? 'active' : ''}`}
              onClick={() => {
                setPage(label);
                setMobileNav(false);
              }}
            >
              <Icon size={18} />
              <span>{label}</span>
              {label === 'Timetable' && schedule.length > 0 && (
                <b className="nav-count">{schedule.length}</b>
              )}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="help-card">
            <div className="help-icon"><Sparkles size={17} /></div>
            <strong>Better schedules, fewer conflicts.</strong>
            <p>Explore scenarios and create a timetable that works for everyone.</p>
            <button onClick={() => setPage('Timetable')}>
              Open timetable <ArrowUpRight size={14} />
            </button>
          </div>

          <div className="profile">
            <div className="avatar">EA</div>
            <div className="profile-copy">
              <strong>Exam Administrator</strong>
              <span>Academic operations</span>
            </div>
            <ChevronDown size={16} />
          </div>
        </div>
      </aside>

      {mobileNav && (
        <div className="mobile-overlay" onClick={() => setMobileNav(false)} />
      )}

      <main className="main">
        <header className="topbar">
          <div className="topbar-left">
            <button className="mobile-menu" onClick={() => setMobileNav(true)}>
              <Menu size={20} />
            </button>
            <span className="crumb">Workspace</span>
            <span className="slash">/</span>
            <strong>{page}</strong>
          </div>

          <div className="topbar-right">
            <span className={`connection ${connected ? 'online' : 'offline'}`}>
              <i />
              {connected ? 'Backend connected' : 'Demo mode'}
            </span>
            <button className="icon-button" title="Refresh data" onClick={refresh}>
              <RefreshCw size={17} />
            </button>
            <div className="avatar small">EA</div>
          </div>
        </header>

        <div className="content">
          {error && (
            <div className="alert">
              <CircleAlert size={17} />
              <span>{error}</span>
              <button onClick={() => setError('')}><X size={15} /></button>
            </div>
          )}

          <section className="page-heading">
            <div>
              <div className="eyebrow">ACADEMIC PLANNING / 2026</div>
              <h1>
                {page === 'Overview'
                  ? 'Examination overview'
                  : page === 'Timetable'
                    ? 'Timetable studio'
                    : page === 'Exam management'
                      ? 'Exam management'
                      : 'Rooms & time slots'}
              </h1>
              <p>
                {page === 'Overview'
                  ? 'Plan examination schedules with clarity, control, and fewer conflicts.'
                  : page === 'Timetable'
                    ? 'Review the schedule, inspect constraints, and export the final plan.'
                    : page === 'Exam management'
                      ? 'Manage course exams, cohorts, duration, and scheduling priority.'
                      : 'Review the capacity and time windows available to the scheduler.'}
              </p>
            </div>

            <div className="heading-actions">
              {page === 'Exam management' && (
                <button className="btn secondary" onClick={() => setShowAdd(true)}>
                  <Plus size={16} /> Add exam
                </button>
              )}
              <button className="btn primary" onClick={optimize} disabled={loading}>
                <Sparkles size={16} />
                {loading ? 'Optimizing…' : 'Optimize timetable'}
              </button>
            </div>
          </section>

          {page === 'Overview' && (
            <Overview
              exams={exams}
              rooms={rooms}
              slots={slots}
              schedule={schedule}
              metrics={metrics}
              onOptimize={optimize}
              loading={loading}
              setPage={setPage}
            />
          )}

          {page === 'Timetable' && (
            <Timetable
              schedule={schedule}
              unassigned={unassigned}
              slots={slots}
              metrics={metrics}
              explanations={explanations}
              onExport={exportCsv}
              scenario={scenario}
              setScenario={setScenario}
              onOptimize={optimize}
              loading={loading}
            />
          )}

          {page === 'Exam management' && (
            <ExamManagement
              exams={filtered}
              search={search}
              setSearch={setSearch}
              onAdd={() => setShowAdd(true)}
              onRemove={removeExam}
            />
          )}

          {page === 'Rooms & slots' && (
            <RoomsSlots
              rooms={rooms}
              slots={slots}
              scenario={scenario}
              setScenario={setScenario}
            />
          )}
        </div>

        <footer className="footer">
          <span>
            RippleMind <span className="muted">· Examination scheduling workspace</span>
          </span>
          <span>
            Constraint-aware planning <span className="footer-dot">●</span> v1.0
          </span>
        </footer>
      </main>

      {showAdd && (
        <div className="modal-backdrop" onClick={() => setShowAdd(false)}>
          <form
            className="modal"
            onSubmit={addExam}
            onClick={e => e.stopPropagation()}
          >
            <div className="modal-heading">
              <div>
                <h2>Add an exam</h2>
                <p>Enter course and cohort details to include it in scheduling.</p>
              </div>
              <button
                type="button"
                className="icon-button"
                onClick={() => setShowAdd(false)}
              >
                <X size={18} />
              </button>
            </div>

            <div className="form-grid">
              <label>
                Course code
                <input
                  required
                  value={form.course_code}
                  onChange={e =>
                    setForm({ ...form, course_code: e.target.value.toUpperCase() })
                  }
                  placeholder="CSE306"
                />
              </label>

              <label>
                Student group
                <input
                  required
                  value={form.group}
                  onChange={e => setForm({ ...form, group: e.target.value })}
                  placeholder="CSE-A"
                />
              </label>

              <label className="full">
                Course name
                <input
                  required
                  value={form.course_name}
                  onChange={e => setForm({ ...form, course_name: e.target.value })}
                  placeholder="Introduction to AI"
                />
              </label>

              <label>
                Students
                <input
                  type="number"
                  min="1"
                  max="1000"
                  required
                  value={form.students}
                  onChange={e => setForm({ ...form, students: e.target.value })}
                />
              </label>

              <label>
                Duration
                <select
                  value={form.duration}
                  onChange={e => setForm({ ...form, duration: Number(e.target.value) })}
                >
                  <option value="120">2 hours</option>
                  <option value="180">3 hours</option>
                  <option value="240">4 hours</option>
                </select>
              </label>

              <label className="full">
                Scheduling priority
                <select
                  value={form.priority}
                  onChange={e => setForm({ ...form, priority: e.target.value })}
                >
                  <option>High</option>
                  <option>Medium</option>
                  <option>Low</option>
                </select>
              </label>
            </div>

            <div className="modal-actions">
              <button
                type="button"
                className="btn secondary"
                onClick={() => setShowAdd(false)}
              >
                Cancel
              </button>
              <button className="btn primary" type="submit">
                <Plus size={16} /> Add exam
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, sub, icon: Icon, tone = 'blue' }) {
  return (
    <div className="stat-card">
      <div className="stat-top">
        <span>{label}</span>
        <div className={`stat-icon ${tone}`}><Icon size={18} /></div>
      </div>
      <div className="stat-value">{value}</div>
      <div className="stat-sub">{sub}</div>
    </div>
  );
}

function Overview({ exams, rooms, slots, schedule, metrics, onOptimize, loading, setPage }) {
  const groups = Object.entries(
    exams.reduce((a, e) => {
      const group = e.group ?? e.student_group ?? 'Unknown';
      a[group] = (a[group] || 0) + 1;
      return a;
    }, {})
  ).sort((a, b) => b[1] - a[1]).slice(0, 5);

  const count = metrics?.scheduled ?? schedule.length;

  return (
    <>
      <div className="stats-grid">
        <StatCard
          label="Total examinations"
          value={exams.length}
          sub="Courses in this planning cycle"
          icon={GraduationCap}
        />
        <StatCard
          label="Scheduled exams"
          value={`${count}/${exams.length}`}
          sub={count === exams.length ? 'All exams currently assigned' : 'Run optimizer to build a schedule'}
          icon={CalendarDays}
          tone="purple"
        />
        <StatCard
          label="Unresolved conflicts"
          value={metrics?.conflicts_after ?? '—'}
          sub={metrics ? 'Checked against hard constraints' : 'Optimize to validate constraints'}
          icon={CircleAlert}
          tone="amber"
        />
        <StatCard
          label="Room utilization"
          value={metrics ? `${metrics.room_utilization}%` : '—'}
          sub={`${rooms.length} rooms · ${slots.length} time slots`}
          icon={Building2}
          tone="green"
        />
      </div>

      <div className="overview-grid">
        <section className="panel schedule-panel">
          <div className="panel-heading">
            <div>
              <h2>Schedule preview</h2>
              <p>Latest assigned examination sessions</p>
            </div>
            <button className="text-button" onClick={() => setPage('Timetable')}>
              View timetable <ArrowUpRight size={15} />
            </button>
          </div>

          {schedule.length ? (
            <div className="preview-list">
              {schedule.slice(0, 5).map((s, i) => (
                <div className="preview-row" key={s.exam_id ?? s.id ?? i}>
                  <div className="date-tile">
                    <strong>{(s.day ?? 'TBD').slice(0, 3)}</strong>
                    <span>{s.slot_id ?? '—'}</span>
                  </div>
                  <div className="preview-course">
                    <strong>{s.course_code ?? s.exam_id}</strong>
                    <span>{s.course_name ?? 'Exam'}</span>
                  </div>
                  <div className="preview-room">
                    <span>{s.slot_label ?? '—'}</span>
                    <strong>{s.room_name ?? 'Unassigned'}</strong>
                  </div>
                  <span className="students-tag">
                    <Users size={13} />{s.students ?? 0}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <div className="empty-icon"><CalendarDays size={25} /></div>
              <strong>Your timetable is ready to take shape</strong>
              <p>Run the optimizer to assign exams to available rooms and time slots.</p>
              <button className="btn primary" onClick={onOptimize} disabled={loading}>
                <Sparkles size={16} />
                {loading ? 'Optimizing…' : 'Generate first timetable'}
              </button>
            </div>
          )}
        </section>

        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Planning snapshot</h2>
              <p>Resource distribution</p>
            </div>
            <div className="tiny-pill">LIVE</div>
          </div>

          <div className="snapshot-stat">
            <div className="snapshot-label">
              <span>Exam coverage</span>
              <strong>{Math.round(count / Math.max(1, exams.length) * 100)}%</strong>
            </div>
            <div className="progress-track">
              <div
                className="progress-fill"
                style={{ width: `${Math.min(100, count / Math.max(1, exams.length) * 100)}%` }}
              />
            </div>
          </div>

          <div className="snapshot-stat">
            <div className="snapshot-label">
              <span>Available rooms</span>
              <strong>{rooms.length}</strong>
            </div>
            <div className="room-bars">
              {rooms.map((r, i) => (
                <div className="room-bar-row" key={r.id ?? i}>
                  <span>{(r.name ?? r.room_name ?? r.id ?? 'Room').replace('Block ', '')}</span>
                  <div className="progress-track">
                    <div
                      className="progress-fill alt"
                      style={{ width: `${Math.min(100, (Number(r.capacity) || 0) / 120 * 100)}%` }}
                    />
                  </div>
                  <strong>{r.capacity ?? '—'}</strong>
                </div>
              ))}
            </div>
          </div>

          <div className="snapshot-stat">
            <div className="snapshot-label">
              <span>Student groups</span>
              <strong>{groups.length}</strong>
            </div>
            <div className="group-chips">
              {groups.map(([group, n]) => (
                <span key={group}>{group}<b>{n}</b></span>
              ))}
            </div>
          </div>
        </section>
      </div>

      <section className="panel workflow-panel">
        <div className="workflow-copy">
          <div className="feature-icon"><Settings2 size={20} /></div>
          <div>
            <h2>Build a better schedule</h2>
            <p>
              RippleMind checks room capacity and student-group overlaps, then
              assigns compatible rooms and time slots. Tune the scenario to
              compare planning outcomes.
            </p>
          </div>
        </div>
        <button className="btn primary" onClick={() => setPage('Rooms & slots')}>
          Configure scenario <ArrowUpRight size={16} />
        </button>
      </section>
    </>
  );
}

function Timetable({
  schedule, unassigned, slots, metrics, explanations, onExport,
  scenario, setScenario, onOptimize, loading
}) {
  const [activeDay, setActiveDay] = useState('All days');
  const [simulation, setSimulation] = useState(null);
  const [scenarios, setScenarios] = useState(null);
  const [toolError, setToolError] = useState('');
  const [toolLoading, setToolLoading] = useState(false);
  async function runSimulation() {
    setToolLoading(true); setToolError(''); setScenarios(null);
    try { setSimulation(await api('/simulate', { method: 'POST', body: JSON.stringify(scenario) })); }
    catch (e) { setToolError(e.message || 'Simulation failed'); }
    finally { setToolLoading(false); }
  }
  async function compareScenarios() {
    setToolLoading(true); setToolError(''); setSimulation(null);
    try { setScenarios(await api('/scenarios', { method: 'POST', body: JSON.stringify(scenario) })); }
    catch (e) { setToolError(e.message || 'Scenario comparison failed'); }
    finally { setToolLoading(false); }
  }
  async function applySimulation() {
    if (!simulation || !window.confirm('Apply this simulated timetable to the live database?')) return;
    setToolLoading(true); setToolError('');
    try {
      await api('/apply-simulation', { method: 'POST', body: JSON.stringify({ assignments: simulation.schedule }) });
      window.location.reload();
    } catch (e) { setToolError(e.message || 'Could not apply simulation'); }
    finally { setToolLoading(false); }
  }
  const days = ['All days', ...new Set(schedule.map(s => s.day).filter(Boolean))];
  const shown = schedule.filter(s => activeDay === 'All days' || s.day === activeDay);

  return (
    <>
      <div className="scenario-strip">
        <div>
          <div className="scenario-icon"><Settings2 size={18} /></div>
          <div>
            <strong>Scenario controls</strong>
            <span>{scenario.available_slots} time slots · {scenario.duration_buffer} min buffer</span>
          </div>
        </div>

        <label>
          Available slots
          <select
            value={scenario.available_slots}
            onChange={e => setScenario({ ...scenario, available_slots: Number(e.target.value) })}
          >
            {slots.map((s, i) => (
              <option key={s.id ?? i} value={i + 1}>{i + 1} slots</option>
            ))}
          </select>
        </label>

        <label>
          Duration buffer
          <select
            value={scenario.duration_buffer}
            onChange={e => setScenario({ ...scenario, duration_buffer: Number(e.target.value) })}
          >
            <option value="0">No buffer</option>
            <option value="15">15 minutes</option>
            <option value="30">30 minutes</option>
            <option value="60">60 minutes</option>
          </select>
        </label>

        <label className="toggle-label">
          <input
            type="checkbox"
            checked={scenario.prefer_larger_rooms}
            onChange={e => setScenario({ ...scenario, prefer_larger_rooms: e.target.checked })}
          />
          Fit rooms closely
        </label>

        <button className="btn primary" onClick={onOptimize} disabled={loading}>
          <Sparkles size={15} />{loading ? 'Working…' : 'Run scenario'}
        </button>
      </div>

      <section className="panel" style={{ marginTop: 16 }}>
        <div className="panel-heading">
          <div>
            <h2>Simulation & scenario lab</h2>
            <p>Preview changes without saving, inspect affected exams, and compare alternatives.</p>
          </div>
          <Sparkles size={18} className="muted-icon" />
        </div>
        <div className="heading-actions" style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <button className="btn secondary" onClick={runSimulation} disabled={toolLoading}>
            {toolLoading ? 'Working…' : 'Run what-if simulation'}
          </button>
          <button className="btn secondary" onClick={compareScenarios} disabled={toolLoading}>
            Compare 3 scenarios
          </button>
          <button className="btn secondary" onClick={async () => {
            setToolLoading(true); setToolError('');
            try {
              const result = await api('/validate');
              setSimulation({ validationOnly: true, ...result });
            } catch (e) { setToolError(e.message || 'Validation failed'); }
            finally { setToolLoading(false); }
          }} disabled={toolLoading}>Validate current timetable</button>
        </div>
        {toolError && <div className="alert" style={{ marginTop: 12 }}>{toolError}</div>}
        {simulation && (
          <div style={{ marginTop: 16 }}>
            <strong>{simulation.validationOnly ? (simulation.valid ? 'Current timetable passes validation' : 'Current timetable has conflicts') : simulation.message}</strong>
            {simulation.metrics && <p>Scheduled: {simulation.metrics.scheduled} · Unassigned: {simulation.metrics.unassigned} · Conflicts: {simulation.metrics.hard_conflicts} · Changed assignments: {simulation.metrics.changed_assignments}</p>}
            {simulation.conflicts?.length > 0 && <div className="unassigned-list">{simulation.conflicts.map((c, i) => <p key={i}>{c.message}</p>)}</div>}
            {simulation.affected?.length > 0 && <>
              <h3>Affected exams ({simulation.affected.length})</h3>
              <div className="table-wrap"><table><thead><tr><th>Course</th><th>Status</th><th>Previous</th><th>Proposed</th></tr></thead><tbody>
                {simulation.affected.map((a, i) => <tr key={a.exam_id || i}><td>{a.course_code}</td><td>{a.status}</td><td>{a.previous_room || '—'} · {a.previous_slot || '—'}</td><td>{a.new_room || 'Unassigned'} · {a.new_slot || '—'}</td></tr>)}
              </tbody></table></div>
            </>}
            {simulation.schedule && <button className="btn primary" style={{ marginTop: 12 }} onClick={applySimulation} disabled={toolLoading || simulation.conflicts?.length > 0}>Apply validated simulation</button>}
          </div>
        )}
        {scenarios?.scenarios && <div style={{ marginTop: 16 }}>
          <strong>Recommended scenario: {scenarios.recommended}</strong>
          <div className="table-wrap"><table><thead><tr><th>Scenario</th><th>Scheduled</th><th>Unassigned</th><th>Conflicts</th><th>Changed</th><th>Score</th></tr></thead><tbody>
            {scenarios.scenarios.map(item => <tr key={item.name}><td>{item.name}</td><td>{item.metrics.scheduled}</td><td>{item.metrics.unassigned}</td><td>{item.metrics.hard_conflicts}</td><td>{item.metrics.changed_assignments}</td><td>{item.metrics.score}</td></tr>)}
          </tbody></table></div>
          <p className="helper-copy">Scenario comparison is a preview only; no timetable is saved by this action.</p>
        </div>}
      </section>

      <div className="stats-grid compact">
        <StatCard label="Scheduled" value={metrics?.scheduled ?? schedule.length} sub={`of ${metrics?.total ?? schedule.length} exams`} icon={CheckCircle2} tone="green" />
        <StatCard label="Unassigned" value={metrics?.unassigned ?? unassigned.length} sub="Need more compatible capacity" icon={CircleAlert} tone="amber" />
        <StatCard label="Hard conflicts" value={metrics?.conflicts_after ?? 0} sub="Room and cohort overlaps" icon={Activity} />
        <StatCard label="Seat utilization" value={metrics ? `${metrics.seat_utilization}%` : '—'} sub="Allocated seats across slots" icon={Users} tone="purple" />
      </div>

      <section className="panel timetable-panel">
        <div className="panel-heading">
          <div>
            <h2>Generated timetable</h2>
            <p>
              {schedule.length
                ? `${schedule.length} exams assigned across ${new Set(schedule.map(s => s.day)).size} days`
                : 'No schedule generated yet'}
            </p>
          </div>
          <div className="heading-actions">
            <button className="btn secondary" onClick={onExport} disabled={!schedule.length}>
              <Download size={15} /> Export CSV
            </button>
          </div>
        </div>

        <div className="tabs">
          {days.map(day => (
            <button
              className={activeDay === day ? 'selected' : ''}
              key={day}
              onClick={() => setActiveDay(day)}
            >
              {day}
            </button>
          ))}
        </div>

        {shown.length ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>COURSE</th>
                  <th>STUDENT GROUP</th>
                  <th>DAY / SLOT</th>
                  <th>ROOM</th>
                  <th>COHORT</th>
                  <th>CAPACITY</th>
                </tr>
              </thead>
              <tbody>
                {shown.map((s, i) => (
                  <tr key={s.exam_id ?? s.id ?? i}>
                    <td>
                      <div className="course-cell">
                        <strong>{s.course_code ?? s.exam_id}</strong>
                        <span>{s.course_name ?? 'Exam'}</span>
                      </div>
                    </td>
                    <td><span className="group-badge">{s.group ?? '—'}</span></td>
                    <td>
                      <div className="slot-cell">
                        <strong>{s.day ?? '—'}</strong>
                        <span><Clock3 size={13} />{s.slot_label ?? '—'}</span>
                      </div>
                    </td>
                    <td>
                      <div className="room-cell"><Building2 size={15} />{s.room_name ?? '—'}</div>
                    </td>
                    <td>{s.students ?? '—'} students</td>
                    <td>
                      <div className="capacity-cell">
                        <div className="progress-track">
                          <div
                            className="progress-fill"
                            style={{
                              width: `${Math.min(100, (Number(s.students) || 0) / Math.max(1, Number(s.room_capacity) || 1) * 100)}%`
                            }}
                          />
                        </div>
                        <span>{s.students ?? '—'}/{s.room_capacity ?? '—'}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty-state compact-empty">
            <div className="empty-icon"><CalendarDays size={24} /></div>
            <strong>No timetable yet</strong>
            <p>Click “Optimize timetable” to create a schedule from your current exams.</p>
            <button className="btn primary" onClick={onOptimize} disabled={loading}>
              Generate timetable
            </button>
          </div>
        )}
      </section>

      <div className="bottom-grid">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Scheduling rationale</h2>
              <p>Why these assignments were selected</p>
            </div>
            <Sparkles size={18} className="muted-icon" />
          </div>

          {explanations.length ? (
            <div className="rationale-list">
              {explanations.map((x, i) => (
                <div key={i}>
                  <span className="rationale-number">0{i + 1}</span>
                  <p>{x}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="helper-copy">
              Run the optimizer to see the constraint checks and explanations for this scenario.
            </p>
          )}
        </section>

        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Unassigned exams</h2>
              <p>Items requiring planner attention</p>
            </div>
            <span className="count-pill">{unassigned.length}</span>
          </div>

          {unassigned.length ? (
            <div className="unassigned-list">
              {unassigned.map((u, i) => (
                <div key={u.exam_id ?? u.id ?? i}>
                  <div>
                    <strong>{u.course_code ?? u.exam_id}</strong>
                    <span>{u.course_name ?? 'Exam'}</span>
                  </div>
                  <p>{u.reason ?? 'No compatible slot was assigned.'}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="success-note">
              <CheckCircle2 size={18} />
              <div>
                <strong>No unassigned exams</strong>
                <span>All exams fit within the current room and slot constraints.</span>
              </div>
            </div>
          )}
        </section>
      </div>
    </>
  );
}

function ExamManagement({ exams, search, setSearch, onAdd, onRemove }) {
  return (
    <section className="panel management-panel">
      <div className="panel-heading">
        <div>
          <h2>Examination catalogue</h2>
          <p>Course cohorts and scheduling requirements</p>
        </div>
        <button className="btn primary" onClick={onAdd}>
          <Plus size={16} /> Add exam
        </button>
      </div>

      <div className="search-row">
        <div className="search-box">
          <Search size={17} />
          <input
            placeholder="Search by course, name, or group…"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <span className="results-count">{exams.length} exams</span>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>COURSE</th>
              <th>STUDENT GROUP</th>
              <th>STUDENTS</th>
              <th>DURATION</th>
              <th>PRIORITY</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {exams.map(e => (
              <tr key={e.id}>
                <td>
                  <div className="course-cell">
                    <strong>{e.course_code}</strong>
                    <span>{e.course_name}</span>
                  </div>
                </td>
                <td><span className="group-badge">{e.group ?? e.student_group ?? '—'}</span></td>
                <td><span className="student-count"><Users size={14} />{e.students}</span></td>
                <td>{(Number(e.duration) || 0) / 60} hours</td>
                <td>
                  <span className={`priority ${(e.priority ?? 'medium').toLowerCase()}`}>
                    {e.priority ?? 'Medium'}
                  </span>
                </td>
                <td>
                  <button className="delete-button" title="Delete exam" onClick={() => onRemove(e.id)}>
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!exams.length && <div className="no-results">No exams match that search.</div>}
      </div>

      <div className="table-footnote">
        <CircleAlert size={14} />
        Removing an exam also removes its existing timetable assignment.
      </div>
    </section>
  );
}

function RoomsSlots({ rooms, slots, scenario, setScenario }) {
  return (
    <>
      <div className="resource-grid">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Available rooms</h2>
              <p>Capacity and building information</p>
            </div>
            <Building2 size={19} className="muted-icon" />
          </div>

          <div className="room-card-list">
            {rooms.map((r, i) => (
              <div className="room-card" key={r.id ?? i}>
                <div className="room-card-icon"><Building2 size={18} /></div>
                <div className="room-info">
                  <strong>{r.name ?? r.room_name ?? r.id}</strong>
                  <span>{r.building || 'Academic building'} · {r.id}</span>
                  <div className="room-capacity-bar">
                    <div className="progress-track">
                      <div
                        className="progress-fill"
                        style={{ width: `${Math.min(100, (Number(r.capacity) || 0) / 120 * 100)}%` }}
                      />
                    </div>
                    <span>{r.capacity ?? '—'} seats</span>
                  </div>
                </div>
                <span className="available-tag">Available</span>
              </div>
            ))}
            {!rooms.length && <p className="helper-copy">No rooms returned by the API.</p>}
          </div>
        </section>

        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Time slots</h2>
              <p>Current examination windows</p>
            </div>
            <Clock3 size={19} className="muted-icon" />
          </div>

          <div className="slot-card-list">
            {slots.map((s, i) => (
              <div className="slot-card" key={s.id ?? i}>
                <div className="slot-number">{String(i + 1).padStart(2, '0')}</div>
                <div>
                  <strong>{s.day ?? s.date ?? 'Available slot'}</strong>
                  <span>{s.label ?? `${s.start_time ?? s.start ?? ''} – ${s.end_time ?? s.end ?? ''}`}</span>
                </div>
                <span className="slot-id">{s.id}</span>
              </div>
            ))}
            {!slots.length && <p className="helper-copy">No time slots returned by the API.</p>}
          </div>
        </section>
      </div>

      <section className="panel scenario-config">
        <div className="panel-heading">
          <div>
            <h2>Optimization preferences</h2>
            <p>Configure how a new timetable is generated</p>
          </div>
          <Settings2 size={19} className="muted-icon" />
        </div>

        <div className="config-grid">
          <div>
            <strong>Available time slots</strong>
            <p>Limit the number of windows considered by the scheduler.</p>
            <select
              value={scenario.available_slots}
              onChange={e => setScenario({ ...scenario, available_slots: Number(e.target.value) })}
            >
              {slots.map((s, i) => (
                <option key={s.id ?? i} value={i + 1}>{i + 1} slots</option>
              ))}
              {!slots.length && <option value={6}>6 slots</option>}
            </select>
          </div>

          <div>
            <strong>Duration buffer</strong>
            <p>Add a planning buffer to the nominal exam duration.</p>
            <select
              value={scenario.duration_buffer}
              onChange={e => setScenario({ ...scenario, duration_buffer: Number(e.target.value) })}
            >
              <option value="0">No buffer</option>
              <option value="15">15 minutes</option>
              <option value="30">30 minutes</option>
              <option value="60">60 minutes</option>
            </select>
          </div>

          <div>
            <strong>Room assignment</strong>
            <p>Prefer rooms with less unused capacity.</p>
            <label className="check-row">
              <input
                type="checkbox"
                checked={scenario.prefer_larger_rooms}
                onChange={e => setScenario({ ...scenario, prefer_larger_rooms: e.target.checked })}
              />
              Fit rooms closely
            </label>
          </div>
        </div>
      </section>
    </>
  );
}

createRoot(document.getElementById('root')).render(<App />);
